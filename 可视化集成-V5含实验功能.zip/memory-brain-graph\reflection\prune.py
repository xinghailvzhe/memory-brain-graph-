# -*- coding: utf-8 -*-
"""归档候选清单：把「标了 stale 很久」的条目和「标题重复」的组挑出来。
默认只出报告（不动库）；只有显式 --apply 才会把 stale 超过 N 天的条目标成 archived，
而且动手之前一定先备份 memory.db。

用法：
  prune.py                  # 只报告
  prune.py --days 45        # 改阈值（默认 30 天）
  prune.py --apply         # 备份 + 真正归档

判据：
  · stale 状态 + updated_at 早于 N 天前 → 归档候选（stale 本来就表示"完结/过时"，放太久只是占检索面）
  · 标题归一化后重复的组 → 提示合并（不自动改，因为合并判断需要语义）
"""
import sqlite3
import os
import shutil
import datetime
import sys

HERE = os.path.dirname(os.path.abspath(__file__))
WORKSPACE = os.environ.get("REFLECT_WORKSPACE") or os.path.dirname(os.path.dirname(HERE))
DB = os.environ.get("REFLECT_DB") or os.path.join(WORKSPACE, ".dsh-meow", "memory.db")
BACKUP_DIR = os.environ.get("REFLECT_BACKUP") or os.path.join(WORKSPACE, ".dsh-meow", "backups")
REPORT_DIR = os.environ.get("REFLECT_LOG_DIR") or HERE
LEVELS = ["soul", "user", "project", "fact", "lesson", "topic", "rules"]
NAME = {"soul": "灵魂", "user": "用户", "project": "项目", "fact": "事实",
        "lesson": "经验", "topic": "话题", "rules": "准则"}


def norm(t):
    return "".join((t or "").split()).lower()[:40]


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    args = sys.argv[1:]
    apply_it = "--apply" in args
    days = 30
    if "--days" in args:
        try:
            days = int(args[args.index("--days") + 1])
        except Exception:
            pass
    cutoff = int((datetime.datetime.now() - datetime.timedelta(days=days)).timestamp() * 1000)

    conn = sqlite3.connect(DB)
    cand = []
    for lv in LEVELS:
        try:
            rows = conn.execute(
                "SELECT id, title, content, updated_at FROM %s WHERE status='stale' AND updated_at < ?" % lv,
                (cutoff,),
            ).fetchall()
        except Exception:
            continue
        for rid, title, content, ts in rows:
            cand.append({"level": lv, "id": rid, "title": (title or (content or "").strip()[:24]),
                         "ts": ts})
    # 重复标题（只提示，不自动改）
    dup = {}
    for lv in LEVELS:
        try:
            rows = conn.execute("SELECT title FROM %s WHERE title IS NOT NULL AND title<>''" % lv).fetchall()
        except Exception:
            continue
        for (t,) in rows:
            dup.setdefault(norm(t), []).append((lv, t))
    dup_groups = [(k, v) for k, v in dup.items() if len(v) > 1]

    if apply_it and cand:
        os.makedirs(BACKUP_DIR, exist_ok=True)
        stamp = datetime.datetime.now().strftime("%Y%m%d-%H%M%S")
        bak = os.path.join(BACKUP_DIR, "memory-%s.db" % stamp)
        shutil.copy2(DB, bak)
        done = 0
        for c in cand:
            try:
                conn.execute("UPDATE %s SET status='archived' WHERE id=?" % c["level"], (c["id"],))
                done += 1
            except Exception as e:
                print("archive failed:", c["id"], e)
        conn.commit()
        print("backup:", bak)
        print("archived:", done)

    conn.close()

    now = datetime.datetime.now()
    lines = [
        "# 归档候选 · %s" % now.strftime("%Y-%m-%d %H:%M"),
        "",
        "- 阈值：stale 超过 %d 天" % days,
        "- 候选：%d 条" % len(cand),
        "- 重复标题组：%d" % len(dup_groups),
        "",
        "## 归档候选（%d）" % len(cand),
        "",
    ]
    for c in cand[:80]:
        ts = datetime.datetime.fromtimestamp(c["ts"] / 1000).strftime("%Y-%m-%d") if c["ts"] else "?"
        lines.append("- [%s] %s｜%s" % (NAME.get(c["level"], c["level"]), c["title"][:40], ts))
    if len(cand) > 80:
        lines.append("- …另有 %d 条" % (len(cand) - 80))
    lines += ["", "## 重复标题组（%d，仅提示）" % len(dup_groups), ""]
    for k, v in dup_groups[:30]:
        lines.append("- " + " / ".join("%s:%s" % (NAME.get(lv, lv), t) for lv, t in v[:3]))
    out = os.path.join(REPORT_DIR, "prune-%s.md" % now.strftime("%Y%m%d"))
    os.makedirs(REPORT_DIR, exist_ok=True)
    with open(out, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print("report:", out)
    print("candidates:", len(cand), "dup groups:", len(dup_groups), "applied:", apply_it)


if __name__ == "__main__":
    main()
