#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""预组装件库：把「经常一起出现、可以被多个 skill 共用」的零件先拼成组件。

用户 2026-11-02 的口径（原话）：
  「设置为零件可复用然后 skill 组装是根据当前记忆分预组装和主组装，相当于你拼乐高；
    后续只是零件可复用；新组装过的 skill 可以不用拆了，只有完全用不上的时候
    或者需要优化的时候才拆，直接预组装。」

所以是三层，不是两层：

  零件 brick（skill 里的 `##` 章节，parts.py 产出）
      ↓ 预组装（这里）—— 把共享执行体的零件先拼成「组件」，可复用
  组件 sub-assembly（不是完整 skill，是半成品：执行体 + 用法 + 验收）
      ↓ 主组装（compose.py --need）—— 组件 + 新零件拼成技能
  成品 skill（45 个，已经是组装好的东西，**默认不拆**）

为什么组件不是「合并 skill」
--------------------------------
之前 review 判共享执行体就建议 merge，那是错的：DST 四件套各有自己的触发场景
（每日巡检 / 点名快查 / 版本更新 / 运维排障），合了之后触发条件全挤在一起。
正确的做法是把共用的执行体**抽成组件**，四个 skill 各自引用它 —— skill 不拆，
重复的那一份不再各写一遍。

组件的判据（自动，不靠模型）
----------------------------
1. 一个执行体（脚本/主机/配置）被 >=2 个 skill 引用
2. 这些 skill 里引用它的零件 >=2 个
3. 组件必须有 action 层（否则抽了没意义）——只共享一个路径不算组件

产物：plugins/memory-brain-graph/assets/organs/assemblies.json
"""
import datetime
import json
import re
import sys
from collections import defaultdict
import os
from pathlib import Path

WS = Path(os.environ.get("MBG_WS") or Path(__file__).resolve().parents[2])
ORGANS = Path(os.environ.get("MBG_OUT") or (WS / "plugins" / "memory-brain-graph" / "assets" / "organs"))
PARTS = ORGANS / "parts.json"
OUT = ORGANS / "assemblies.json"

# 这些 dep 太泛，被引用不等于「同一套动作」
GENERIC_DEP = re.compile(
    r"^(SKILL\.md|AGENTS\.md|CLAUDE\.md|README\.md|GLOSSARY.*\.md|docs/adr/?|references?/?|"
    r"parallel_server_exec|memory_sync|pwsh|python|node)$", re.I)
# 噪声 dep：JSON 片段、裸命令、点开头目录 —— 不是执行体，别拿它拼组件
NOISE_DEP = re.compile(
    r'[:{}"]|'                       # health:"ok / {"a":1
    r'^(diff|grep|cat|ls|cd|echo|true|false|ok)$|'
    r'^\.[\w-]+/?$',                  # .scratch/
    re.I)


def slug(s):
    s = re.sub(r"[^A-Za-z0-9]+", "-", s).strip("-").lower()
    return (s or "x")[:40]


def build():
    data = json.loads(PARTS.read_text(encoding="utf-8"))
    parts = {p["id"]: p for p in data["parts"]}

    # dep → 引用它的零件
    dep_parts = defaultdict(list)
    for p in data["parts"]:
        for d in p["deps"]:
            d = d.strip()
            if GENERIC_DEP.match(d) or NOISE_DEP.search(d):
                continue
            dep_parts[d].append(p)

    asms = []
    # 按「skill 集合」聚合 dep：一组 skill 共享一批执行体，应该合成**一个**组件，
    # 而不是每个执行体各占一个（DST 四件套的 18 个 dep 其实是一件事）。
    groups = defaultdict(lambda: {"deps": [], "parts": {}})
    for dep, ps in dep_parts.items():
        skills = tuple(sorted({p["skill"] for p in ps}))
        if len(skills) < 2:
            continue
        if not any(p["layer"] == "act" for p in ps):
            continue
        g = groups[skills]
        g["deps"].append(dep)
        for p in ps:
            g["parts"][p["id"]] = p

    for skills, g in groups.items():
        ps = list(g["parts"].values())
        layers = {"sense": 0, "think": 0, "act": 0, "unknown": 0}
        for p in ps:
            layers[p["layer"]] = layers.get(p["layer"], 0) + 1
        complete = layers["sense"] > 0 and layers["think"] > 0 and layers["act"] > 0
        # 组件名：取最短的 dep 里最能看懂的那个（绝对路径取最后一段）
        names = sorted(g["deps"], key=lambda d: (len(d), d))
        name = names[0]
        if re.match(r"^[A-Za-z]:[\\/]", name):
            name = re.split(r"[\\/]", name.rstrip("\\/"))[-1]
        asms.append({
            "id": "asm-" + slug(name) + "-" + slug(skills[0])[:10],
            "name": name,
            "deps": sorted(g["deps"])[:12],
            "parts": [{"id": p["id"], "skill": p["skill"], "title": p["title"],
                       "layer": p["layer"], "chars": p["chars"]} for p in ps],
            "skills": list(skills),
            "reuse": len(skills),
            "layers": layers,
            "complete": complete,
            "status": "active",
            "verified": False,   # 只有真被主组装用过并实测过才置 true
            "usedBy": [],
            "createdAt": datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        })

    asms.sort(key=lambda a: (-a["reuse"], -sum(a["layers"][k] for k in ("sense", "think", "act"))))
    return {
        "generatedAt": datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        "model": {"brick": "零件（skill 章节）", "sub": "组件（预组装件，可复用）", "main": "skill（主组装成品）"},
        "counts": {
            "assemblies": len(asms),
            "complete": sum(1 for a in asms if a["complete"]),
            "reusedBy3plus": sum(1 for a in asms if a["reuse"] >= 3),
            "bricks": len(parts),
        },
        "assemblies": asms,
    }


def match(need_tokens, topk=3):
    """按需求词找能直接用的组件。返回 [(score, asm)]。"""
    if not OUT.exists():
        return []
    data = json.loads(OUT.read_text(encoding="utf-8"))
    out = []
    for a in data["assemblies"]:
        text = a["dep"] + " " + " ".join(p["title"] for p in a["parts"]) + " " + " ".join(a["skills"])
        hits = sum(1 for t in need_tokens if t and t.lower() in text.lower())
        if hits:
            out.append((hits * a["reuse"], a))
    out.sort(key=lambda x: -x[0])
    return out[:topk]


def main():
    data = build()
    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")
    c = data["counts"]
    print("assemblies=%d (complete=%d, reused>=3=%d) bricks=%d -> %s" % (
        c["assemblies"], c["complete"], c["reusedBy3plus"], c["bricks"], OUT))
    print("%-30s %-6s %-5s %-5s %s" % ("assembly", "reuse", "sense", "think", "act"))
    for a in data["assemblies"][:15]:
        print("%-30s %-6d %-5d %-5d %d%s" % (
            a["name"][:30], a["reuse"], a["layers"]["sense"], a["layers"]["think"],
            a["layers"]["act"], "  ← 三层齐" if a["complete"] else ""))
    return 0


if __name__ == "__main__":
    sys.exit(main())
