# -*- coding: utf-8 -*-
"""语义反思（会一轮一轮跑到「待反思」清空为止）。

口径（用户 2026-11-01 两次反馈后定下的）：
  · 外围三个法阵 = 待反思列表（今日新增、还没被提炼过的记忆）；中间法阵 = 已反思成果；
  · 所以这里按「今日待反思」循环取批次，**一次运行会一直反思，直到没有待办才停**，
    不再出现"每次只反思一条"或"隔一会儿把同一批再总结一遍"；
  · 隐私边界：只送 project / fact / lesson / topic / rules，soul / user 两层永不外发；
  · 每批写一次 reflection.json（页面据此播一次诞生动画），并往 history.jsonl 追加一条历史；
  · 失败不改页面数据。

用法：
  semantic_reflect.py            正常跑（循环到清空）
  semantic_reflect.py --dry      只打印第一批提示词，不调模型、不改输出
  semantic_reflect.py --batch 8  每批条数（默认 6）
  semantic_reflect.py --max 6    最多跑几批（防止无限循环，默认 12）
退出码：0 成功（含"没有待反思"）；1 网关失败或写盘失败。
"""
import sqlite3
import json
import sys
import os
import re
import time
import datetime
import urllib.request
import urllib.error

import reflect_store

HERE = os.path.dirname(os.path.abspath(__file__))
WORKSPACE = os.environ.get("REFLECT_WORKSPACE") or os.path.dirname(os.path.dirname(HERE))
DB = os.environ.get("REFLECT_DB") or os.path.join(WORKSPACE, ".dsh-meow", "memory.db")
OUT_JSON = os.environ.get("REFLECT_OUT") or os.path.join(
    WORKSPACE, "plugins", "memory-brain-graph", "assets", "organs", "reflection.json")
LOG_DIR = os.environ.get("REFLECT_LOG_DIR") or HERE

# 网关与 Key 一律从环境变量读，模板里不内置任何地址/端口/本机路径。
# 换机器部署时设置：
#   REFLECT_GATEWAY   免费网关地址，形如 http://127.0.0.1:<端口>/v1/chat/completions
#   REFLECT_KEY_FILE  网关 key 文件（JSON，含 forwardKey 字段）
GATEWAY = os.environ.get("REFLECT_GATEWAY", "")
KEY_FILE = os.environ.get("REFLECT_KEY_FILE") or os.path.join(
    os.path.expanduser("~"), ".dsh", "our-free-model", "settings.json")
MODELS = ["kilo-auto/free", "openrouter/free"]

# 只反思这几层（soul/user 是身份与个人偏好，不外发）
LEVELS = ["project", "fact", "lesson", "topic", "rules"]
NAME = {"project": "项目", "fact": "事实", "lesson": "经验", "topic": "话题", "rules": "准则"}

SECRET_RE = re.compile(
    r"(sk-[A-Za-z0-9]{8,}|ofm-[A-Za-z0-9_\-]{8,}|password\s*[:=]|passwd\s*[:=]|密码\s*[:=]|密钥\s*[:=]|api[_ ]?key\s*[:=]|token\s*[:=]\s*[A-Za-z0-9_\-]{16,})",
    re.I,
)
BATCH = 10
MAX_BATCHES = 30
MAX_SECONDS = 1800
SNIP = 130


def log(msg):
    line = "%s %s" % (datetime.datetime.now().strftime("%H:%M:%S"), msg)
    try:
        os.makedirs(LOG_DIR, exist_ok=True)
        with open(os.path.join(LOG_DIR, "semantic.log"), "a", encoding="utf-8") as f:
            f.write(line + "\n")
    except Exception:
        pass
    try:
        print(line)
    except Exception:
        pass


def load_key():
    try:
        with open(KEY_FILE, "r", encoding="utf-8") as f:
            return json.load(f).get("forwardKey", "")
    except Exception:
        return ""


def _load_output():
    try:
        with open(OUT_JSON, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def _absorbed_set():
    return set(str(x) for x in (_load_output().get("absorbedIds") or []))


def fetch_pending(absorbed, limit):
    """今日新增、还没被提炼过的记忆（外围三个法阵画的就是这批）。

    返回 (items, discarded)：discarded 是"没有可用信息、不该拿去反思"的条目
    （空内容 / 含密钥口令 / 标题重复）。这些不进模型、直接算处理完，
    但要在页面上如实显示"丢弃了哪些"，不能假装反思过（用户 2026-11-01 要求）。"""
    # 「今日」从 05:00 起算：凌晨仍算前一天，05:00 后才换日（2026-11-01 用户口径）
    now0 = datetime.datetime.now()
    d0 = now0.replace(hour=5, minute=0, second=0, microsecond=0)
    if now0 < d0:
        d0 -= datetime.timedelta(days=1)
    since = int(d0.timestamp() * 1000)
    conn = sqlite3.connect(DB)
    items, discarded = [], []
    try:
        for lv in LEVELS:
            try:
                rows = conn.execute(
                    "SELECT id, title, content, project, importance FROM %s "
                    "WHERE COALESCE(created_at, updated_at) >= ? AND (status IS NULL OR status='active') "
                    "ORDER BY importance DESC, updated_at DESC LIMIT 400" % lv,
                    (since,),
                ).fetchall()
            except Exception:
                continue
            for rid, title, content, project, imp in rows:
                rid = str(rid or "")
                if not rid or rid in absorbed:
                    continue
                body = re.sub(r"\s+", " ", (content or "")).strip()
                head = (title or "").strip()
                if not head and not body:
                    discarded.append({"id": rid, "head": "(空条目)", "reason": "没有内容"})
                    continue
                if not head:
                    head, body = body[:24], body[24:]
                if SECRET_RE.search(head + " " + body):
                    discarded.append({"id": rid, "head": head[:40] or "(无标题)", "reason": "含密钥/口令"})
                    continue
                items.append({
                    "id": rid,
                    "level": lv,
                    "head": head[:40],
                    "snip": body[:SNIP].strip(),
                    "project": (project or "").strip(),
                    "importance": imp or 1,
                })
    finally:
        conn.close()
    # 去重 + 按重要度排
    seen, uniq = set(), []
    for it in sorted(items, key=lambda x: (-int(x["importance"] or 1),)):
        k = (it["head"], it["snip"][:40])
        if k in seen:
            discarded.append({"id": it["id"], "head": it["head"][:40], "reason": "标题/摘要重复"})
            continue
        seen.add(k)
        uniq.append(it)
    return uniq[:limit], discarded


def build_prompt(items):
    rows = []
    for i, it in enumerate(items, 1):
        tag = NAME[it["level"]] + ("·" + it["project"] if it["project"] and it["project"] != "全局" else "")
        rows.append("%d. [%s] %s｜%s" % (i, tag, it["head"], it["snip"]))
    body = "\n".join(rows)
    sys_p = (
        "你是记忆库的整理员。下面是一个 AI 的跨会话记忆条目（标题｜摘要）。"
        "只做判断，不写客套话。找出：①这些记忆里哪几条已经过时或被后来的事实覆盖；"
        "②哪两条彼此矛盾；③哪些重复度太高该合并；④哪些经验够格沉淀成可复用的 skill。"
        "严格输出 JSON，不要代码块，格式："
        '{"summary":"一句话总括，不超过30字",'
        '"lines":["结论一，不超过38字","结论二","结论三"]}'
        "lines 必须正好 3 条，中文，具体到条目标题或层名，不要泛泛而谈。"
        "如果这批在这几方面没有问题，就直接说“无明显问题”并给出最值得注意的一点。"
    )
    user_p = "共 %d 条：\n\n%s" % (len(items), body)
    return sys_p, user_p


def call_gateway(key, messages):
    last_err = None
    for model in MODELS:
        payload = {
            "model": model,
            "messages": messages,
            "max_tokens": 3000,
            "temperature": 0.3,
            "reasoning_effort": "low",  # 不压推理强度时，免费池的模型会把预算烧在思考上、正文空
        }
        req = urllib.request.Request(
            GATEWAY,
            data=json.dumps(payload, ensure_ascii=False).encode("utf-8"),
            headers={"Content-Type": "application/json", "Authorization": "Bearer " + key},
            method="POST",
        )
        try:
            with urllib.request.urlopen(req, timeout=150) as resp:
                data = json.loads(resp.read().decode("utf-8"))
            choice = (data.get("choices") or [{}])[0]
            msg = choice.get("message") or {}
            text = msg.get("content") or ""
            usage = data.get("usage") or {}
            tokens = usage.get("total_tokens") or 0
            if (text or "").strip():
                return text, tokens, data.get("model") or model
            last_err = "empty content from %s (finish_reason=%s)" % (model, choice.get("finish_reason"))
        except urllib.error.HTTPError as e:
            last_err = "%s HTTP %s %s" % (model, e.code, e.read()[:160].decode("utf-8", "replace"))
        except Exception as e:
            last_err = "%s %s" % (model, e)
        log("gateway failed: " + last_err)
    raise RuntimeError(last_err or "no model available")


def parse(text):
    """先按标准 JSON 解析；模型把输出截断时（免费池常见），从未闭合的文本里把 summary/lines 抠出来。"""
    t = text.strip()
    t = re.sub(r"^```(?:json)?|```$", "", t, flags=re.M).strip()
    try:
        m = re.search(r"\{.*\}", t, re.S)
        if m:
            obj = json.loads(m.group(0))
            lines = [str(x).strip() for x in (obj.get("lines") or []) if str(x).strip()]
            if len(lines) >= 3:
                return obj.get("summary", "").strip() or lines[0], lines[:3]
    except Exception:
        pass
    # 容错：summary + lines 数组逐个引号内取字符串
    ms = re.search(r'"summary"\s*:\s*"([^"]*)"', t)
    summary = (ms.group(1) if ms else "").strip()
    ml = re.search(r'"lines"\s*:\s*\[(.*)$', t, re.S)
    lines = []
    if ml:
        for seg in re.findall(r'"([^"]{2,})"', ml.group(1)):
            seg = seg.strip()
            if seg and seg not in lines:
                lines.append(seg)
    if len(lines) < 3:
        raise ValueError("need 3 lines, got %d: %s" % (len(lines), t[:160]))
    return (summary or lines[0])[:60], lines[:3]


def reflect_batch(key, items):
    sys_p, user_p = build_prompt(items)
    messages = [{"role": "system", "content": sys_p}, {"role": "user", "content": user_p}]
    for attempt in (1, 2):
        try:
            raw, tokens, model = call_gateway(key, messages)
            summary, lines = parse(raw)
            return summary, lines, tokens, model
        except Exception as e:
            log("batch attempt %d failed: %s" % (attempt, e))
            if attempt == 1:
                time.sleep(75)   # 免费池限流是分钟级窗口，等一轮再试
    return None


def write_output(now, summary, lines, tokens, model, ids, absorbed, discarded=None):
    # 手动反思（note.py 写的 manual）不能被语义反思的整体重写覆盖掉
    manual = None
    try:
        with open(OUT_JSON, "r", encoding="utf-8") as f:
            manual = json.load(f).get("manual")
    except Exception:
        pass
    data = {
        "date": now.strftime("%Y-%m-%d"),
        "updatedAt": now.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        "autoAt": now.strftime("%m-%d %H:%M"),
        "kind": "semantic",
        "tokens": tokens,
        "summary": summary[:60],
        "lines": lines,
        "model": model,
        "newIds": ids,
        "absorbedIds": sorted(absorbed),
        "pending": len(ids),
        "discarded": discarded or [],
    }
    if manual:
        data["manual"] = manual
    for _ in range(3):
        try:
            with open(OUT_JSON, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            return True
        except Exception as e:
            log("write retry: %s" % e)
            time.sleep(1)
    return False


def append_md(now, summary, lines, items, tokens, model, elapsed):
    md = [
        "",
        "## 批次 %s · %d 条 · %d tokens · %.1fs" % (now.strftime("%H:%M:%S"), len(items), tokens, elapsed),
        "",
        "- 模型：%s" % model,
        "- 结论：%s" % summary,
    ] + ["- " + x for x in lines] + ["- 条目：" + "、".join(i["head"][:18] for i in items)]
    try:
        with open(os.path.join(LOG_DIR, "semantic-%s.md" % now.strftime("%Y%m%d")), "a", encoding="utf-8") as f:
            f.write("\n".join(md) + "\n")
    except Exception as e:
        log("md write failed: %s" % e)


def main():
    try:
        sys.stdout.reconfigure(encoding="utf-8", errors="replace")
    except Exception:
        pass
    args = sys.argv[1:]
    dry = "--dry" in args
    batch = BATCH
    max_batches = MAX_BATCHES
    if "--batch" in args:
        try:
            batch = max(1, int(args[args.index("--batch") + 1]))
        except Exception:
            pass
    if "--max" in args:
        try:
            max_batches = max(1, int(args[args.index("--max") + 1]))
        except Exception:
            pass

    absorbed = _absorbed_set()
    pending, dropped0 = fetch_pending(absorbed, 9999)
    for d in dropped0:
        absorbed.add(d["id"])     # 没有可用信息：算处理完，但不冒充"反思过"
    if not pending:
        if dropped0:
            names = "、".join(x["head"][:14] for x in dropped0[:6])
            log("没有可反思的信息，丢弃 %d 条：%s" % (len(dropped0), names))
            now = datetime.datetime.now()
            # 只有丢弃时**不覆盖**上一次真正的反思结论：只把丢弃清单挂到现有 json 上，
            # updatedAt 保持不动 —— 否则页面会显示成「本次反思：丢弃 N 条」，把真结论顶掉。
            keep = _load_output()
            if keep:
                keep["discarded"] = dropped0
                try:
                    with open(OUT_JSON, "w", encoding="utf-8") as f:
                        json.dump(keep, f, ensure_ascii=False, indent=2)
                except Exception as e:
                    log("discard merge failed: %s" % e)
            reflect_store.append({"at": now.strftime("%Y-%m-%dT%H:%M:%S"),
                                  "atMs": int(now.timestamp() * 1000), "kind": "discard",
                                  "summary": "丢弃 %d 条" % len(dropped0), "lines": [],
                                  "tokens": 0, "model": "", "ids": [d["id"] for d in dropped0]})
        else:
            log("没有待反思的条目（今日新增的都已提炼），跳过，不改页面数据")
        return 0
    if dry:
        sp, up = build_prompt(pending[:batch])
        print(up)
        return 0

    if not GATEWAY:
        log("未配置网关：请设置环境变量 REFLECT_GATEWAY（或改脚本顶部的 GATEWAY）")
        return 1
    key = load_key()
    if not key:
        log("no forwardKey, abort")
        return 1

    log("开始反思：待反思 %d 条，每批 %d 条，最多 %d 批" % (len(pending), batch, max_batches))
    done, rounds = 0, 0
    fails, skip = 0, set()      # 单批失败只跳过该批；连续 3 批失败才收手
    disc_all = list(dropped0)
    t_start = time.time()
    while rounds < max_batches and time.time() - t_start < MAX_SECONDS:
        items, dropped = fetch_pending(absorbed | skip, batch)
        for d in dropped:
            absorbed.add(d["id"])       # 丢弃即处理完，别让它永远挡住"清空"
        disc_all.extend(dropped)
        if not items:
            break
        rounds += 1
        now = datetime.datetime.now()
        log("第 %d 批：%d 条（剩余待反思 %d）" % (rounds, len(items), len(fetch_pending(absorbed, 9999))))
        t0 = time.time()
        res = reflect_batch(key, items)
        if not res:
            fails += 1
            skip |= set(i["id"] for i in items if i.get("id"))
            log("批次失败（连续 %d 次），跳过这 %d 条继续" % (fails, len(items)))
            if fails >= 3:
                log("连续失败 3 次，本轮收手（已提炼 %d 条）" % done)
                return 1
            continue
        fails = 0
        summary, lines, tokens, model = res
        elapsed = time.time() - t0
        ids = [i["id"] for i in items if i.get("id")]
        absorbed |= set(ids)
        if not write_output(now, summary, lines, tokens, model, ids, absorbed, disc_all):
            return 1
        reflect_store.append({
            "at": now.strftime("%Y-%m-%dT%H:%M:%S"),
            "atMs": int(now.timestamp() * 1000),
            "kind": "semantic",
            "summary": summary[:60],
            "lines": lines,
            "tokens": tokens,
            "model": model,
            "ids": ids,
        })
        append_md(now, summary, lines, items, tokens, model, elapsed)
        done += len(ids)
        log("第 %d 批完成：%s" % (rounds, summary))
        for x in lines:
            log("  - " + x)
        time.sleep(1.0)

    remain = len(fetch_pending(absorbed, 9999))
    log("本轮结束：提炼 %d 条，剩待反思 %d 条，用时 %.0fs" % (done, remain, time.time() - t_start))
    return 0


if __name__ == "__main__":
    sys.exit(main())
