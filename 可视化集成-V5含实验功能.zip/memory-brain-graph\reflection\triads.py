#!/usr/bin/env python3
"""把「要被反思的东西」（skill / plugin）按 感知 / 思索 / 实践 三个权重打成坐标。

不手填，全自动：skill 读 SKILL.md，plugin 读代码与页面。
三个轴的定义（2026-11-02 与用户对齐）：
  · 感知 = 靠什么被触发、吃什么输入（监听 / 事件 / 轮询 / 定时）
  · 思索 = 内含的判断与取舍（规则 / 阈值 / 优先级 / 条件）
  · 实践 = 实际往外吐的动作（写 / 执行 / 部署 / 渲染 / 推送）

输出：plugins/memory-brain-graph/assets/organs/triads.json
      + 控制台一份「最失衡的」清单。
"""
import datetime
import json
import math
import re
from pathlib import Path

WS = Path(__file__).resolve().parents[2]
SKILLS = Path.home() / ".dsh" / "skills"
PLUGINS = WS / "plugins"
OUT = WS / "plugins" / "memory-brain-graph" / "assets" / "organs" / "triads.json"
WAKEUPS = WS / "learn" / "wakeups.json"

PAT = {
    "sense": re.compile(
        r"监听|事件|触发|感知|轮询|检测|订阅|hook|watch|listen|emit|observ|subscrib|schedul|timer|interval|timeout|poll",
        re.I),
    "think": re.compile(
        r"判断|决策|策略|规则|条件|阈值|权重|优先级|分析|解析|推理|评估|取舍|policy|rule|threshold|score|weight|priorit|decision|evaluat",
        re.I),
    "act": re.compile(
        r"写入|保存|执行|运行|推送|上传|下载|部署|生成|渲染|绘制|命令|工具调用|落盘|write|save|exec|spawn|deploy|render|draw|push|upload|fetch|apply|invoke",
        re.I),
}
SAT = 40.0          # 每千字符命中这么多次算打满
MAX_BYTES = 400_000  # 单个对象最多读这么多字节，避免大包压制
TEXT_EXT = {".md", ".js", ".mjs", ".cjs", ".ts", ".tsx", ".py", ".json", ".yml", ".yaml", ".html", ".css", ".txt"}


def collect_text(paths):
    buf = []
    total = 0
    for p in paths:
        try:
            if p.is_dir():
                continue
            if p.suffix.lower() not in TEXT_EXT:
                continue
            if total >= MAX_BYTES:
                break
            with open(p, "r", encoding="utf-8", errors="ignore") as f:
                chunk = f.read(MAX_BYTES - total)
            buf.append(chunk)
            total += len(chunk)
        except Exception:
            continue
    return "\n".join(buf)


def score(text):
    n = len(text)
    if n < 50:
        return None
    out = {}
    for k, rx in PAT.items():
        hits = len(rx.findall(text))
        density = hits / (n / 1000.0)
        out[k] = round(min(1.0, math.log1p(density) / math.log1p(SAT)), 3)
    vals = list(out.values())
    out["balance"] = round(max(vals) - min(vals), 3)   # 越大越失衡
    out["top"] = max(out, key=lambda x: out[x]) if out["balance"] > 0 else "even"
    out["chars"] = n
    return out


def main():
    items = []
    if SKILLS.exists():
        for d in sorted(SKILLS.iterdir()):
            if not d.is_dir():
                continue
            f = d / "SKILL.md"
            if not f.exists():
                continue
            s = score(collect_text([f]))
            if s:
                items.append(dict(name=d.name, type="skill", **s))
    if PLUGINS.exists():
        for d in sorted(PLUGINS.iterdir()):
            if not d.is_dir() or d.name.startswith("."):
                continue
            files = [p for p in d.rglob("*") if p.is_file()]
            s = score(collect_text(files))
            if s:
                items.append(dict(name=d.name, type="plugin", **s))

    # 唤醒寄存器：被声明「什么时候自己动」的 skill，感知轴不该算成 0
    # （它不是等人喊，而是有触发时机；判定看 learn/wakeups.json，不看正文里有没有「监听」这个词）
    wake = {}
    try:
        with open(WAKEUPS, "r", encoding="utf-8") as f:
            for it in (json.load(f).get("items") or []):
                if it.get("enabled", True):
                    wake[it.get("skill") or it.get("id")] = it
    except Exception:
        pass
    for it in items:
        w = wake.get(it["name"])
        if it["type"] == "skill" and w:
            if w.get("status", "active") == "active":
                it["sense"] = round(max(it["sense"], 0.45), 3)
                it["wake"] = w.get("when", "")
            else:
                it["wakePending"] = w.get("when", "")
            vals = [it["sense"], it["think"], it["act"]]
            it["balance"] = round(max(vals) - min(vals), 3)
            it["top"] = max(("sense", "think", "act"), key=lambda k: it[k])

    items.sort(key=lambda x: -x["balance"])
    _act = [w for w in wake.values() if w.get("status", "active") == "active"]
    _pend = [w for w in wake.values() if w.get("status") == "pending"]
    data = {
        "generatedAt": datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        "axes": {"sense": "感知/触发", "think": "思索/判断", "act": "实践/动作"},
        "count": len(items),
        "wake": {
            "total": len(wake),
            "active": len(_act),
            "pending": len(_pend),
            "inProgress": len(_pend) > 0,
            "items": [{"skill": k, "when": v.get("when", ""), "status": v.get("status", "active")}
                      for k, v in wake.items()],
        },
        "items": items,
    }
    OUT.parent.mkdir(parents=True, exist_ok=True)
    with open(OUT, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)

    print("objects=%d  -> %s" % (len(items), OUT))
    print("%-34s %-7s %5s %5s %5s %5s" % ("name", "type", "sense", "think", "act", "imbal"))
    for it in items[:20]:
        print("%-34s %-7s %5.2f %5.2f %5.2f %5.2f" % (
            it["name"][:34], it["type"], it["sense"], it["think"], it["act"], it["balance"]))


if __name__ == "__main__":
    main()
