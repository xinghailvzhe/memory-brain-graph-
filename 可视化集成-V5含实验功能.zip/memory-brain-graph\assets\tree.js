/* =============================================================================
 * 光缆树 · 心智单元 —— 记忆脑图里的「独立视图」
 *
 * 定位：不参与脑图那套 camDist 缩放分层（放大法阵 / 缩小鲸鱼那套）。
 *       它是 viewMode === 'tree' 时整屏接管的一张独立画面，按开关来回切。
 *
 * 画面：地面是一整块电路板（透视网格 + 节点），正中一颗斜放的 CPU；
 *       CPU 引脚引出的走线先按板子的 45° 折线走，出板后渐变成暖金色根须铺开；
 *       树从 CPU 顶面长出来 —— 主干是几十股绞合光缆（白热芯 / 金中层 / 暗铜外廓），
 *       分出五级枝，枝头各开一朵半机械花（金铜花瓣 + 齿轮花心 + LED 芯）。
 *
 * 口径（对齐记忆脑图）：深近黑底 + 极淡点阵 + 星尘；细亮线 + 柔光晕；
 *       所有发光都走「叠加(lighter)」，不用纯白大块填充。
 * ========================================================================== */
(function () {
  'use strict';

  var TAU = Math.PI * 2;

  /* ---------- 调色板：和 index.html 同源（青 #8fe3ff / 金 #ffd88a / 底 #070b14） ---------- */
  var PAL = {
    bg: '#04060c',
    ink: '#b8c9dc',
    cyan: '#8fe3ff',
    cyanSoft: '#4fb6dd',
    violet: '#9a86ff',
    goldPale: '#fff4d2',
    gold: '#ffd88a',
    goldMid: '#d9a648',
    goldDark: '#8a5f24',
    goldDeep: '#3a2710',
    ember: '#ffb45a'
  };

  /* ---------- 工具 ---------- */
  function rgba(hex, a) {
    if (a < 0) a = 0; if (a > 1) a = 1;
    var h = hex.replace('#', '');
    return 'rgba(' + parseInt(h.substr(0, 2), 16) + ',' + parseInt(h.substr(2, 2), 16) +
      ',' + parseInt(h.substr(4, 2), 16) + ',' + a.toFixed(3) + ')';
  }
  function lerp(a, b, t) { return a + (b - a) * t; }
  function clamp01(v) { return v < 0 ? 0 : v > 1 ? 1 : v; }
  function easeOutCubic(t) { t = clamp01(t); return 1 - Math.pow(1 - t, 3); }
  function easeInOutSine(t) { return 0.5 - 0.5 * Math.cos(Math.PI * clamp01(t)); }
  function easeOutBack(t) {
    t = clamp01(t); var c = 1.6, u = t - 1;
    return 1 + (c + 1) * u * u * u + c * u * u;
  }
  function mulberry32(a) {
    return function () {
      a |= 0; a = (a + 0x6D2B79F5) | 0;
      var t = Math.imul(a ^ (a >>> 15), 1 | a);
      t = (t + Math.imul(t ^ (t >>> 7), 61 | t)) ^ t;
      return ((t ^ (t >>> 14)) >>> 0) / 4294967296;
    };
  }

  /* ---------- 场景缓存 ---------- */
  var S = null;
  var T0 = null;
  var FLOWER_HITS = [];      // 本帧每朵花的屏幕位置（点击命中用）
  var PICKED = -1;           // 当前选中的花
  var SKILL_CACHE = null;    // /api/skills 缓存
  var SKILL_BY_ID = {};      // id -> skill 对象
  var SKILL_ORDER = null;    // 花序号 -> 技能 id（有依赖关系的技能排前面，保证都在花里）
  var DEPS = null;           // { 技能id: [前置技能id...] }（assets/skill-deps.json）
  var DEPS_LOADED = false, DEPS_LOADING = false;
  var UNLOCK = null, HOVERED = -1, FLASH = 0;
  var USAGE = {};            // 技能 -> 记忆库里被提到多少次（辅助证据）
  var USAGE_LOADED = false;
  var PARTS = {};            // 技能 -> 拆出来的操作零件数（主判据）
  var PARTS_DIST = {};       // 技能 -> {sense,think,act,unknown}
  var PARTS_LOADED = false;
  var UNLOCK_PARTS = 4;      // 零件 >= 4 才算"真的会"

  function loadUnlock() {
    if (UNLOCK) return;
    UNLOCK = {};
    try { var raw = localStorage.getItem('mbgTreeUnlock'); if (raw) UNLOCK = JSON.parse(raw) || {}; } catch (e) { UNLOCK = {}; }
  }
  // 图纸：根技能默认已解锁；前置都亮的技能可以点开；其余是青色（锁定）
  function stateOf(id) {
    if (!id) return 'on';
    // 解锁条件 = 这个技能有没有被拆出足够的操作零件（真的会 → 亮）
    if (PARTS_LOADED) {
      return (PARTS[id] || 0) >= UNLOCK_PARTS ? 'on' : 'locked';
    }
    if (USAGE_LOADED) return (USAGE[id] || 0) > 0 ? 'on' : 'locked';
    loadUnlock();
    if (!DEPS || !DEPS[id] || !DEPS[id].length) return 'on';
    return 'ready';
  }
  function saveUnlock() { try { localStorage.setItem('mbgTreeUnlock', JSON.stringify(UNLOCK)); } catch (e) { } }
  function skillIdOfSeq(seq) {
    if (!SKILL_ORDER || !SKILL_ORDER.length) return null;
    return SKILL_ORDER[seq % SKILL_ORDER.length];
  }

  function loadDeps() {
    if (DEPS_LOADED || DEPS_LOADING) return;
    DEPS_LOADING = true;
    Promise.all([
      fetch('/api/skills').then(function (r) { return r.json(); }).catch(function () { return null; }),
      fetch('/skill-deps.json').then(function (r) { return r.json(); }).catch(function () { return null; }),
      fetch('/api/skill-usage').then(function (r) { return r.json(); }).catch(function () { return null; }),
      fetch('/organs/parts.json').then(function (r) { return r.json(); }).catch(function () { return null; })
    ]).then(function (res) {
      var sk = (res[0] && res[0].skills) ? res[0].skills : [];
      SKILL_CACHE = sk;
      SKILL_BY_ID = {};
      var ids = [];
      for (var i = 0; i < sk.length; i++) {
        var id = sk[i].id || sk[i].name;
        if (!id) continue;
        SKILL_BY_ID[id] = sk[i];
        ids.push(id);
      }
      DEPS = (res[1] && res[1].deps) ? res[1].deps : {};
      USAGE = (res[2] && res[2].usage) ? res[2].usage : {};
      USAGE_LOADED = true;
      if (res[3] && res[3].skills) {
        res[3].skills.forEach(function (sk) {
          var nm = sk.name || sk.id;
          if (!nm) return;
          PARTS[nm] = sk.parts || 0;
          PARTS_DIST[nm] = sk.dist || {};
        });
        PARTS_LOADED = true;
      }
      // 有依赖关系的技能优先排进花里，否则 45 个技能抢 30 朵花，依赖边会大面积落空
      var involved = {};
      Object.keys(DEPS).forEach(function (k) {
        involved[k] = 1;
        (DEPS[k] || []).forEach(function (q) { involved[q] = 1; });
      });
      var first = ids.filter(function (id) { return involved[id]; });
      // 把"记忆里还没证据"的技能也排进前 30，否则青色的花根本不会出现
      var zero = ids.filter(function (id) {
        return !involved[id] && USAGE.hasOwnProperty(id) && (USAGE[id] || 0) === 0;
      });
      var rest = ids.filter(function (id) {
        return !involved[id] && zero.indexOf(id) < 0;
      });
      SKILL_ORDER = first.concat(zero).concat(rest);
      DEPS_LOADED = true;
      if (panelEl && panelEl.style.display !== 'none') renderPanel();
    }).catch(function () { DEPS_LOADED = true; });
  }

  function skillOfSeq(seq) {
    if (!SKILL_ORDER || !SKILL_ORDER.length) return null;
    return SKILL_BY_ID[SKILL_ORDER[seq % SKILL_ORDER.length]] || null;
  }
  var BL = { cv: null, ctx: null };

  /* ============================ 构建 ============================ */
  function build(w, h) {
    var rnd = mulberry32(0x5EED2026);
    var s = Math.min(w / 1600, h / 900);      // 统一缩放：所有像素尺寸乘它
    var cx = w * 0.5;
    var baseY = h * 0.845;                    // 树干与 CPU 的交点
    var horizonY = h * 0.645;                  // 地面网格的消失带
    var sc = {
      w: w, h: h, s: s, cx: cx, baseY: baseY, horizonY: horizonY,
      age: 0,
      ground: [], chip: null, trunk: null, branches: [], tips: [],
      motes: [], routes: [], stars: [], dots: []
    };

    /* ---- 1. 背景星尘（风格契约：不用点阵；星点数量 = 面积/8000） ---- */
    var starN = Math.round((w * h) / 8000);
    for (var i = 0; i < starN; i++)
      sc.stars.push({
        x: rnd() * w, y: rnd() * h,
        r: rnd() * 1.1 + 0.25, a: rnd() * 0.5 + 0.12,
        sp: rnd() * 1.4 + 0.4, ph: rnd() * TAU
      });

    /* ---- 2. 地面：透视网格（横线 + 汇聚到消失点的纵线 + 节点 + 亮面） ---- */
    var bandH = baseY - horizonY;              // 地面纵向跨度
    var DEPTH = 16;
    var vpX = cx, vpY = horizonY - bandH * 0.30;
    for (var d = 0; d <= DEPTH; d++) {
      var u = d / DEPTH;
      var y = baseY - Math.pow(u, 1.65) * bandH;
      var k = 1 - Math.pow(u, 0.95) * 0.90;
      sc.ground.push({
        kind: 'h', y: y, k: k, a: (1 - u) * 0.30 + 0.03,
        w: (1 - u) * 1.0 + 0.35
      });
    }
    for (var uu = -1.6; uu <= 1.6; uu += 0.16) {
      sc.ground.push({
        kind: 'ray', uu: uu, vpX: vpX, vpY: vpY,
        a: 0.20 - Math.abs(uu) * 0.085,
        w: 0.75
      });
    }
    // 网格交点上的发光节点（稀疏）
    for (var n = 0; n < 90; n++) {
      var uu2 = (rnd() * 2 - 1) * 1.5;
      var uu3 = Math.pow(rnd(), 0.75);
      var yy = baseY - Math.pow(uu3, 1.65) * bandH;
      var kk = 1 - Math.pow(uu3, 0.95) * 0.90;
      sc.ground.push({
        kind: 'node', x: cx + uu2 * (w * 0.72) * kk, y: yy,
        r: (rnd() * 1.5 + 0.7) * s, a: rnd() * 0.5 + 0.22,
        ph: rnd() * TAU
      });
    }
    // 几块很淡的亮面（板子上的高光片区）
    for (var f = 0; f < 7; f++) {
      var fu = (rnd() * 2 - 1) * 1.2;
      var fv = 0.12 + rnd() * 0.55;
      var fy = baseY - Math.pow(fv, 1.65) * bandH;
      var fk = 1 - Math.pow(fv, 0.95) * 0.90;
      var fw = (28 + rnd() * 60) * s * fk / 0.9;
      sc.ground.push({
        kind: 'patch', x: cx + fu * (w * 0.72) * fk, y: fy,
        w: fw, hh: fw * 0.26, a: 0.05 + rnd() * 0.05
      });
    }

    /* ---- 3. CPU：斜放的方片（iso 菱形）+ 引脚 + 走线 ---- */
    var Cw = Math.min(w, h) * 0.124;            // 半边宽
    var Ch = Cw * 0.40;                          // 半边高（压扁）
    var chipCY = baseY + Ch * 0.52;
    sc.chip = {
      cx: cx, cy: chipCY, cw: Cw, ch: Ch,
      th: 13 * s,                                // 厚度（正面露出的板子边）
      pins: [], traces: []
    };
    // 四角：上 右 下 左
    var corners = [
      { x: cx, y: chipCY - Ch }, { x: cx + Cw, y: chipCY },
      { x: cx, y: chipCY + Ch }, { x: cx - Cw, y: chipCY }
    ];
    sc.chip.corners = corners;
    // 沿四条边排引脚
    for (var e = 0; e < 4; e++) {
      var a1 = corners[e], a2 = corners[(e + 1) % 4];
      var per = 9;
      for (var p = 1; p <= per; p++) {
        var tt = p / (per + 1);
        var px = lerp(a1.x, a2.x, tt), py = lerp(a1.y, a2.y, tt);
        // 边的外法线
        var dx = a2.x - a1.x, dy = a2.y - a1.y, dl = Math.hypot(dx, dy) || 1;
        var nx = dy / dl, ny = -dx / dl;
        // 让法线朝外（远离中心）
        if ((px + nx - cx) * nx + (py + ny - chipCY) * ny < 0) { nx = -nx; ny = -ny; }
        var pl = 7.5 * s;
        sc.chip.pins.push({
          x1: px, y1: py, x2: px + nx * pl, y2: py + ny * pl,
          a: 0.55 + 0.35 * Math.sin(p * 1.7 + e)
        });
      }
    }
    // 从引脚往外走 45° 折线（板子上的走线），再交给根须
    for (var tr = 0; tr < 26; tr++) {
      var ce = tr % 4;
      var ca = corners[ce], cb = corners[(ce + 1) % 4];
      var tq = 0.12 + rnd() * 0.76;
      var qx = lerp(ca.x, cb.x, tq), qy = lerp(ca.y, cb.y, tq);
      var ddx = cb.x - ca.x, ddy = cb.y - ca.y, ddl = Math.hypot(ddx, ddy) || 1;
      var nxx = ddy / ddl, nyy = -ddx / ddl;
      if ((qx + nxx - cx) * nxx + (qy + nyy - chipCY) * nyy < 0) { nxx = -nxx; nyy = -nyy; }
      var L1 = (26 + rnd() * 74) * s;
      var bend = (rnd() < 0.5 ? 1 : -1) * (10 + rnd() * 26) * s;
      var pts = [
        { x: qx, y: qy },
        { x: qx + nxx * L1, y: qy + nyy * L1 },
        { x: qx + nxx * L1 + bend, y: qy + nyy * L1 + bend * 0.42 }
      ];
      sc.chip.traces.push({ pts: pts, a: 0.22 + rnd() * 0.3, w: (0.6 + rnd() * 0.7) * s });
    }

    /* ---- 4. 主干：中心线 + 几十股绞合 ---- */
    var trunkH = h * 0.300;
    var topY = baseY - trunkH;
    var tp = [], radii = [];
    var N = 56;
    for (var j = 0; j <= N; j++) {
      var ss = j / N;
      // 轻微 S 形：base 附近右偏一点，往上回正再向左
      var wx = Math.sin(ss * 2.35 - 0.35) * w * 0.0075 * Math.sin(ss * 2.6)
        + Math.sin(ss * 5.6 + 1.1) * w * 0.0016;
      tp.push({ x: cx + wx, y: (chipCY + h * 0.018) - ss * trunkH });
      // 半径：底部张开（根盘），往上快速收细，再缓慢收
      var flare = 1 + 0.26 * Math.exp(-ss * 18);
      var r0 = (42 * s) * flare * (1 - 0.54 * Math.pow(ss, 0.8));
      radii.push(Math.max(2.4 * s, r0));
    }
    sc.trunk = { pts: tp, radii: radii, N: N };
    // 绞股参数
    sc.trunk.strands = [];
    var SN = 26;
    for (var k2 = 0; k2 < SN; k2++) {
      var ph = (k2 / SN) * TAU + rnd() * 0.25;
      var hue = k2 % 11 === 0 ? PAL.cyan : (k2 % 7 === 0 ? PAL.violet : PAL.gold);
      sc.trunk.strands.push({
        ph: ph,
        turns: 1.55 + rnd() * 0.55,
        w: (0.85 + rnd() * 1.35) * s,
        tint: hue,
        amp: 0.62 + rnd() * 0.38,
        a: 0.30 + rnd() * 0.45
      });
    }

    /* ---- 5. 枝：递归，五级（末梢下垂，像真树） ---- */
    // 树冠穹顶：所有枝末梢都收在这个椭圆里，轮廓才不会乱飞
    var crown = { cx: cx, cy: (chipCY - h * 0.285) - h * 0.205, rx: w * 0.345, ry: h * 0.225 };
    function insideEx(x, y) {
      var dx = (x - crown.cx) / crown.rx, dy = (y - crown.cy) / crown.ry;
      return dx * dx + dy * dy <= 1;
    }
    function fitLen(x, y, ang, len) {
      for (var kk = 1; kk >= 0.30; kk -= 0.05) {
        if (insideEx(x + Math.cos(ang) * len * kk, y + Math.sin(ang) * len * kk)) return len * kk;
      }
      return len * 0.30;
    }

    var flowerSeq = 0;
    function grow(px, py, ang, len, wid, depth, parentRoute) {
      len = fitLen(px, py, ang, len);
      var segs = Math.max(5, Math.round(len / (7 * s)));
      var pts = [{ x: px, y: py }], ws = [wid];
      var a = ang, x = px, y = py;
      var curl = (rnd() - 0.5) * 0.08;                       // 几何树：几乎不弯
      var droop = (0.02 + rnd() * 0.04) * (0.4 + depth * 0.2);  // 只留一点点垂
      for (var i2 = 1; i2 <= segs; i2++) {
        var u2 = i2 / segs;
        a += curl / segs + (droop * u2) / segs;
        x += Math.cos(a) * (len / segs);
        y += Math.sin(a) * (len / segs);
        pts.push({ x: x, y: y });
        ws.push(wid * (1 - 0.70 * Math.pow(u2, 0.7)));
      }
      var br = { pts: pts, ws: ws, depth: depth, ang: a, tip: { x: x, y: y }, twigs: [] };
      // 侧生小枝：参考图那种"毛茸茸"的冠部靠它，不然只剩光秃秃的骨架
      if (depth >= 2) {
        var tn = 2 + Math.floor(rnd() * 2);
        for (var tw = 0; tw < tn; tw++) {
          var ui = 0.22 + rnd() * 0.72;
          var bidx = Math.min(pts.length - 1, Math.floor(ui * pts.length));
          var bp = pts[bidx];
          var tside = rnd() < 0.5 ? -1 : 1;
          var ta = a + tside * (0.65 + rnd() * 0.75);
          var tl = (5 + rnd() * 10) * s;
          br.twigs.push({
            x0: bp.x, y0: bp.y,
            mx: bp.x + Math.cos(ta) * tl * 0.55 + (rnd() - 0.5) * 3 * s,
            my: bp.y + Math.sin(ta) * tl * 0.55 + (rnd() - 0.5) * 3 * s,
            x1: bp.x + Math.cos(ta) * tl,
            y1: bp.y + Math.sin(ta) * tl
          });
        }
      }
      sc.branches.push(br);
      var route = parentRoute.concat(pts);

      if (depth >= 5) {
        sc.routes.push(route);
        // 花 = 技能：数量封顶（一朵花对一个技能），其余枝头是装饰性晶体
        var isFlower = rnd() < 0.30 && flowerSeq < 30;
        if (isFlower) flowerSeq++;
        sc.tips.push({
          x: x, y: y, ang: a, d: depth,
          size: (isFlower ? 14 + rnd() * 7 : 7 + rnd() * 5) * s * (1 - depth * 0.06),
          delay: 0.50 + rnd() * 2.4,
          ph: rnd() * TAU,
          flower: isFlower,
          decor: !isFlower && rnd() < 0.42,
          seq: isFlower ? (flowerSeq - 1) : -1,
          hero: isFlower && rnd() < 0.42
        });
        return;
      }
      var kids = (depth <= 2) ? (rnd() < 0.62 ? 3 : 2) : 2;
      var spread = 0.48 + rnd() * 0.18;
      for (var c2 = 0; c2 < kids; c2++) {
        var off = (c2 / (kids - 1) - 0.5) * 2;
        var na = ang + off * spread + (rnd() - 0.5) * 0.12;
        grow(x, y, na, len * (0.74 + rnd() * 0.10), wid * 0.64, depth + 1, route);
      }
    }

    // 主干顶端分出 7 根主杈，铺满整个穹顶
    var top = tp[N];
    var boughA = [-1.30, -0.86, -0.30, 0, 0.30, 0.86, 1.30];
    for (var b = 0; b < boughA.length; b++) {
      var ba = -Math.PI / 2 + boughA[b] + (rnd() - 0.5) * 0.12;
      grow(top.x, top.y, ba, h * 0.185 * (1 - Math.abs(boughA[b]) * 0.10), 13.0 * s, 1, tp);
    }
    // 主干中段再补两根低位枝（让 tree 不是一根杆上顶个球）
    for (var lb = 0; lb < 2; lb++) {
      var li = 24 + lb * 8;
      var lp = tp[li];
      var la = -Math.PI / 2 + (lb === 0 ? -1.44 : 1.44) + (rnd() - 0.5) * 0.15;
      grow(lp.x, lp.y, la, h * 0.100, 4.8 * s, 3, tp.slice(0, li + 1));
    }

    /* ---- 5b. 晶体云：整棵树没有实体，形状全靠晶体堆出来 ---- */
    sc.shards = [];
    function pushShard(x, y, size, hue, seed) {
      sc.shards.push({ x: x, y: y, size: size, hue: hue, rot: (seed * 2.399) % TAU, ph: seed * 1.7 });
    }
    var q2, z2, s2;
    // 主干：一柱很密的晶簇（这就是"树干"，但它是散的）
    for (q2 = 0; q2 <= N; q2 += 1) {
      var tP = tp[q2], tR = radii[q2];
      var tN = Math.max(3, Math.round(tR * 0.55));
      for (z2 = 0; z2 < tN; z2++) {
        var ta = rnd() * TAU, tr = Math.sqrt(rnd()) * tR * 1.15;
        pushShard(tP.x + Math.cos(ta) * tr, tP.y + Math.sin(ta) * tr * 0.95,
          (2.4 + rnd() * 4.4) * s, rnd() < 0.10 ? 252 : 44, rnd() * 100);
      }
    }
    // 枝：越往外越疏越小
    for (var b3 = 0; b3 < sc.branches.length; b3++) {
      var br3 = sc.branches[b3];
      for (q2 = 0; q2 < br3.pts.length; q2 += 1) {
        var bp3 = br3.pts[q2], bw3 = br3.ws[q2];
        var bN = Math.max(2, Math.round(bw3 * 0.60));
        for (z2 = 0; z2 < bN; z2++) {
          pushShard(bp3.x + (rnd() - 0.5) * bw3 * 1.4,
            bp3.y + (rnd() - 0.5) * bw3 * 1.4,
            (1.5 + rnd() * Math.min(3.6, bw3 * 0.42)) * s,
            rnd() < 0.12 ? 252 : 44, rnd() * 100);
        }
      }
    }
    // 枝周围的光晕层：让"虚线"膨成一条发光的带
    for (var b4 = 0; b4 < sc.branches.length; b4++) {
      var br4 = sc.branches[b4];
      for (q2 = 0; q2 < br4.pts.length; q2 += 3) {
        var bh = br4.pts[q2];
        for (z2 = 0; z2 < 2; z2++) {
          var ha = rnd() * TAU, hr = (2.5 + rnd() * 11) * s;
          pushShard(bh.x + Math.cos(ha) * hr, bh.y + Math.sin(ha) * hr,
            (1.1 + rnd() * 2.0) * s, 44, rnd() * 100);
        }
      }
    }
    // 体积层：树冠范围内再铺一层更小更暗的碎晶，把冠"填成团"
    for (var v2 = 0; v2 < 300; v2++) {
      var va = rnd() * TAU, vr = Math.sqrt(rnd());
      var vx = crown.cx + Math.cos(va) * vr * crown.rx * 0.98;
      var vy = crown.cy + Math.sin(va) * vr * crown.ry * 1.02;
      pushShard(vx, vy, (1.1 + rnd() * 2.4) * s * (1.15 - vr * 0.45), 44, rnd() * 100);
    }

    // 根：六条晶体轨迹绕过芯片（不是实体根带，是晶簇）
    for (var r3 = 0; r3 < 6; r3++) {
      var side3 = r3 < 3 ? -1 : 1, idx3 = r3 % 3;
      var sx3 = cx + side3 * (radii[9] * 0.9);
      var sy3 = tp[9].y;
      var ex3 = cx + side3 * sc.chip.cw * (0.72 + 0.16 * idx3);
      var ey3 = sc.chip.cy + sc.chip.ch * (0.40 + 0.20 * idx3) + (2 + idx3 * 2);
      for (q2 = 0; q2 <= 16; q2++) {
        var u3 = q2 / 16;
        var px3 = sx3 + (ex3 - sx3) * Math.pow(u3, 0.85) + Math.sin(u3 * Math.PI) * side3 * 10 * s;
        var py3 = sy3 + (ey3 - sy3) * Math.pow(u3, 0.78);
        for (z2 = 0; z2 < 2; z2++) {
          pushShard(px3 + (rnd() - 0.5) * 7 * s, py3 + (rnd() - 0.5) * 7 * s,
            (1.8 + rnd() * 2.6) * s, rnd() < 0.08 ? 252 : 44, rnd() * 100);
        }
      }
    }

    /* ---- 6. 金尘 ---- */
    var moteN = Math.round(90 * s);
    var canonTop = topY - h * 0.22;
    for (var m = 0; m < moteN; m++) {
      sc.motes.push({
        x: cx + (rnd() * 2 - 1) * w * 0.40,
        y: canonTop + rnd() * (baseY - canonTop),
        r: (0.5 + rnd() * 1.7) * s,
        a: 0.18 + rnd() * 0.45,
        vy: (6 + rnd() * 16) * s,
        ph: rnd() * TAU,
        sp: 0.5 + rnd() * 1.4
      });
    }

    sc.canonTop = canonTop;
    S = sc;
    return sc;
  }

  /* ============================ 绘制小件 ============================ */

  // 一条「光缆」：按 pts/ws 画三层嵌套带子（暗铜外廓 → 金 → 白热芯）+ 外发光
  function tube(g, pts, ws, opt) {
    opt = opt || {};
    var n = pts.length;
    if (n < 2) return;
    var L = [], R = [];
    for (var i = 0; i < n; i++) {
      var p = pts[i];
      var q = pts[Math.min(n - 1, i + 1)], o = pts[Math.max(0, i - 1)];
      var tx = q.x - o.x, ty = q.y - o.y;
      var tl = Math.hypot(tx, ty) || 1;
      tx /= tl; ty /= tl;
      var w = ws[i] * 0.5;
      L.push({ x: p.x - ty * w, y: p.y + tx * w });
      R.push({ x: p.x + ty * w, y: p.y - tx * w });
    }
    function ring(scale) {
      g.beginPath();
      g.moveTo(L[0].x, L[0].y);
      for (var i1 = 1; i1 < n; i1++) g.lineTo(L[i1].x, L[i1].y);
      for (var i3 = n - 1; i3 >= 0; i3--) g.lineTo(R[i3].x, R[i3].y);
      g.closePath();
    }
    // 外轮廓（暗铜）
    ring(1); g.fillStyle = opt.body || rgba(PAL.goldDeep, opt.alpha == null ? 0.55 : opt.alpha); g.fill();
    // 中层（金）
    ring(1); g.fillStyle = opt.mid || rgba(PAL.goldMid, 0.55); g.fill();
    // 亮层：用窄一点的中心线近似（配合 lineCap）
    g.lineCap = 'round'; g.lineJoin = 'round';
    if (opt.glow !== false) {
      g.globalCompositeOperation = 'lighter';
      g.strokeStyle = rgba(opt.glowTint || PAL.gold, (opt.glowA == null ? 0.10 : opt.glowA));
      g.lineWidth = Math.max(1.6, (ws[0] + ws[n - 1]) * 0.5 * 2.4);
      g.beginPath(); g.moveTo(pts[0].x, pts[0].y);
      for (var i4 = 1; i4 < n; i4++) g.lineTo(pts[i4].x, pts[i4].y);
      g.stroke();
      g.globalCompositeOperation = 'source-over';
    }
    // 白热芯：中心细线
    g.strokeStyle = opt.core || rgba(PAL.goldPale, 0.85);
    g.lineWidth = Math.max(0.55, ws[0] * 0.20);
    g.beginPath(); g.moveTo(pts[0].x, pts[0].y);
    for (var i5 = 1; i5 < n; i5++) g.lineTo(pts[i5].x, pts[i5].y);
    g.stroke();
  }

  /* 细丝：一条发光的线（宽晕 → 金线 → 白热芯）。比 ribbon 更像光纤。 */
  function polyline(g, pts) {
    g.beginPath();
    g.moveTo(pts[0].x, pts[0].y);
    for (var i = 1; i < pts.length; i++) g.lineTo(pts[i].x, pts[i].y);
  }
  function filament(g, pts, w) {
    if (pts.length < 2) return;
    g.save();
    g.lineCap = 'round'; g.lineJoin = 'round';
    // 宽晕（加色）
    g.globalCompositeOperation = 'lighter';
    g.strokeStyle = 'rgba(255,186,104,0.055)';
    g.lineWidth = Math.max(3.0, w * 3.4);
    polyline(g, pts); g.stroke();
    // 金属主体
    g.globalCompositeOperation = 'source-over';
    g.strokeStyle = 'rgba(216,166,74,0.60)';
    g.lineWidth = Math.max(0.85, w * 0.66);
    polyline(g, pts); g.stroke();
    // 白热芯
    g.globalCompositeOperation = 'lighter';
    g.strokeStyle = 'rgba(255,232,170,0.50)';
    g.lineWidth = Math.max(0.42, w * 0.20);
    polyline(g, pts); g.stroke();
    g.restore();
  }
  /* ============================ 主绘制 ============================ */
  function draw(g, w, h, t, dt, age) {
    if (!S || S.w !== w || S.h !== h) build(w, h);
    var s = S.s;
    // 生长进度用「场景自己的年龄」：切进这个视图时从头长一遍，
    // 不跟页面全局时间跑（否则从脑图切回来时，树早就长完了）。
    if (age != null) S.age = age;
    else S.age += Math.min(0.05, Math.max(0.001, dt || 0.016));
    var tt = S.age;

    // 面板跟着 body.tree-mode 自愈（页面初始化时 tree.js 可能还没加载，applyViewMode 里那一下会漏）
    var wantPanel = document.body.classList.contains('tree-mode');
    if (wantPanel && (!panelEl || panelEl.style.display === 'none')) setPanelVisible(true);
    if (!wantPanel && panelEl && panelEl.style.display !== 'none') setPanelVisible(false);

    /* ---- 背景 ----
     * 注意：调用方已经把 ctx 设成 DPR 变换了（resize 里 setTransform(DPR,0,0,DPR,0,0)），
     * 这里**不能**再动变换，否则 HiDPI 下整张图会缩成 1/DPR。
     * 背景按风格契约：径向 #0d1626 → #070b14 → #04060b，不铺点阵。
     */
    var bg = g.createRadialGradient(S.cx, h * 0.42, 0, S.cx, h * 0.42, Math.max(w, h) * 0.85);
    bg.addColorStop(0, '#0d1626');
    bg.addColorStop(0.45, '#070b14');
    bg.addColorStop(1, '#04060b');
    g.fillStyle = bg;
    g.fillRect(0, 0, w, h);

    // 星尘
    g.globalCompositeOperation = 'lighter';
    for (var i2 = 0; i2 < S.stars.length; i2++) {
      var st = S.stars[i2];
      var tw = st.a * (0.62 + 0.38 * Math.sin(tt * st.sp + st.ph));
      g.fillStyle = 'rgba(190,215,255,' + tw.toFixed(3) + ')';
      g.beginPath(); g.arc(st.x, st.y, st.r, 0, TAU); g.fill();
    }
    g.globalCompositeOperation = 'source-over';

    /* ---- 皇冠背后的暖雾 ---- */
    var hazeY = S.canonTop + h * 0.10;
    var hz = g.createRadialGradient(S.cx, hazeY, 0, S.cx, hazeY, w * 0.42);
    hz.addColorStop(0, 'rgba(255,210,130,0.13)');
    hz.addColorStop(0.45, 'rgba(255,184,96,0.055)');
    hz.addColorStop(1, 'rgba(255,160,60,0)');
    g.fillStyle = hz;
    g.beginPath(); g.arc(S.cx, hazeY, w * 0.42, 0, TAU); g.fill();

    /* ---- 地面网格 ---- */
    drawGround(g, tt, s);

    /* ---- CPU ---- */
    drawChip(g, tt, s);

    /* ---- 晶体云：树没有实体，干/枝/根全靠晶体堆出形状 ---- */
    drawCrystalCloud(g, tt, s);

    /* ---- 花 ---- */
    FLOWER_HITS.length = 0;
    for (var fi = 0; fi < S.tips.length; fi++) {
      var tq = S.tips[fi];
      var k = clamp01((tt - 0.9 - tq.delay) / 1.25);
      if (k <= 0) continue;
      k = easeOutBack(k);
      var pf = wind(tq, tt);
      var sway = Math.sin(tt * 0.55 + tq.ph) * 0.055;
      if (tq.flower) {
        var fR = tq.size * (0.55 + 0.45 * k) * (tq.hero ? 1.5 : 1);
        var stOf = stateOf(skillIdOfSeq(tq.seq));
        if (stOf !== 'on') {
          g.save();
          g.filter = stOf === 'ready'
            ? 'hue-rotate(150deg) saturate(0.85) brightness(1.02)'
            : 'hue-rotate(158deg) saturate(0.55) brightness(0.72)';
        }
        drawFlower(g, pf.x, pf.y, tq.ang * 0.18 + sway, fR, clamp01(k), tt, tq.ph, tq.hero);
        if (stOf !== 'on') g.restore();
        FLOWER_HITS.push({ x: pf.x, y: pf.y, r: Math.max(10 * s, fR * 1.5), i: fi, seq: tq.seq });
        if (PICKED === fi) {
          g.save();
          g.strokeStyle = 'rgba(255,246,214,0.85)';
          g.lineWidth = Math.max(0.8, 1.3 * s);
          g.beginPath(); g.arc(pf.x, pf.y, fR * 1.75, 0, TAU); g.stroke();
          g.strokeStyle = 'rgba(255,214,140,0.35)';
          g.beginPath(); g.arc(pf.x, pf.y, fR * 2.25, 0, TAU); g.stroke();
          g.restore();
        }
      } else if (tq.decor) {
        drawLeafCluster(g, pf.x, pf.y, tq.ang + sway, tq.size * (0.6 + 0.4 * k), clamp01(k), tq.ph);
      }
    }

    /* ---- 花与 CPU 之间的细丝：沿路线再压一条极细的线，把花"吊"回 CPU ---- */
    drawThreads(g, tt, s);

    /* ---- 前置链：按技能顺序把花串起来 ---- */
    drawSkillChain(g, tt, s);

    /* ---- 脉冲：沿某条枝条从 CPU 往枝头跑 ---- */
    drawPulses(g, tt, s);

    /* ---- 金尘 ---- */
    g.globalCompositeOperation = 'lighter';
    for (var mi = 0; mi < S.motes.length; mi++) {
      var mo = S.motes[mi];
      var yy = mo.y - ((tt * mo.vy) % (h * 0.5));
      if (yy < S.canonTop - 40) yy += h * 0.5;
      var xx = mo.x + Math.sin(tt * mo.sp + mo.ph) * 9 * s;
      var aa = mo.a * (0.55 + 0.45 * Math.sin(tt * 1.7 + mo.ph));
      g.fillStyle = rgba(PAL.goldPale, aa * 0.55);
      g.beginPath(); g.arc(xx, yy, mo.r, 0, TAU); g.fill();
    }
    g.globalCompositeOperation = 'source-over';

    /* ---- 泛光：把画好的画面缩一半、模糊，再叠加回来 ----
     * 参考图那种"光会晕开"靠的就是这一层；不加的话所有线都是硬边矢量，看着干。
     */
    if (!BL.cv) { BL.cv = document.createElement('canvas'); BL.ctx = BL.cv.getContext('2d'); }
    var bw = Math.max(64, Math.floor(w * 0.5)), bh = Math.max(64, Math.floor(h * 0.5));
    if (BL.cv.width !== bw || BL.cv.height !== bh) { BL.cv.width = bw; BL.cv.height = bh; }
    BL.ctx.setTransform(1, 0, 0, 1, 0, 0);
    BL.ctx.globalCompositeOperation = 'copy';
    BL.ctx.drawImage(g.canvas, 0, 0, bw, bh);
    BL.ctx.globalCompositeOperation = 'source-over';
    g.save();
    g.globalCompositeOperation = 'lighter';
    g.globalAlpha = 0.62;
    g.filter = 'blur(4px)';
    g.drawImage(BL.cv, 0, 0, w, h);
    g.restore();

    /* ---- 暗角 ---- */
    var vg = g.createRadialGradient(S.cx, h * 0.50, Math.min(w, h) * 0.28, S.cx, h * 0.50, Math.max(w, h) * 0.80);
    vg.addColorStop(0, 'rgba(0,0,0,0)');
    vg.addColorStop(1, 'rgba(0,0,0,0.60)');
    g.fillStyle = vg;
    g.fillRect(0, 0, w, h);
  }

  /* ---- 风：整棵树按高度做水平偏移（越高摆得越大） ---- */
  function wind(p, tt) {
    var s = S.s;
    var hgt = clamp01((S.baseY - p.y) / (S.baseY - S.canonTop));
    var amp = Math.pow(hgt, 1.9) * 13 * s;
    return { x: p.x + Math.sin(tt * 0.52 + hgt * 1.9) * amp, y: p.y };
  }

  /* ---- 地面 ---- */
  function drawGround(g, tt, s) {
    var w = S.w, cx = S.cx;
    // 横线
    g.globalCompositeOperation = 'lighter';
    for (var i = 0; i < S.ground.length; i++) {
      var it = S.ground[i];
      if (it.kind === 'h') {
        var half = w * 0.62 * it.k;
        g.strokeStyle = rgba(PAL.cyan, it.a * 0.26);
        g.lineWidth = it.w * s;
        g.beginPath();
        g.moveTo(cx - half, it.y);
        g.lineTo(cx + half, it.y);
        g.stroke();
      } else if (it.kind === 'ray') {
        var half2 = w * 0.62;
        // 从消失点射到前缘
        g.strokeStyle = rgba(PAL.cyan, Math.max(0, it.a) * 0.32);
        g.lineWidth = it.w * s;
        g.beginPath();
        g.moveTo(it.vpX, it.vpY);
        g.lineTo(cx + it.uu * half2, S.baseY + 8);
        g.stroke();
      } else if (it.kind === 'node') {
        var pulse = 0.55 + 0.45 * Math.sin(tt * 1.6 + it.ph);
        g.fillStyle = rgba(PAL.cyan, it.a * pulse * 0.55);
        g.beginPath(); g.arc(it.x, it.y, it.r, 0, TAU); g.fill();
      } else if (it.kind === 'patch') {
        g.fillStyle = rgba(PAL.cyanSoft, it.a);
        g.beginPath();
        g.moveTo(it.x - it.w, it.y);
        g.lineTo(it.x, it.y - it.hh);
        g.lineTo(it.x + it.w, it.y);
        g.lineTo(it.x, it.y + it.hh);
        g.closePath(); g.fill();
      }
    }
    g.globalCompositeOperation = 'source-over';
  }

  /* ---- CPU ---- */
  function drawChip(g, tt, s) {
    var c = S.chip;
    var Cw = c.cw, Ch = c.ch, cx = c.cx, cy = c.cy;

    // 底板投光
    g.globalCompositeOperation = 'lighter';
    var gl = g.createRadialGradient(cx, cy, 0, cx, cy, Cw * 2.0);
    gl.addColorStop(0, 'rgba(120,220,255,0.10)');
    gl.addColorStop(0.45, 'rgba(80,160,255,0.035)');
    gl.addColorStop(1, 'rgba(0,0,0,0)');
    g.fillStyle = gl;
    g.beginPath(); g.arc(cx, cy, Cw * 2.0, 0, TAU); g.fill();
    g.globalCompositeOperation = 'source-over';

    // 厚度：下方两块侧面
    g.fillStyle = '#060b13';
    g.beginPath();
    g.moveTo(cx - Cw, cy); g.lineTo(cx, cy + Ch);
    g.lineTo(cx, cy + Ch + c.th); g.lineTo(cx - Cw, cy + c.th);
    g.closePath(); g.fill();
    g.beginPath();
    g.moveTo(cx + Cw, cy); g.lineTo(cx, cy + Ch);
    g.lineTo(cx, cy + Ch + c.th); g.lineTo(cx + Cw, cy + c.th);
    g.closePath(); g.fill();
    // 侧面铜线
    g.strokeStyle = rgba(PAL.goldDark, 0.55);
    g.lineWidth = 0.8 * s;
    for (var q = 0; q < 3; q++) {
      var qy = cy + Ch * 0.35 + q * c.th * 0.34;
      g.beginPath(); g.moveTo(cx - Cw + 6 * s, qy); g.lineTo(cx - 6 * s, qy + Ch * 0.55); g.stroke();
      g.beginPath(); g.moveTo(cx + Cw - 6 * s, qy); g.lineTo(cx + 6 * s, qy + Ch * 0.55); g.stroke();
    }

    // 顶面
    var tf = g.createLinearGradient(cx - Cw, cy - Ch, cx + Cw, cy + Ch);
    tf.addColorStop(0, '#16202f');
    tf.addColorStop(0.48, '#0d1622');
    tf.addColorStop(1, '#1a2333');
    g.fillStyle = tf;
    g.beginPath();
    g.moveTo(cx, cy - Ch); g.lineTo(cx + Cw, cy);
    g.lineTo(cx, cy + Ch); g.lineTo(cx - Cw, cy);
    g.closePath(); g.fill();

    // 顶面外框：冷光 + 一道细金边（金边是"这块是有工艺的芯片"的关键）
    g.strokeStyle = rgba(PAL.cyan, 0.62);
    g.lineWidth = 1.15 * s;
    g.stroke();
    g.strokeStyle = rgba(PAL.gold, 0.42);
    g.lineWidth = 0.7 * s;
    g.stroke();

    // 内 die
    var dw = Cw * 0.56, dh = Ch * 0.56;
    var dg = g.createLinearGradient(cx - dw, cy - dh, cx + dw, cy + dh);
    dg.addColorStop(0, '#0b1a28');
    dg.addColorStop(1, '#07121c');
    g.fillStyle = dg;
    g.beginPath();
    g.moveTo(cx, cy - dh); g.lineTo(cx + dw, cy);
    g.lineTo(cx, cy + dh); g.lineTo(cx - dw, cy);
    g.closePath(); g.fill();
    g.strokeStyle = rgba(PAL.cyan, 0.42);
    g.lineWidth = 0.8 * s;
    g.stroke();

    // die 里的电路纹理（斜向细线 + 小方块）
    g.save();
    g.beginPath();
    g.moveTo(cx, cy - dh); g.lineTo(cx + dw, cy);
    g.lineTo(cx, cy + dh); g.lineTo(cx - dw, cy);
    g.closePath(); g.clip();
    var rnd = mulberry32(77);
    g.strokeStyle = rgba(PAL.cyan, 0.42);
    g.lineWidth = 0.65 * s;
    for (var t1 = 0; t1 < 16; t1++) {
      var ox = (rnd() * 2 - 1) * dw, oy = (rnd() * 2 - 1) * dh;
      g.beginPath();
      g.moveTo(cx + ox, cy + oy);
      g.lineTo(cx + ox + (rnd() * 2 - 1) * 22 * s, cy + oy + (rnd() * 2 - 1) * 9 * s);
      g.stroke();
    }
    g.fillStyle = rgba(PAL.cyan, 0.55);
    for (var t2 = 0; t2 < 18; t2++) {
      var ox2 = (rnd() * 2 - 1) * dw * 0.85, oy2 = (rnd() * 2 - 1) * dh * 0.85;
      g.fillRect(cx + ox2, cy + oy2, 2.8 * s, 2.8 * s);
    }
    g.restore();

    // 核心光（冷白青），缓慢呼吸
    var corePulse = 0.78 + 0.22 * Math.sin(tt * 1.25);
    g.globalCompositeOperation = 'lighter';
    var cg = g.createRadialGradient(cx, cy, 0, cx, cy, Cw * 0.46);
    cg.addColorStop(0, 'rgba(226,252,255,' + (0.30 * corePulse).toFixed(3) + ')');
    cg.addColorStop(0.22, 'rgba(140,225,255,' + (0.13 * corePulse).toFixed(3) + ')');
    cg.addColorStop(1, 'rgba(60,140,220,0)');
    g.fillStyle = cg;
    g.beginPath(); g.arc(cx, cy, Cw * 0.46, 0, TAU); g.fill();
    g.fillStyle = 'rgba(240,252,255,' + (0.80 * corePulse).toFixed(3) + ')';
    g.beginPath(); g.arc(cx, cy, 2.4 * s, 0, TAU); g.fill();

    // 引脚
    for (var p = 0; p < c.pins.length; p++) {
      var pn = c.pins[p];
      g.strokeStyle = rgba(PAL.gold, 0.42 + pn.a * 0.22);
      g.lineWidth = 1.5 * s;
      g.beginPath(); g.moveTo(pn.x1, pn.y1); g.lineTo(pn.x2, pn.y2); g.stroke();
    }
    // 走线
    for (var tr = 0; tr < c.traces.length; tr++) {
      var tc = c.traces[tr];
      g.strokeStyle = rgba(PAL.cyan, tc.a * 0.55);
      g.lineWidth = tc.w;
      g.beginPath();
      g.moveTo(tc.pts[0].x, tc.pts[0].y);
      for (var v2 = 1; v2 < tc.pts.length; v2++) g.lineTo(tc.pts[v2].x, tc.pts[v2].y);
      g.stroke();
    }
    g.globalCompositeOperation = 'source-over';

    // 定位角：四个角上的小金点 + 一颗青色晶振点（CPU 那种"有 pin1 标记"的读法）
    for (var cc = 0; cc < 4; cc++) {
      var cq = c.corners[cc];
      var inx = (cq.x - cx) * 0.86 + cx, iny = (cq.y - cy) * 0.86 + cy;
      g.fillStyle = rgba(PAL.gold, 0.55);
      g.beginPath(); g.arc(inx, iny, 1.6 * s, 0, TAU); g.fill();
    }
    g.fillStyle = rgba(PAL.cyan, 0.70);
    g.beginPath(); g.arc(cx - Cw * 0.15, cy - Ch * 0.12, 2.4 * s, 0, TAU); g.fill();
  }

  /* ---- 根：几何神话风 —— 只留六条粗根，绕过芯片把它"包住" ----
   * 用户 2026-11-02：「把 cpu 改成树根包裹住 cpu」「这树根太密了」。
   * 所以不再是十几条放射的板根，而是左右各三条：从基部下来 → 跨过芯片左右角 →
   * 在芯片前缘翻下去（下面画阴影），看起来是把芯片抱在根里。
   */
  function drawRoots(g, tt, s) {
    var c = S.chip, cx = c.cx, cy = c.cy;
    var base = S.trunk.pts[9];
    var i, k;

    for (i = 0; i < 6; i++) {
      var side = i < 3 ? -1 : 1;
      var idx = i % 3;
      var spread = 0.34 + idx * 0.30;               // 每侧三条，由内往外
      var pts = [], ws = [];
      var segs = 18;
      var sx = cx + side * S.trunk.radii[9] * 0.92;
      var sy = base.y - 2 * s;
      // 终点：芯片前缘外侧（翻到板子下面去）
      var ex = cx + side * c.cw * (0.72 + 0.16 * idx);
      var ey = cy + c.ch * (0.40 + 0.20 * idx) + (0 + idx * 2) * s;
      for (k = 0; k <= segs; k++) {
        var u = k / segs;
        // 先贴着树干外侧下来，再向外弯（绕过芯片的角）
        var bow = Math.sin(u * Math.PI) * side * (spread * 26) * s;
        pts.push({
          x: sx + (ex - sx) * Math.pow(u, 0.85) + bow,
          y: sy + (ey - sy) * Math.pow(u, 0.78)
        });
        ws.push((28 - 24 * Math.pow(u, 0.55)) * s);
      }

      // 跨过芯片顶面时压一道暗影，读出"根在上面"的层次
      g.save();
      g.strokeStyle = 'rgba(0,0,0,0.34)';
      g.lineWidth = Math.max(2, 14 * s);
      g.beginPath();
      for (k = 0; k <= segs; k++) {
        var u0 = k / segs;
        if (u0 < 0.30) continue;
        if (k === 0) g.moveTo(pts[k].x, pts[k].y + 5 * s); else g.lineTo(pts[k].x, pts[k].y + 5 * s);
      }
      g.stroke();
      g.restore();

      tube(g, pts, ws, {
        body: 'rgba(24,17,8,0.96)',
        mid: 'rgba(148,118,70,0.97)',
        core: rgba(PAL.goldPale, 0.10),
        glow: false
      });

      // 受光侧一条细亮棱（几何风：只一道，不做明暗层次）
      g.save();
      g.strokeStyle = 'rgba(255,240,204,0.30)';
      g.lineWidth = Math.max(0.5, 1.1 * s);
      g.beginPath();
      for (k = 0; k <= segs; k++) {
        var lx = pts[k].x - side * ws[k] * 0.30;
        if (k === 0) g.moveTo(lx, pts[k].y); else g.lineTo(lx, pts[k].y);
      }
      g.stroke();
      g.restore();

      // 前缘翻下去：一道短弧 + 更深的阴影，暗示根绕到板子底下
      var tail = pts[segs];
      g.save();
      g.strokeStyle = 'rgba(8,6,4,0.55)';
      g.lineWidth = Math.max(2, 8 * s);
      g.beginPath();
      g.moveTo(tail.x, tail.y);
      g.quadraticCurveTo(tail.x + side * 6 * s, tail.y + 9 * s, tail.x + side * 10 * s, tail.y + 4 * s);
      g.stroke();
      g.restore();
    }

    // 芯片被根勒住的地方：两条很淡的环
    g.save();
    g.strokeStyle = 'rgba(255,232,170,0.13)';
    g.lineWidth = Math.max(0.6, 0.9 * s);
    g.beginPath();
    g.ellipse ? g.ellipse(cx, cy + c.ch * 0.18, c.cw * 1.02, c.ch * 0.98, 0, 0, TAU)
              : g.arc(cx, cy + c.ch * 0.18, c.cw, 0, TAU);
    g.stroke();
    g.restore();
  }

  /* ---- 主干：几何神话风（只留外形，不画写实的木纹/绞股） ----
   * 用户 2026-11-02：「整个树也是机械的」「树干只需要参考外形，内部不用画那么真实，
   * 就跟神话故事那种绘画风格一般」。所以这里只有：干净的剪影 + 一条亮边 + 几道刻面线 +
   * 几道机械环箍 + 内部一条竖向透光带。不做 13 根绞股，也不做写实木纹。
   */
  function drawTrunk(g, tt, s) {
    var tr = S.trunk, pts = tr.pts, radii = tr.radii, N = tr.N;
    var j;

    function columnPath(scaleW) {
      var L = [], R = [];
      for (var q = 0; q <= N; q++) {
        var p = pts[q];
        var a1 = pts[Math.min(N, q + 1)], a0 = pts[Math.max(0, q - 1)];
        var tx = a1.x - a0.x, ty = a1.y - a0.y;
        var tl = Math.hypot(tx, ty) || 1; tx /= tl; ty /= tl;
        var wq = radii[q] * (scaleW == null ? 1 : scaleW);
        L.push({ x: p.x - ty * wq, y: p.y + tx * wq });
        R.push({ x: p.x + ty * wq, y: p.y - tx * wq });
      }
      g.beginPath();
      g.moveTo(L[0].x, L[0].y);
      for (var q2 = 1; q2 <= N; q2++) g.lineTo(L[q2].x, L[q2].y);
      for (var q3 = N; q3 >= 0; q3--) g.lineTo(R[q3].x, R[q3].y);
      g.closePath();
      return { L: L, R: R };
    }

    // ① 剪影：暗底
    columnPath(1.0);
    g.fillStyle = 'rgba(34,26,14,0.96)';
    g.fill();

    // ② 柱身：竖向暖白渐变（上亮下暖），横向不收边 —— 只靠亮边勾形
    var topP = pts[N], botP = pts[0];
    var bodyGrad = g.createLinearGradient(botP.x, botP.y, topP.x, topP.y);
    bodyGrad.addColorStop(0.00, 'rgba(120,92,48,0.98)');
    bodyGrad.addColorStop(0.30, 'rgba(176,148,100,0.98)');
    bodyGrad.addColorStop(0.68, 'rgba(190,172,134,0.99)');
    bodyGrad.addColorStop(1.00, 'rgba(212,198,164,0.99)');
    var edges = columnPath(0.97);
    g.fillStyle = bodyGrad;
    g.fill();

    // ③ 内部竖向透光带（一条就够，代表"光从干里透出来"）
    g.save();
    columnPath(0.97);
    g.clip();
    var beam = g.createLinearGradient(botP.x - 10 * s, 0, botP.x + 10 * s, 0);
    beam.addColorStop(0.00, 'rgba(255,246,222,0)');
    beam.addColorStop(0.45, 'rgba(255,250,238,0.15)');
    beam.addColorStop(0.55, 'rgba(255,250,238,0.15)');
    beam.addColorStop(1.00, 'rgba(255,246,222,0)');
    g.fillStyle = beam;
    g.fillRect(0, topP.y - 10, S.w, botP.y - topP.y + 20);
    // ④ 刻面线：4 条纵向细线（不是木纹，是"刻出来的棱"）
    g.strokeStyle = 'rgba(255,248,226,0.20)';
    g.lineWidth = Math.max(0.5, 0.8 * s);
    for (var f = 0; f < 4; f++) {
      var fx = (f / 3 - 0.5) * 1.5;
      g.beginPath();
      for (var q4 = 0; q4 <= N; q4++) {
        var p4 = pts[q4];
        var xx = p4.x + fx * radii[q4] * 0.42;
        if (q4 === 0) g.moveTo(xx, p4.y); else g.lineTo(xx, p4.y);
      }
      g.stroke();
    }
    g.restore();

    // ⑤ 亮边：一条 1.1px 的金白描边，勾出剪影（风格契约：线要细、要亮）
    columnPath(1.0);
    g.strokeStyle = 'rgba(255,232,170,0.50)';
    g.lineWidth = Math.max(0.8, 1.1 * s);
    g.stroke();

    // ⑥ 机械环箍：4 道很细的椭圆环 + 小菱形节点（神话/机械的那口气）
    for (var b = 0; b < 4; b++) {
      var u0 = 0.18 + b * 0.21;
      var qi = Math.round(u0 * N);
      var pp = pts[qi], rr = radii[qi];
      g.save();
      g.translate(pp.x, pp.y);
      g.scale(1, 0.24);
      g.strokeStyle = 'rgba(255,238,196,' + (0.52 - b * 0.06).toFixed(3) + ')';
      g.lineWidth = Math.max(1.0, 1.5 * s);
      g.beginPath(); g.arc(0, 0, rr * 1.02, 0, TAU); g.stroke();
      g.strokeStyle = 'rgba(255,246,222,0.16)';
      g.beginPath(); g.arc(0, 0, rr * 0.80, 0, TAU); g.stroke();
      g.restore();
      // 环上的小菱形
      g.fillStyle = 'rgba(255,232,170,0.75)';
      g.save();
      g.translate(pp.x, pp.y);
      g.rotate(Math.PI / 4);
      g.fillRect(-1.6 * s, -1.6 * s, 3.2 * s, 3.2 * s);
      g.restore();
    }

    // ⑦ 底部根盘的一点点暖光（收口用）
    g.globalCompositeOperation = 'lighter';
    var bg = g.createRadialGradient(botP.x, botP.y, 0, botP.x, botP.y, s * 80);
    bg.addColorStop(0, 'rgba(255,226,172,0.12)');
    bg.addColorStop(1, 'rgba(255,186,100,0)');
    g.fillStyle = bg;
    g.beginPath(); g.arc(botP.x, botP.y, s * 80, 0, TAU); g.fill();
    g.globalCompositeOperation = 'source-over';
  }

  /* ---- 晶体碎片：直接搬记忆脑图那套（四角抖动四边形 + 虹彩渐变 + 热白边） ---- */
  function crystal(g, x, y, size, ang, hue, alpha) {
    g.save();
    g.translate(x, y); g.rotate(ang);
    var w = size * 0.42, h = size * 0.62;
    var j0 = 1 + 0.10 * Math.sin(ang * 3.1);
    var j1 = 1 + 0.10 * Math.cos(ang * 2.3);
    g.beginPath();
    g.moveTo(0, -h * j0);
    g.lineTo(w * j1, -h * 0.10);
    g.lineTo(0, h * 0.92);
    g.lineTo(-w * j1, -h * 0.10);
    g.closePath();
    var gr = g.createLinearGradient(-w, -h, w, h);
    var sat = hue > 120 ? 58 : 82;
    gr.addColorStop(0.00, 'hsla(' + (hue - 14) + ',' + sat + '%,58%,' + (0.86 * alpha).toFixed(3) + ')');
    gr.addColorStop(0.45, 'hsla(' + (hue + 6) + ',' + sat + '%,66%,' + (0.90 * alpha).toFixed(3) + ')');
    gr.addColorStop(1.00, 'hsla(' + (hue + 34) + ',' + (sat - 10) + '%,74%,' + (0.82 * alpha).toFixed(3) + ')');
    g.fillStyle = gr;
    g.fill();
    // 暗边垫底：这一步是"玻璃感"的关键，没有它就只是一块不透明色片
    g.strokeStyle = 'rgba(8,11,20,' + (0.55 * Math.min(1, alpha * 1.7)).toFixed(3) + ')';
    g.lineWidth = Math.max(0.8, size * 0.11);
    g.stroke();
    g.strokeStyle = 'rgba(255,246,224,' + (0.72 * alpha).toFixed(3) + ')';
    g.lineWidth = Math.max(0.42, size * 0.048);
    g.stroke();
    g.beginPath(); g.moveTo(0, -h * j0); g.lineTo(0, h * 0.9);
    g.strokeStyle = 'rgba(255,248,226,' + (0.18 * alpha).toFixed(3) + ')';
    g.lineWidth = Math.max(0.3, size * 0.03);
    g.stroke();
    g.restore();
  }

  /* ---- 冠部：不再是"叶片"，改成成簇的晶体碎片（这才是记忆脑图的画风） ---- */
  function drawLeafCluster(g, x, y, ang, size, k, ph) {
    var n = 2;
    for (var i = 0; i < n; i++) {
      var t = n > 1 ? (i / (n - 1) - 0.5) : 0;
      var a = ang + t * 1.9 + Math.sin(ph + i) * 0.18;
      var L = size * (1.65 + 0.45 * Math.sin(ph * 2.7 + i));
      var cool = ((i + Math.round(ph * 3)) % 5) === 0;
      var hue = cool ? 252 : 44;
      crystal(g, x + Math.cos(a) * L * 0.30, y + Math.sin(a) * L * 0.30, L * 1.25, a, hue, 0.52 * k);
    }
  }

  /* ---- 半机械花：郁金香结构（外 3 瓣 + 内 3 瓣错开 60°），花心是齿轮 ---- */
  function drawFlower(g, x, y, ang, R, k, tt, ph, hero) {
    if (R < 2.2) return;
    g.save();
    g.translate(x, y);
    g.rotate(ang + Math.PI / 2 + Math.PI);   // 花心朝外、花萼朝枝

    var pulse = 0.84 + 0.16 * Math.sin(tt * 1.1 + ph);

    // 花照亮周围的枝：内层是花瓣自己的光，外层很大很淡，
    // 让花"被染进"枝条里（没有这层，花像贴上去的贴纸）
    g.globalCompositeOperation = 'lighter';
    var gr = g.createRadialGradient(0, 0, 0, 0, 0, R * 1.9);
    gr.addColorStop(0, 'rgba(255,214,140,' + (0.15 * k * pulse).toFixed(3) + ')');
    gr.addColorStop(0.45, 'rgba(255,180,90,' + (0.05 * k * pulse).toFixed(3) + ')');
    gr.addColorStop(1, 'rgba(255,160,60,0)');
    g.fillStyle = gr;
    g.beginPath(); g.arc(0, 0, R * 1.9, 0, TAU); g.fill();
    var gr2 = g.createRadialGradient(0, 0, 0, 0, 0, R * 4.2);
    gr2.addColorStop(0, 'rgba(255,206,132,' + (0.055 * k * pulse).toFixed(3) + ')');
    gr2.addColorStop(0.5, 'rgba(255,178,92,' + (0.022 * k * pulse).toFixed(3) + ')');
    gr2.addColorStop(1, 'rgba(255,150,60,0)');
    g.fillStyle = gr2;
    g.beginPath(); g.arc(0, 0, R * 4.2, 0, TAU); g.fill();
    g.globalCompositeOperation = 'source-over';

    // 外层 3 瓣（暗金，长）
    for (var i = 0; i < 3; i++) {
      g.save(); g.rotate(i * TAU / 3); petal(g, R, false); g.restore();
    }
    // 内层 3 瓣（亮金，短、错开 60°）—— 这就是郁金香那种层叠
    for (var i2 = 0; i2 < 3; i2++) {
      g.save(); g.rotate(i2 * TAU / 3 + TAU / 6); petal(g, R * 0.76, true); g.restore();
    }

    /* --- 齿轮花心：轮廓齿轮（齿浅、只读形状），不是写实机械 --- */
    var gearR = R * 0.40;
    var teeth = 10;
    g.beginPath();
    for (var d = 0; d < teeth; d++) {
      var b0 = d / teeth * TAU;
      var b1 = (d + 0.30) / teeth * TAU;
      var b2 = (d + 0.62) / teeth * TAU;
      var b3 = (d + 0.92) / teeth * TAU;
      g.lineTo(Math.cos(b0) * gearR * 0.86, Math.sin(b0) * gearR * 0.86);
      g.lineTo(Math.cos(b1) * gearR, Math.sin(b1) * gearR);
      g.lineTo(Math.cos(b2) * gearR, Math.sin(b2) * gearR);
      g.lineTo(Math.cos(b3) * gearR * 0.86, Math.sin(b3) * gearR * 0.86);
    }
    g.closePath();
    g.fillStyle = 'rgba(30,21,10,0.88)';
    g.fill();
    g.strokeStyle = rgba(PAL.gold, 0.78);
    g.lineWidth = Math.max(0.55, R * 0.035);
    g.stroke();

    // 齿轮内环 + 六根辐条（机械感靠它，不靠齿牙）
    g.beginPath(); g.arc(0, 0, gearR * 0.58, 0, TAU);
    g.fillStyle = 'rgba(18,13,7,0.9)'; g.fill();
    g.strokeStyle = rgba(PAL.goldPale, 0.42);
    g.lineWidth = Math.max(0.4, R * 0.022);
    g.stroke();
    g.beginPath();
    for (var sp = 0; sp < 6; sp++) {
      var sa = sp / 6 * TAU;
      g.moveTo(Math.cos(sa) * gearR * 0.16, Math.sin(sa) * gearR * 0.16);
      g.lineTo(Math.cos(sa) * gearR * 0.54, Math.sin(sa) * gearR * 0.54);
    }
    g.strokeStyle = rgba(PAL.gold, 0.34);
    g.stroke();

    // LED 芯：小小一颗，不要烧成太阳
    g.globalCompositeOperation = 'lighter';
    var cg = g.createRadialGradient(0, 0, 0, 0, 0, gearR * 0.55);
    cg.addColorStop(0, 'rgba(255,252,236,' + (0.92 * k * pulse).toFixed(3) + ')');
    cg.addColorStop(0.34, 'rgba(255,226,160,' + (0.42 * k * pulse).toFixed(3) + ')');
    cg.addColorStop(1, 'rgba(255,180,80,0)');
    g.fillStyle = cg;
    g.beginPath(); g.arc(0, 0, gearR * 0.55, 0, TAU); g.fill();
    g.fillStyle = 'rgba(255,255,250,' + (0.82 * k).toFixed(3) + ')';
    g.beginPath(); g.arc(0, 0, Math.max(0.5, R * 0.055), 0, TAU); g.fill();
    g.globalCompositeOperation = 'source-over';

    // 花萼：两片小金属片夹住枝头
    g.strokeStyle = rgba(PAL.goldDark, 0.85);
    g.lineWidth = Math.max(0.6, R * 0.055);
    g.beginPath();
    g.moveTo(-R * 0.30, R * 0.22); g.lineTo(0, R * 0.50); g.lineTo(R * 0.30, R * 0.22);
    g.stroke();

    // 花瓣根部的银色焊点（#D8D8D8）—— 机械感最省成本的一笔
    if (R > 5.5) {
      g.fillStyle = 'rgba(216,216,216,' + (0.55 * k).toFixed(3) + ')';
      for (var sv = 0; sv < 3; sv++) {
        var sva = TAU / 3 * sv + 0.5;
        g.beginPath();
        g.arc(Math.cos(sva) * R * 0.30, Math.sin(sva) * R * 0.30, Math.max(0.45, R * 0.045), 0, TAU);
        g.fill();
      }
    }

    if (hero) {
      // 主角花：一圈很细的刻线环，远看是个亮点，近看有工艺
      g.strokeStyle = rgba(PAL.goldPale, 0.26);
      g.lineWidth = Math.max(0.45, R * 0.022);
      g.beginPath(); g.arc(0, 0, R * 1.20, 0, TAU); g.stroke();
    }
    g.restore();
  }

  function petal(g, R, inner) {
    var w = R * 0.34;
    g.beginPath();
    g.moveTo(0, R * 0.12);
    g.bezierCurveTo(-w, -R * 0.18, -w * 1.06, -R * 0.86, 0, -R * 1.02);
    g.bezierCurveTo(w * 1.06, -R * 0.86, w, -R * 0.18, 0, R * 0.12);
    g.closePath();
    var grd = g.createLinearGradient(0, R * 0.12, 0, -R * 1.02);
    if (inner) {
      grd.addColorStop(0, 'rgba(92,60,20,0.92)');
      grd.addColorStop(0.50, 'rgba(198,152,88,0.92)');
      grd.addColorStop(1, 'rgba(255,232,170,0.96)');
    } else {
      grd.addColorStop(0, 'rgba(58,38,14,0.92)');
      grd.addColorStop(0.55, 'rgba(146,104,50,0.90)');
      grd.addColorStop(1, 'rgba(212,164,74,0.86)');
    }
    g.fillStyle = grd;
    g.fill();
    // 亮边
    g.strokeStyle = inner ? 'rgba(255,236,186,0.62)' : 'rgba(255,226,160,0.32)';
    g.lineWidth = Math.max(0.45, R * 0.026);
    g.stroke();
    // 中脊亮棱 + 两侧暗槽（金属折面）
    g.beginPath(); g.moveTo(0, R * 0.06); g.lineTo(0, -R * 0.94);
    g.strokeStyle = 'rgba(255,246,214,' + (inner ? 0.30 : 0.15) + ')';
    g.lineWidth = Math.max(0.35, R * 0.020);
    g.stroke();
    g.beginPath();
    g.moveTo(-w * 0.52, -R * 0.12); g.lineTo(-w * 0.16, -R * 0.80);
    g.moveTo(w * 0.52, -R * 0.12); g.lineTo(w * 0.16, -R * 0.80);
    g.strokeStyle = 'rgba(42,27,10,0.30)';
    g.stroke();
  }

  /* ---- 脉冲 ---- */
  var pulses = [];
  var lastPulse = 0;
  function drawPulses(g, tt, s) {
    if (!S.routes.length) return;
    if (tt - lastPulse > 0.62) {
      lastPulse = tt;
      var ri = Math.floor(Math.random() * S.routes.length);
      pulses.push({ route: S.routes[ri], t0: tt, dur: 2.1 + Math.random() * 1.1, hue: Math.random() < 0.22 ? PAL.cyan : PAL.gold });
      if (pulses.length > 9) pulses.shift();
    }
    g.globalCompositeOperation = 'lighter';
    for (var i = pulses.length - 1; i >= 0; i--) {
      var p = pulses[i];
      var u = (tt - p.t0) / p.dur;
      if (u > 1) { pulses.splice(i, 1); continue; }
      if (u < 0) continue;
      var rp = p.route;
      var idx = Math.min(rp.length - 1, Math.floor(u * (rp.length - 1)));
      var pt = wind(rp[idx], tt);
      var fade = Math.sin(u * Math.PI);
      var rad = 2.4 * s;
      var gr = g.createRadialGradient(pt.x, pt.y, 0, pt.x, pt.y, rad * 6);
      gr.addColorStop(0, rgba(p.hue, 0.75 * fade));
      gr.addColorStop(0.35, rgba(p.hue, 0.20 * fade));
      gr.addColorStop(1, rgba(p.hue, 0));
      g.fillStyle = gr;
      g.beginPath(); g.arc(pt.x, pt.y, rad * 6, 0, TAU); g.fill();
      g.fillStyle = rgba(PAL.goldPale, 0.9 * fade);
      g.beginPath(); g.arc(pt.x, pt.y, rad * 0.55, 0, TAU); g.fill();
    }
    g.globalCompositeOperation = 'source-over';
  }

  /* ---- 前置链：按技能序号把相邻的两朵花用丝串起来（越前越基础）---- */
  function drawSkillChain(g, tt, s) {
    loadDeps();
    var fl = [];
    var bySeq = {}, byId = {};
    for (var i = 0; i < S.tips.length; i++) {
      var t0 = S.tips[i];
      if (!t0.flower || t0.seq < 0) continue;
      if (!S.routes[i] || S.routes[i].length < 2) continue;
      fl.push({ i: i, seq: t0.seq, born: 0.9 + t0.delay });
      bySeq[t0.seq] = i;
      if (SKILL_ORDER) byId[SKILL_ORDER[t0.seq % SKILL_ORDER.length]] = i;
    }
    if (!fl.length) return;

    function routePt(idx, k) {
      var r = S.routes[idx];
      var p = r[Math.max(0, Math.min(r.length - 1, k))];
      return wind(p, tt);
    }
    function commonPrefix(ra, rb) {
      var n = Math.min(ra.length, rb.length), k = 0;
      while (k < n && Math.abs(ra[k].x - rb[k].x) < 0.6 && Math.abs(ra[k].y - rb[k].y) < 0.6) k++;
      return Math.max(1, k);
    }
    function link(iA, iB, bornA, bornB, shade) {
      var ra = S.routes[iA], rb = S.routes[iB];
      var app = clamp01((tt - Math.max(bornA, bornB)) / 1.1);
      if (app <= 0) return;
      var kx = commonPrefix(ra, rb);
      var pa = routePt(iA, ra.length - 1), pb = routePt(iB, rb.length - 1);
        g.strokeStyle = 'rgba(255,242,214,' + Math.min(1, shade * 1.15 * app).toFixed(3) + ')';
      g.lineWidth = 1.05;
      g.beginPath();
      g.moveTo(pa.x, pa.y);
      for (var d1 = ra.length - 2; d1 >= kx; d1 -= 1) { var p1 = routePt(iA, d1); g.lineTo(p1.x, p1.y); }
      for (var d2 = kx; d2 < rb.length; d2++) { var p2 = routePt(iB, d2); g.lineTo(p2.x, p2.y); }
      g.stroke();
    }

    g.save();
    g.lineCap = 'round';
    g.lineJoin = 'round';

    // ① 真实前置关系：child 的丝连到它所有前置
    var used = 0;
    if (DEPS && SKILL_ORDER) {
      Object.keys(DEPS).forEach(function (childId) {
        var ci = byId[childId];
        if (ci == null) return;
        (DEPS[childId] || []).forEach(function (parentId) {
          var pi = byId[parentId];
          if (pi == null) return;
          var a = null, b = null;
          for (var q = 0; q < fl.length; q++) {
            if (fl[q].i === ci) a = fl[q];
            if (fl[q].i === pi) b = fl[q];
          }
          if (!a || !b) return;
          link(ci, pi, a.born, b.born, 0.55);
          used++;
        });
      });
    }

    // ② 没有依赖数据（或用了 0 条）时，退回顺序链
    if (!used) {
      fl.sort(function (a, b) { return a.seq - b.seq; });
      for (var q2 = 0; q2 + 1 < fl.length; q2++) {
        link(fl[q2].i, fl[q2 + 1].i, fl[q2].born, fl[q2 + 1].born, 0.45);
      }
    }
    g.restore();
  }

  /* ---- 晶体云：把 S.shards 画成一片发光晶体（四角星 + 菱形两种） ---- */
  function drawCrystalCloud(g, tt, s) {
    var list = S.shards;
    if (!list || !list.length) return;
    g.save();
    g.globalCompositeOperation = 'lighter';
    for (var i = 0; i < list.length; i++) {
      var sh = list[i];
      var w = wind(sh, tt);
      var tw = 0.72 + 0.28 * Math.sin(tt * 1.3 + sh.ph);
      var sz = sh.size * (0.85 + 0.25 * tw);
      var warm = sh.hue < 120;
      g.fillStyle = warm
        ? 'hsla(42,88%,' + (64 + 16 * tw).toFixed(0) + '%,' + (0.62 * tw).toFixed(3) + ')'
        : 'hsla(252,62%,74%,' + (0.50 * tw).toFixed(3) + ')';
      if (sz > 3.2) {
        // 四角星（朝露那种星芒）
        var k = sz * 1.9, m = sz * 0.34;
        g.beginPath();
        g.moveTo(w.x, w.y - k);
        g.lineTo(w.x + m, w.y - m);
        g.lineTo(w.x + k, w.y);
        g.lineTo(w.x + m, w.y + m);
        g.lineTo(w.x, w.y + k);
        g.lineTo(w.x - m, w.y + m);
        g.lineTo(w.x - k, w.y);
        g.lineTo(w.x - m, w.y - m);
        g.closePath();
        g.fill();
      } else {
        // 小菱形
        var d = sz * 1.25;
        g.beginPath();
        g.moveTo(w.x, w.y - d);
        g.lineTo(w.x + d * 0.72, w.y);
        g.lineTo(w.x, w.y + d);
        g.lineTo(w.x - d * 0.72, w.y);
        g.closePath();
        g.fill();
      }
      // 大的再点一颗白心
      if (sz > 5.2) {
        g.fillStyle = 'rgba(255,252,240,' + (0.55 * tw).toFixed(3) + ')';
        g.beginPath(); g.arc(w.x, w.y, sz * 0.22, 0, TAU); g.fill();
      }
    }
    g.restore();
  }

  /* ---- 细丝：花 → 沿路线 → CPU ---- */
  function drawThreads(g, tt, s) {
    g.save();
    g.lineCap = 'round';
    g.lineJoin = 'round';
    g.strokeStyle = 'rgba(255,228,176,0.26)';
    g.lineWidth = 0.7;
    for (var i = 0; i < S.tips.length; i++) {
      var tp = S.tips[i];
      if (!tp.flower) continue;
      var route = S.routes[i];
      if (!route || route.length < 2) continue;
      var app = clamp01((tt - 1.1 - tp.delay) / 1.4);
      if (app <= 0) continue;
      var cnt = Math.max(2, Math.floor(route.length * app));
      g.beginPath();
      for (var k = 0; k < cnt; k++) {
        var p = wind(route[k], tt);
        if (k === 0) g.moveTo(p.x, p.y); else g.lineTo(p.x, p.y);
      }
      g.stroke();
    }
    g.restore();
  }

  /* ---- 技能数据：给花挂上名字/简介（点花时用） ---- */
  function fetchSkills(cb) {
    if (SKILL_CACHE) { cb(SKILL_CACHE); return; }
    try {
      fetch('/api/skills').then(function (r) { return r.json(); }).then(function (d) {
        SKILL_CACHE = (d && d.skills) ? d.skills : [];
        cb(SKILL_CACHE);
      }).catch(function () { SKILL_CACHE = []; cb(SKILL_CACHE); });
    } catch (e) { SKILL_CACHE = []; cb(SKILL_CACHE); }
  }

  function showSkillTip(sk, x, y, extra) {
    var el = document.getElementById('nodetip');
    if (!el) return;
    var dot = document.getElementById('ntDot'), lv = document.getElementById('ntLv');
    var imp = document.getElementById('ntImp'), ti = document.getElementById('ntTitle');
    var ex = document.getElementById('ntEx'), mt = document.getElementById('ntMeta');
    if (dot) dot.style.color = '#ffd88a';
    if (lv) lv.textContent = '技能 · 光缆树';
    if (imp) imp.textContent = '';
    if (ti) ti.textContent = sk.name || sk.title || sk.id || '(未命名技能)';
    var d = String(sk.description || sk.desc || '').replace(/\s+/g, ' ').trim();
    if (ex) ex.textContent = (d ? (d.length > 150 ? d.slice(0, 150) + '…' : d) : '（这个技能没有写简介）') + (extra || '');
    if (mt) mt.innerHTML = '';
    el.style.left = Math.max(10, Math.min(window.innerWidth - 340, x + 16)) + 'px';
    el.style.top = Math.max(10, Math.min(window.innerHeight - 40, y - 8)) + 'px';
    el.classList.add('show');
  }

  function hideSkillTip() {
    var el = document.getElementById('nodetip');
    if (el) el.classList.remove('show');
  }

  /* ---- 左键点花：选中 + 显示名字/简介（技能数据来自 /api/skills） ---- */
  function hitAt(x, y) {
    var best = null, bestD = 1e9;
    for (var i = 0; i < FLOWER_HITS.length; i++) {
      var h = FLOWER_HITS[i];
      var d = Math.hypot(h.x - x, h.y - y);
      if (d < h.r && d < bestD) { bestD = d; best = h; }
    }
    return best;
  }

  function clickAt(x, y) {
    var best = null, bestD = 1e9;
    for (var i = 0; i < FLOWER_HITS.length; i++) {
      var h = FLOWER_HITS[i];
      var d = Math.hypot(h.x - x, h.y - y);
      if (d < h.r && d < bestD) { bestD = d; best = h; }
    }
    if (!best) { PICKED = -1; hideSkillTip(); return false; }
    PICKED = best.i;
    FLASH = 1;
    var idx = (best.seq != null && best.seq >= 0) ? best.seq : best.i;
    loadDeps();
    var sid = skillIdOfSeq(idx);
    var st = stateOf(sid);
    var sk = skillOfSeq(idx);
    if (sk) {
      var extra = '';
      if (PARTS_LOADED) {
        var pn = PARTS[sid] || 0;
        var dd = PARTS_DIST[sid] || {};
        if (st === 'on') {
          extra = '（零件 ' + pn + ' 个 · 感 ' + (dd.sense || 0) + ' / 思 ' + (dd.think || 0) + ' / 实 ' + (dd.act || 0) + '）';
        } else {
          extra = '（零件 ' + pn + '/' + UNLOCK_PARTS + '）｜怎么解锁：把这门技能的 SKILL.md 拆成 ≥' + UNLOCK_PARTS +
                  ' 个可执行零件（感知/思索/实践），重新生成 organs/parts.json，下次打开就会亮。给大肥鱼们的备注：没拆够之前别假装会用，照着零件做一步算一步。';
        }
      } else if (st === 'ready') {
        extra = '（可解锁）';
      }
      showSkillTip(sk, best.x, best.y, extra);
    }
    else fetchSkills(function (list) {
      var s2 = (list && list.length) ? list[idx % list.length] : null;
      showSkillTip(s2 || { name: '技能 #' + (idx + 1), description: '（还没读到技能列表）' }, best.x, best.y);
    });
    return true;
  }

  /* ---- 悬停：高亮 + 名字/简介 ---- */
  function hoverAt(x, y) {
    var h = hitAt(x, y);
    HOVERED = h ? h.i : -1;
    if (h) {
      var idx = (h.seq != null && h.seq >= 0) ? h.seq : h.i;
      loadDeps();
      var sid = skillIdOfSeq(idx);
      var st = stateOf(sid);
      var sk = skillOfSeq(idx);
      if (sk) showSkillTip(sk, h.x, h.y, st === 'locked' ? '（前置未解锁）' : (st === 'ready' ? '（可解锁）' : ''));
    } else {
      hideSkillTip();
    }
    return !!h;
  }

  /* ---- 左侧小技能树：按前置关系缩进列出，点一行跳到那朵花 ---- */
  var panelEl = null;
  function buildPanel() {
    if (panelEl) return panelEl;
    panelEl = document.createElement('div');
    panelEl.id = 'treeSkillPanel';
    panelEl.style.cssText = [
      'position:fixed', 'left:18px', 'top:132px', 'width:224px', 'max-height:62vh',
      'overflow:auto', 'z-index:9', 'padding:10px 10px 12px',
      'border-radius:10px', 'background:rgba(6,12,22,0.72)',
      'border:1px solid rgba(143,227,255,0.16)',
      'backdrop-filter:blur(6px)', 'font:11.5px/1.5 "Microsoft YaHei UI",system-ui',
      'color:#b8c9dc', 'display:none'
    ].join(';');
    document.body.appendChild(panelEl);
    return panelEl;
  }

  function renderPanel() {
    var el = buildPanel();
    if (!SKILL_ORDER) return;
    var rows = SKILL_ORDER.slice(0, 30).map(function (id) {
      var st = stateOf(id);
      var sk = SKILL_BY_ID[id] || {};
      return { id: id, st: st, name: sk.name || id };
    });
    var html = '<div style="font-size:11px;color:#8fe3ff;letter-spacing:.08em;margin-bottom:6px">技能树 · 点一行跳到花</div>';
    html += '<div style="font-size:10px;color:#5f7590;margin-bottom:6px">亮=零件≥4（真的会）　青=零件不够</div>' +
      '<div style="font-size:10px;color:#3f6376;margin-bottom:8px;line-height:1.5">给大肥鱼们的解锁说明：把青色那条的 SKILL.md 拆成 ≥4 个可执行零件（感知/思索/实践），重跑 organs 的拆解，再回来就亮了。</div>';
    rows.forEach(function (r) {
      var c = r.st === 'on' ? '#ffe8aa' : (r.st === 'ready' ? '#8fe3ff' : '#4d7f96');
      var dep = (DEPS && DEPS[r.id] && DEPS[r.id].length) ? DEPS[r.id].join('·') : '';
      html += '<div data-skill="' + r.id + '" style="padding:3px 4px;border-radius:5px;cursor:pointer;color:' + c +
        ';white-space:nowrap;overflow:hidden;text-overflow:ellipsis" title="' + (dep ? ('前置：' + dep) : '根技能') + '">' +
        (r.st === 'on' ? '●' : (r.st === 'ready' ? '◐' : '○')) + ' ' + r.name +
        '<span style="float:right;color:#4d7f96">' + ((PARTS[r.id] || 0) || '') + '</span></div>';
    });
    el.innerHTML = html;
    Array.prototype.forEach.call(el.querySelectorAll('[data-skill]'), function (row) {
      row.onclick = function () { focusSkill(row.getAttribute('data-skill')); };
    });
  }

  function focusSkill(id) {
    if (!SKILL_ORDER) return;
    var seq = SKILL_ORDER.indexOf(id);
    if (seq < 0) return;
    var tipIdx = -1;
    for (var i = 0; i < S.tips.length; i++) {
      var t0 = S.tips[i];
      if (t0.flower && t0.seq === seq) { tipIdx = i; break; }
    }
    if (tipIdx < 0) return;
    PICKED = tipIdx;
    FLASH = 1;
    var sk = SKILL_BY_ID[id];
    var st = stateOf(id);
    st = stateOf(id);
    HOVERED = tipIdx;
    if (sk) showSkillTip(sk, S.w * 0.5, S.h * 0.34, st === 'locked' ? '（前置未解锁）' : '');
    renderPanel();
  }

  function setPanelVisible(on) {
    var el = buildPanel();
    el.style.display = on ? 'block' : 'none';
    if (on && DEPS_LOADED) renderPanel();
  }

  /* ============================ 对外接口 ============================ */
  window.__MBG_TREE = {
    draw: draw,
    clickAt: clickAt,
    hoverAt: hoverAt,
    setPanelVisible: setPanelVisible,
    panelDebug: function () { return panelEl ? { parent: !!panelEl.parentNode, disp: panelEl.style.display, len: (panelEl.innerHTML || '').length, rows: panelEl.querySelectorAll('[data-skill]').length } : null; },
    firstHit: function () { return FLOWER_HITS.length ? FLOWER_HITS[0] : null; },
    debug: function () { return { depsLoaded: DEPS_LOADED, depCount: DEPS ? Object.keys(DEPS).length : 0, orderLen: SKILL_ORDER ? SKILL_ORDER.length : 0, flowers: FLOWER_HITS.length }; },
    reset: function () { S = null; T0 = null; pulses.length = 0; lastPulse = 0; PICKED = -1; hideSkillTip(); },
    /** 供外部（如导出图）拿到当前场景尺寸 */
    size: function () { return S ? { w: S.w, h: S.h } : null; }
  };
})();
