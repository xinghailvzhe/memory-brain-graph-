// 记忆脑图 · 会话日志读取器
// 用法: node session_log.cjs <session.v4.jsonl.zstd> [limit]
// 输出: { ok, id, title, createdAt, turns, count, messages:[{role,time,text}] }
// 说明: DSH 的会话日志是「一帧一条记录」拼接的 zstd（不是单个流），
//       Node 的 zstdDecompressSync 只解第一帧，所以这里先按 zstd 帧格式切边界再逐帧解。
"use strict";
const fs = require("fs");
const zlib = require("zlib");

function frameBounds(buf) {
  const out = [];
  let p = 0;
  const MAGIC = 0xfd2fb528;
  while (p + 5 <= buf.length) {
    if (buf.readUInt32LE(p) !== MAGIC) break;
    let q = p + 4;
    const fhd = buf[q++];
    const fcsFlag = fhd >> 6;
    const single = (fhd >> 5) & 1;
    const checksum = (fhd >> 2) & 1;
    const didFlag = fhd & 3;
    if (!single) q += 1;                       // window descriptor
    q += [0, 1, 2, 4][didFlag];                // dictionary id
    let fcsSize = [0, 2, 4, 8][fcsFlag];
    if (fcsFlag === 0 && single) fcsSize = 1;
    q += fcsSize;
    let last = 0;
    while (!last) {
      if (q + 3 > buf.length) return out;
      const bh = buf[q] | (buf[q + 1] << 8) | (buf[q + 2] << 16);
      q += 3;
      last = bh & 1;
      const type = (bh >> 1) & 3;
      const size = bh >>> 3;
      q += (type === 1) ? 1 : size;
    }
    if (checksum) q += 4;
    if (q > buf.length) return out;
    out.push([p, q]);
    p = q;
  }
  return out;
}

function decodeAll(buf) {
  const chunks = [];
  const frames = frameBounds(buf);
  if (!frames.length) {
    try { chunks.push(zlib.zstdDecompressSync(buf)); } catch { /* 交给上层报错 */ }
  } else {
    for (const [a, b] of frames) {
      try { chunks.push(zlib.zstdDecompressSync(buf.subarray(a, b))); } catch { /* 跳过坏帧 */ }
    }
  }
  return Buffer.concat(chunks).toString("utf8");
}

function textOf(content) {
  if (typeof content === "string") return content;
  if (!Array.isArray(content)) return "";
  const parts = [];
  for (const c of content) {
    if (!c || typeof c !== "object") continue;
    if (c.type === "text" && typeof c.text === "string") parts.push(c.text);
    else if (c.type === "image") parts.push("[图片]");
  }
  return parts.join("\n");
}

function clampText(s, n) {
  s = (s || "").replace(/\r/g, "").trim();
  return s.length > n ? s.slice(0, n) + " …" : s;
}

function main() {
  const file = process.argv[2];
  const limit = Math.max(1, Math.min(400, parseInt(process.argv[3], 10) || 160));
  const res = { ok: false, file, id: "", title: "", createdAt: 0, turns: 0,
                count: 0, toolCalls: 0, messages: [] };
  if (!file || !fs.existsSync(file)) {
    res.error = "找不到会话日志文件";
    process.stdout.write(JSON.stringify(res));
    return;
  }
  let text;
  try {
    text = decodeAll(fs.readFileSync(file));
  } catch (e) {
    res.error = "解压失败: " + (e && e.message);
    process.stdout.write(JSON.stringify(res));
    return;
  }
  const msgs = [];
  let turns = 0, tools = 0;
  for (const line of text.split("\n")) {
    if (!line.trim()) continue;
    let r;
    try { r = JSON.parse(line); } catch { continue; }
    if (r.type === "session") {
      res.id = r.id || "";
      res.createdAt = r.createdAt || 0;
    } else if (r.type === "session/title") {
      const t = r.data && r.data.title;
      if (t) res.title = t;
    } else if (r.type === "turn/start") {
      turns++;
    } else if (r.type === "tool/call") {
      tools++;
    } else if (r.type === "user/message") {
      const d = r.data || {};
      const who = (d.source && d.source.kind) || "";
      const txt = textOf(d.content);
      if (txt.trim() && who !== "tool") {
        msgs.push({ role: "user", time: r.time || 0, text: clampText(txt, 1600) });
      }
    } else if (r.type === "assistant/message") {
      const d = r.data || {};
      const txt = textOf((d.message && d.message.content) || []);
      if (txt.trim()) {
        msgs.push({ role: "assistant", time: r.time || 0, text: clampText(txt, 1600) });
      }
    }
  }
  res.turns = turns;
  res.toolCalls = tools;
  res.count = msgs.length;
  res.messages = msgs.slice(-limit);
  res.ok = true;
  process.stdout.write(JSON.stringify(res));
}

main();
