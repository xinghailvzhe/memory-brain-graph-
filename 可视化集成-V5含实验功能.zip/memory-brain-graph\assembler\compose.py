#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""组装器：把零件库当成零件箱，按需求凑出一个工作单元（skill 骨架或执行方案）。

零件库 = parts.py 产出的 organs/parts.json。每个零件是 skill 里的一个章节，
带 层（感知/思索/实践）、依赖、是否绑死本机、正文。

两个模式
--------
1. 组装（默认）
     python compose.py --need "每天检查服务器 DST 日志有没有崩"
   流程：需求 → 分词 → 三层分别检索零件 → 三层是否齐 → 复用/改造/新写三类分派
        → 输出装配单（Markdown）+ 可选骨架 SKILL.md。
   **不自动生成 skill**：装配单是给人（我）审的，因为没实测过的流程写进 skill 会害后来者。

2. 体检（--review）
   把整库的重复/偏科/孤岛变成可执行的整合、分离、提纯动作清单。
   动作只有五种：merge（合并）、split（拆开）、extract（抽成共享件）、
   prune（删/降级为索引）、fill（补层）。

产物：learn/reflection/out/ 下的 md；零件库本体不改。
"""
import argparse
import itertools
import json
import re
import sys
import datetime
from collections import defaultdict
import os
from pathlib import Path

WS = Path(os.environ.get("MBG_WS") or Path(__file__).resolve().parents[2])
ORGANS = Path(os.environ.get("MBG_OUT") or (WS / "plugins" / "memory-brain-graph" / "assets" / "organs"))
PARTS = ORGANS / "parts.json"
ASSEMBLIES = ORGANS / "assemblies.json"
REVIEW_JSON = ORGANS / "review.json"
OUTDIR = WS / "learn" / "reflection" / "out"

CN_STOP = set("的了是在和与及或就要我你他她它这那个些么什怎如何为把被让给对从到以及而且但是因为所以如果"
              "每天时候一个一下可以需要想要应该可能现在目前然后这样那样这个那些什么怎么".split())
LAYER_CN = {"sense": "感知", "think": "思索", "act": "实践", "unknown": "未知"}
# 虚词字：bigram 里带这些字的多半是跨词边界的碎片（有没/志有/了就），不是关键词
CN_FUNC = set("的了是在和与及或就才吗呢吧啊个这那我你他她它们不很也都还又再被把给对从到以而且但因所如果可要想时"
              "候上下里外前后些么怎啥呀哦")

# 需求里的层信号：出现这些词，说明这一层是刚需
NEED_LAYER_HINT = {
    "sense": re.compile(r"每天|定时|触发|什么时候|一旦|当|自动|轮询|监听|周期|cron|定期|计划任务", re.I),
    "think": re.compile(r"判断|什么算|算不算|标准|规则|阈值|区分|认定|崩溃|失败|异常|对不对|是否", re.I),
    "act": re.compile(r"怎么|如何|执行|命令|脚本|部署|写|生成|检查|查询|重启|下载|更新|修复|落盘", re.I),
}


def tokens(text, strict=False):
    """中英混排分词。strict=True 丢掉跨虚词边界的 bigram（需求侧用，噪声大）。
    **需求侧优先给 --keywords**：组装者自己给词比机器猜准。"""
    out = set()
    for m in re.finditer(r"[A-Za-z][A-Za-z0-9_.-]{1,30}|\d{2,}", text):
        out.add(m.group(0).lower())
    cn = re.sub(r"[A-Za-z0-9_.\-]+", " ", text)
    for seg in re.findall(r"[\u4e00-\u9fff]{2,}", cn):
        for i in range(len(seg) - 1):
            bg = seg[i:i + 2]
            if bg in CN_STOP:
                continue
            if strict and (bg[0] in CN_FUNC or bg[1] in CN_FUNC):
                continue
            out.add(bg)
    return out


def load_parts():
    if not PARTS.exists():
        print("零件库还没生成：先跑 python learn/reflection/parts.py", file=sys.stderr)
        sys.exit(2)
    return json.loads(PARTS.read_text(encoding="utf-8"))


def build_index(parts):
    """建 IDF 索引：常见词（检查/每天）压低、稀有词（dst/崩溃/日志）抬高。
    不分词库、不引工具，纯统计。"""
    import math
    df = defaultdict(int)
    part_tokens = {}
    for p in parts:
        tk = tokens(p["title"]) | tokens(p["text"])
        part_tokens[p["id"]] = tk
        # 只在标题里出现的词额外记一份「标题词」标记
        for t in tk:
            df[t] += 1
    n = max(len(parts), 1)
    idf = {t: math.log(1.0 + n / (1.0 + c)) for t, c in df.items()}
    title_tokens = {p["id"]: tokens(p["title"]) for p in parts}
    return idf, part_tokens, title_tokens


def score_part(p, tk, need_layers, idf, ptk, ttk):
    """IDF 加权：命中稀有词才算真相关；标题命中 ×3。"""
    pid = p["id"]
    matched = tk & ptk.get(pid, set())
    if not matched:
        return 0.0
    title_tk = ttk.get(pid, set())
    s = 0.0
    for t in matched:
        w = idf.get(t, 0.0)
        if t in title_tk:
            w *= 3.0          # 标题里有这个词
        s += w
    # 至少命中一个"稀有词"（idf 高）才算候选，避免"检查/每天"这类通用词把无关零件拉上来
    top_idf = max((idf.get(t, 0.0) for t in matched), default=0.0)
    if top_idf < 1.2 and len(matched) < 3:
        return 0.0
    # 命中词占需求词的比例：需求 10 个词只命中 1 个，相关性弱
    cover = len(matched) / float(max(len(tk), 1))
    s *= (0.4 + 0.6 * min(1.0, cover * 2.5))
    # skill 名命中（需求说 dst → dst-* 全部加权重）：比正文词更能锁定领域
    if tk & tokens(p["skill"], strict=True):
        s *= 1.6
    if p["layer"] in need_layers:
        s *= 1.25
    if p["layer"] == "unknown":
        s *= 0.6
    if p["chars"] < 40:
        s *= 0.5
    elif p["chars"] > 4000:
        s *= 0.85
    return s


def compose(need, kw=None, topk=4):
    data = load_parts()
    idf, ptk, ttk = build_index(data["parts"])
    tk = tokens(kw, strict=True) if kw else tokens(need, strict=True)
    if len(tk) < 2:                       # 需求太短/全是虚词：放宽一次
        tk = tokens(kw or need)
    need_layers = {k for k, rx in NEED_LAYER_HINT.items() if rx.search(need)} or {"sense", "think", "act"}

    scored = []
    for p in data["parts"]:
        s = score_part(p, tk, need_layers, idf, ptk, ttk)
        if s > 0:
            scored.append((s, p))
    scored.sort(key=lambda x: -x[0])

    by_layer = defaultdict(list)
    for s, p in scored:
        if len(by_layer[p["layer"]]) < topk:
            by_layer[p["layer"]].append((s, p))

    # 缺层判定：该层没有零件，或最高分低到不可信（阈值跟分数尺度走）
    missing = []
    best_any = max((s for s, _ in scored[:3]), default=0.0)
    for L in ("sense", "think", "act"):
        cand = by_layer.get(L) or []
        if not cand or cand[0][0] < best_any * 0.35:
            missing.append(L)

    # 先查预组装件：有现成组件能覆盖这个需求，主组装就直接用它，不用从零件重拼。
    # （用户 2026-11-02 口径：拼乐高 —— 预组装过的东西后续只是零件可复用）
    asms = []
    if ASSEMBLIES.exists():
        try:
            adata = json.loads(ASSEMBLIES.read_text(encoding="utf-8"))
            for a in adata.get("assemblies", []):
                hay = " ".join([a.get("name", "")] + a.get("skills", []) + a.get("deps", [])).lower()
                hits = sum(1 for t in tk if t and t.lower() in hay)
                if hits:
                    asms.append({
                        "score": hits * max(a.get("reuse", 1), 1),
                        "id": a["id"], "name": a["name"], "skills": a["skills"],
                        "reuse": a["reuse"], "layers": a["layers"],
                        "complete": a.get("complete", False),
                        "bricks": len(a.get("parts", [])),
                    })
            asms.sort(key=lambda x: -x["score"])
            asms = asms[:3]
        except Exception:
            pass

    now = datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S+08:00")
    return {
        "mode": "compose",
        "generatedAt": now,
        "need": need,
        "tokens": sorted(tk),
        "needLayers": sorted(need_layers),
        "missing": missing,
        "assemblies": asms,
        "candidates": {
            L: [{"score": round(s, 1), "id": p["id"], "skill": p["skill"], "title": p["title"],
                 "layer": p["layer"], "chars": p["chars"], "local": p["local"],
                 "deps": p["deps"][:6], "head": p["text"][:400]}
                for s, p in by_layer.get(L, [])]
            for L in ("sense", "think", "act", "unknown")
        },
        "source": str(PARTS),
    }


def review():
    data = load_parts()
    skills = data["skills"]
    parts = data["parts"]
    by_skill = defaultdict(list)
    for p in parts:
        by_skill[p["skill"]].append(p)
    name2desc = {s["name"]: s.get("description", "") for s in skills}

    actions = []

    # ① 抽成预组装件（extract）：共享执行体的 skill 组。
    #    **不是合并 skill** —— 用户 2026-11-02 的乐高口径：组装好的 skill 默认不拆，
    #    各自有触发场景（每日巡检/点名快查/版本更新/运维排障），合并会把触发条件挤在一起。
    #    正确做法是把共用的那一份抽成组件，几个 skill 各自引用。
    clusters = data.get("clusters", [])
    adj = defaultdict(set)
    pair_deps = {}
    for c in clusters:
        adj[c["a"]].add(c["b"])
        adj[c["b"]].add(c["a"])
        pair_deps[(c["a"], c["b"])] = c
    seen, comps = set(), []
    for n in adj:
        if n in seen:
            continue
        stack, comp = [n], set()
        while stack:
            x = stack.pop()
            if x in seen:
                continue
            seen.add(x)
            comp.add(x)
            stack.extend(adj[x] - seen)
        comps.append(sorted(comp))
    asm_comps = []
    for comp in comps:
        if len(comp) < 2:
            continue
        deps, best = set(), 0
        for a, b in itertools.combinations(comp, 2):
            c = pair_deps.get((a, b)) or pair_deps.get((b, a))
            if c:
                deps.update(c["deps"])
                best = max(best, c["sharedDeps"])
        actions.append({
            "kind": "extract", "priority": "high" if best >= 6 else "medium",
            "skills": comp, "sharedDeps": best, "deps": sorted(deps)[:6],
            "why": "这 %d 个 skill 共 %d 个执行体（%s）——同一套动作写了几遍，改一处必漏其余" % (
                len(comp), best, "、".join(sorted(deps)[:4])),
            "do": "抽成预组装件（assemblies.py 已经能生成）：共用的执行体只写一份，"
                  "%d 个 skill 各自引用；**skill 本身不拆**" % len(comp),
        })
        asm_comps.append(set(comp))

    # ② 其它 extract：一个执行体被 >=3 个 skill 引用，且这组 skill 没被上面的组件覆盖
    groups = defaultdict(list)
    for e in data.get("execShared", []):
        if len(e["skills"]) >= 3 and not re.search(r"https?://", e["dep"]):
            groups[tuple(sorted(e["skills"]))].append(e["dep"])
    for sks, deps in groups.items():
        if any(set(sks) <= comp for comp in asm_comps):
            continue
        actions.append({
            "kind": "extract", "priority": "medium", "skills": list(sks), "deps": deps[:5],
            "why": "%d 个 skill 都引用同一批执行体（%s）；任一份改了其余会静默过期" % (
                len(sks), "、".join(deps[:3])),
            "do": "把这件的用法抽到一处（references/ 或一个预组装件），其余改为引用",
        })

    # ③ split / fill：偏科 + 缺层
    for g in data.get("gaps", []):
        if g["kind"] == "lopsided":
            big = sorted(by_skill[g["skill"]], key=lambda p: -p["chars"])[:3]
            actions.append({
                "kind": "split" if g["share"] >= 0.75 else "fill",
                "priority": "medium", "skill": g["skill"],
                "missing": g["missing"], "share": g.get("share"),
                "why": g["note"],
                "do": ("把 %s 里的大块零件拆出去（%s），本体只留触发与判据" % (
                    g["skill"], "、".join(p["title"][:16] for p in big))
                       if g["share"] >= 0.75 else
                       "补 %s：%s" % ("/".join(LAYER_CN[m] for m in g["missing"]),
                                     "写清楚什么时候该用它（触发）" if "sense" in g["missing"]
                                     else "写清楚怎么判断对错（判据）")),
            })
        elif g["kind"] == "entry":
            actions.append({
                "kind": "prune", "priority": "low", "skill": g["skill"],
                "why": g["note"], "do": "降级为索引条目（在别的 skill 里一句话指路），不再单独占一个 skill 位",
            })
        elif g["kind"] == "island":
            actions.append({
                "kind": "link", "priority": "low", "skill": g["skill"],
                "why": g["note"],
                "do": "检查它是不是别人该引用的零件；是就把引用补上，不是就在描述里写清边界",
            })

    order = {"high": 0, "medium": 1, "low": 2}
    actions.sort(key=lambda x: (order.get(x["priority"], 3), x["kind"]))
    return {
        "mode": "review",
        "generatedAt": datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        "counts": data["counts"],
        "actions": actions,
    }


def render_compose_md(r):
    L = []
    L.append("# 装配单：%s" % r["need"])
    L.append("")
    L.append("> 生成 %s ｜ 需求词：%s" % (r["generatedAt"], " ".join(r["tokens"][:24])))
    L.append("")
    L.append("## 三层齐不齐")
    L.append("")
    L.append("| 层 | 状态 | 首选零件 |")
    L.append("|---|---|---|")
    for Lk in ("sense", "think", "act"):
        cand = r["candidates"].get(Lk) or []
        if Lk in r["missing"]:
            st = "**缺**"
        elif cand:
            st = "有"
        else:
            st = "缺"
        first = (cand[0]["skill"] + " · " + cand[0]["title"]) if cand else "—"
        L.append("| %s | %s | %s |" % (LAYER_CN[Lk], st, first))
    L.append("")
    # 预组装件：有能直接用的就先说，别让人从零拼
    L.append("## 预组装件候选（能直接用就别重拼）")
    L.append("")
    asms = r.get("assemblies") or []
    if not asms:
        L.append("_没有匹配的预组装件：这次要从零件拼。_")
    for a in asms:
        L.append("- **%s**（被 %d 个 skill 复用，%d 个零件，%s）id=`%s`" % (
            a["name"], a["reuse"], a["bricks"],
            "三层齐" if a["complete"] else "缺层", a["id"]))
        L.append("  - 来源：%s" % "、".join(a["skills"]))
    L.append("")
    for Lk in ("sense", "think", "act"):
        cand = r["candidates"].get(Lk) or []
        L.append("## %s件候选" % LAYER_CN[Lk])
        L.append("")
        if not cand:
            L.append("_没有候选：这一层要新写。_")
            L.append("")
            continue
        for c in cand:
            tag = "本机专属" if c["local"] else "可搬"
            L.append("### %s ｜ %s · %s（%d 字，%s）" % (
                c["id"], c["skill"], c["title"], c["chars"], tag))
            L.append("")
            if c["deps"]:
                L.append("依赖：%s" % "、".join("`%s`" % d for d in c["deps"]))
                L.append("")
            L.append("```")
            L.append(c["head"].rstrip())
            L.append("```")
            L.append("")
    L.append("## 装配判断（人填，不自动）")
    L.append("")
    L.append("- 直接复用：")
    L.append("- 需要改造（改哪几处）：")
    L.append("- 必须新写：")
    L.append("- 装配后要实测什么：")
    L.append("")
    return "\n".join(L)


def render_review_md(r):
    L = ["# 零件体检：整合 / 分离 / 提纯", ""]
    c = r["counts"]
    L.append("> %s ｜ %d 个 skill、%d 个零件 ｜ 感知 %d / 思索 %d / 实践 %d / 未知 %d" % (
        r["generatedAt"], c["skills"], c["parts"],
        c["layers"].get("sense", 0), c["layers"].get("think", 0),
        c["layers"].get("act", 0), c["layers"].get("unknown", 0)))
    L.append("")
    L.append("共 %d 条动作（high %d / medium %d / low %d）" % (
        len(r["actions"]),
        sum(1 for a in r["actions"] if a["priority"] == "high"),
        sum(1 for a in r["actions"] if a["priority"] == "medium"),
        sum(1 for a in r["actions"] if a["priority"] == "low")))
    L.append("")
    cur = None
    for a in r["actions"]:
        if a["kind"] != cur:
            cur = a["kind"]
            L.append("## %s" % {
                "merge": "合并（merge）", "extract": "抽共享件（extract）",
                "split": "拆开（split）", "fill": "补层（fill）",
                "prune": "降级/删除（prune）", "link": "补引用（link）",
            }.get(cur, cur))
            L.append("")
        if a.get("skills"):
            tgt = " + ".join(a["skills"])
        elif a.get("skill"):
            tgt = a["skill"]
        else:
            tgt = a.get("dep", "")
        L.append("- **[%s] %s**" % (a["priority"], tgt))
        L.append("  - 为什么：%s" % a["why"])
        L.append("  - 怎么做：%s" % a["do"])
    L.append("")
    return "\n".join(L)


def write_organs(r):
    """把体检结果写成页面可读的精简版（不写长 why/do 的全文，够显示即可）。"""
    slim = {
        "generatedAt": r["generatedAt"],
        "counts": r["counts"],
        "total": len(r["actions"]),
        "byKind": {},
        "actions": [{"kind": a["kind"], "priority": a["priority"],
                     "target": "+".join(a["skills"]) if a.get("skills") else a.get("skill", ""),
                     "why": (a.get("why") or "")[:90],
                     "do": (a.get("do") or "")[:110]}
                    for a in r["actions"][:40]],
    }
    for a in r["actions"]:
        slim["byKind"][a["kind"]] = slim["byKind"].get(a["kind"], 0) + 1
    REVIEW_JSON.parent.mkdir(parents=True, exist_ok=True)
    REVIEW_JSON.write_text(json.dumps(slim, ensure_ascii=False, indent=2), encoding="utf-8")
    return slim


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--need", help="要凑的能力，一句话")
    ap.add_argument("--keywords", default="", help="自己给检索词（空格分隔，中文词/英文词都行）；不给就从需求里切")
    ap.add_argument("--review", action="store_true", help="整库体检，出整合/分离/提纯动作")
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--topk", type=int, default=4)
    ap.add_argument("--out")
    args = ap.parse_args()

    if args.review:
        r = review()
        md = render_review_md(r)
        OUTDIR.mkdir(parents=True, exist_ok=True)
        p = Path(args.out) if args.out else OUTDIR / "review-latest.md"
        p.write_text(md, encoding="utf-8")
        (OUTDIR / "review-latest.json").write_text(
            json.dumps(r, ensure_ascii=False, indent=2), encoding="utf-8")
        write_organs(r)
        if args.json:
            print(json.dumps(r, ensure_ascii=False, indent=2))
        else:
            print(md)
            print("\n-> %s" % p)
        return 0

    if not args.need:
        ap.error("要么 --need，要么 --review")
    r = compose(args.need, args.keywords, args.topk)
    md = render_compose_md(r)
    OUTDIR.mkdir(parents=True, exist_ok=True)
    slug = re.sub(r"[^\w\u4e00-\u9fff]+", "-", args.need)[:40].strip("-")
    p = Path(args.out) if args.out else OUTDIR / ("compose-%s.md" % slug)
    p.write_text(md, encoding="utf-8")
    (OUTDIR / ("compose-%s.json" % slug)).write_text(
        json.dumps(r, ensure_ascii=False, indent=2), encoding="utf-8")
    print(md)
    print("\n-> %s" % p)
    return 0


if __name__ == "__main__":
    sys.exit(main())
