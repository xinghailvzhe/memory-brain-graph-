#!/usr/bin/env python3
"""把 triads.json 画成一张「感知 / 思索 / 实践」三角图（自包含 HTML，用无头浏览器截图看）。

读：plugins/memory-brain-graph/assets/organs/triads.json
写：.tmp/triads-map.html

坐标：三个顶点为纯感知 / 纯思索 / 纯实践；每个对象的 (s,t,a) 先归一化成方向，
再按信号强度（三轴和）收缩，所以「三轴都很低」的对象会落在中心附近，
贴边且离中心远的才是真正偏科的对象。
"""
import json
import math
from pathlib import Path

WS = Path(__file__).resolve().parents[2]
SRC = WS / "plugins" / "memory-brain-graph" / "assets" / "organs" / "triads.json"
OUT = WS / ".tmp" / "triads-map.html"

W, H = 1080, 860
CX, CY = 0.5, 0.60
S = (0.50, 0.06)
T = (0.05, 0.94)
A = (0.95, 0.94)


def place(it):
    s, t, a = it["sense"], it["think"], it["act"]
    tot = s + t + a
    if tot <= 0:
        return CX, CY, 0.0
    dx = (s * S[0] + t * T[0] + a * A[0]) / tot
    dy = (s * S[1] + t * T[1] + a * A[1]) / tot
    strength = min(1.0, tot / 1.15)
    px = CX + (dx - CX) * strength
    py = CY + (dy - CY) * strength
    return px, py, tot


def main():
    data = json.loads(SRC.read_text(encoding="utf-8"))
    items = data["items"]

    def X(nx):
        return 40 + nx * (W - 80)

    def Y(ny):
        return 120 + ny * (H - 200)

    parts = []
    parts.append('<rect width="100%" height="100%" fill="#070b18"/>')
    # 三角边框与网格
    p1, p2, p3 = (X(S[0]), Y(S[1])), (X(T[0]), Y(T[1])), (X(A[0]), Y(A[1]))
    parts.append('<polygon points="%.1f,%.1f %.1f,%.1f %.1f,%.1f" fill="none" stroke="rgba(140,190,255,0.35)" stroke-width="1.2"/>' % (p1[0], p1[1], p2[0], p2[1], p3[0], p3[1]))
    # 中位线（0.33 / 0.66 两条等高线，示意层级）
    for frac in (0.33, 0.66):
        q1 = (p1[0] + (p2[0] - p1[0]) * frac, p1[1] + (p2[1] - p1[1]) * frac)
        q2 = (p1[0] + (p3[0] - p1[0]) * frac, p1[1] + (p3[1] - p1[1]) * frac)
        parts.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="rgba(120,160,220,0.12)" stroke-width="1"/>' % (q1[0], q1[1], q2[0], q2[1]))
        q3 = (p2[0] + (p3[0] - p2[0]) * frac, p2[1] + (p3[1] - p2[1]) * frac)
        parts.append('<line x1="%.1f" y1="%.1f" x2="%.1f" y2="%.1f" stroke="rgba(120,160,220,0.10)" stroke-width="1"/>' % (q3[0], q3[1], q1[0], q1[1]) if frac == 0.33 else "")

    # 顶点标签
    parts.append('<text x="%.1f" y="%.1f" fill="#8fe8d0" font-size="17" font-weight="700" text-anchor="middle">感知 · 触发</text>' % (p1[0], p1[1] - 18))
    parts.append('<text x="%.1f" y="%.1f" fill="#ffd68a" font-size="17" font-weight="700" text-anchor="middle">思索 · 判断</text>' % (p2[0] + 6, p2[1] + 34))
    parts.append('<text x="%.1f" y="%.1f" fill="#9fc8ff" font-size="17" font-weight="700" text-anchor="middle">实践 · 动作</text>' % (p3[0] - 6, p3[1] + 34))

    pts = []
    for it in items:
        px, py, tot = place(it)
        pts.append((it, px, py, tot))

    # 点
    for it, px, py, tot in pts:
        col = "#5ee0c0" if it["type"] == "skill" else "#ffc861"
        r = 3.2 + 2.6 * min(1.0, it["balance"])
        parts.append('<circle cx="%.1f" cy="%.1f" r="%.1f" fill="%s" fill-opacity="%.2f" stroke="%s" stroke-opacity="0.55" stroke-width="0.8"/>' % (X(px), Y(py), r, col, 0.35 + 0.45 * min(1.0, tot / 1.2), col))

    # 最失衡的 10 个加标签
    for it, px, py, tot in pts[:10]:
        parts.append('<text x="%.1f" y="%.1f" fill="rgba(220,235,255,0.78)" font-size="11">%s</text>' % (X(px) + 8, Y(py) + 4, it["name"][:22]))

    head = ('<text x="40" y="44" fill="#e8f2ff" font-size="22" font-weight="700">感知 / 思索 / 实践 · 对象坐标</text>'
            '<text x="40" y="70" fill="rgba(160,195,235,0.75)" font-size="13">共 %d 个对象（skill %d · plugin %d）· 生成于 %s</text>'
            '<text x="40" y="92" fill="rgba(150,180,220,0.55)" font-size="12">离三顶点越近＝该轴越强；靠近中心＝三轴都弱（信号不足，不是均衡）</text>'
            % (len(items),
               sum(1 for i in items if i["type"] == "skill"),
               sum(1 for i in items if i["type"] == "plugin"),
               data.get("generatedAt", "")))

    legend = ('<g transform="translate(760,60)">'
              '<circle cx="0" cy="0" r="5" fill="#5ee0c0"/><text x="12" y="4" fill="rgba(210,235,255,0.8)" font-size="12">skill</text>'
              '<circle cx="0" cy="22" r="5" fill="#ffc861"/><text x="12" y="26" fill="rgba(210,235,255,0.8)" font-size="12">plugin</text>'
              '</g>')

    svg = ('<svg xmlns="http://www.w3.org/2000/svg" width="%d" height="%d" viewBox="0 0 %d %d" '
           'font-family="Microsoft YaHei, system-ui, sans-serif">%s%s%s%s</svg>'
           % (W, H, W, H, "".join(parts), head, legend, ""))

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text('<!doctype html><html><head><meta charset="utf-8"><style>html,body{margin:0;background:#070b18}</style></head><body>%s</body></html>' % svg, encoding="utf-8")
    print("WROTE", OUT, "items=", len(items))


if __name__ == "__main__":
    main()
