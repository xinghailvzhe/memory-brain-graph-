---
name: reflection-ops
description: 维护记忆脑图（memory-brain-graph）的「自我反思」流水线：待反思清单、语义反思的模型调用与调参、历史与去重、丢弃口径、05:00 换日。需要改反思脚本、换模型或网关、调批次与重试、排查「反思不跑 / 重复反思 / 结论被覆盖 / 待反思清不掉」时读这一份。
---

# 反思流水线运维（reflection-ops）

## 什么时候用这个 skill

**该读（出现这些说法/任务就进来）**

- 「反思不跑了」「反思没更新」「待反思清不掉」「数字不对/不涨」「重复反思同一条」「结论被覆盖/被顶掉」「丢了几条」
- 要**换模型、换网关**、调每批条数 / 重试次数 / 最长运行时间
- 要改反思结果在页面上的呈现（星、计数、discarded 清单、开关）
- 排查 `/api/reflect/*` 接口、计划任务开关、`pythonw` 不写盘、`schtasks` 状态读错

**不用读**

- 只是安装插件、起服务、连记忆库 → 看 `AI-INSTALL.md` §1–§3
- 只改页面里跟反思无关的视觉 → 直接看 `assets/index.html`
- 任务不涉及 `learn/reflection/`、`history.jsonl`、`reflection.json`

**接手先做这三件事**

1. `GET /api/reflect/status`：确认 `supported` / `tasks` / `lastRun`。
2. 看 `learn/reflection/history.jsonl` 最后几条：最近一次反思是什么类型、成功了没、带了多少 id。
3. `semantic_reflect.py --dry`：只打印第一批提示词，不调模型、不改输出；确认它准备送什么。


## 这套东西在哪

| 文件 | 干什么 |
|---|---|
| `learn/reflection/semantic_reflect.py` | 语义反思：按今日待反思循环取批 → 调模型 → 写结论/历史，跑到清空 |
| `learn/reflection/auto_reflect.py` | 规则反思（每小时）：只统计数量，不调模型；当天已有语义结论时**不覆盖页面** |
| `learn/reflection/full_audit.py` | 全量自检：分层/状态/关键词/重复统计，写 `audit-*.md` |
| `learn/reflection/reflect_store.py` | 历史库 `history.jsonl`：追加记录、按 kind 查最后时间、已反思 id 集合 |
| `learn/reflection/prune.py` | 归档候选清单（默认只报告；`--apply` 才动库且先备份） |
| `learn/reflection/note.py` | **手动反思写入器**：只写 `reflection.json` 的 `manual` 字段（记忆整理 / 自我审视 / 这一轮干了啥），不覆盖自动那套 |
| `learn/reflection/triads.py` | **三元图打分**：扫 `~/.dsh/skills/*/SKILL.md` 与工作区 `plugins/`，按 感知/思索/实践 打权重，写 `assets/organs/triads.json` |
| `learn/reflection/parts.py` | **零件库**：章节级拆解 + 三层归位 + 共享执行体查重，写 `assets/organs/parts.json` |
| `learn/reflection/compose.py` | **组装器 / 体检器**：`--need` 出装配单，`--review` 出整合分离提纯动作 |
| `learn/reflection/triad_map.py` | 把 triads.json 画成一张独立三角图 HTML（截图/人工核对用，页面不依赖它） |
| `plugins/memory-brain-graph/assets/reflection.json` | 页面读的唯一结论文件（`updatedAt` 变→播诞生动画） |
| `plugins/memory-brain-graph/assets/index.html` | 页面：外围三阵=待反思、中间=成果、一条结论一颗星、开关/立即反思/秒数 |
| `plugins/memory-brain-graph/assets/server.py` | 接口：`/api/reflect/status`、`/api/reflect/auto`、`/api/reflect/run`、`/api/reflect/tokens` |

## 部署到新机器（别人装了插件、但没有这套脚本）

1. 把包内 `reflection/` 目录整个拷到 `<工作区>/learn/reflection/`。
2. 默认路径按脚本位置推导（上两级＝工作区）；插件不在工作区时设 `REFLECT_DB` / `REFLECT_OUT` / `REFLECT_LOG_DIR`。
3. `python semantic_reflect.py --dry` 先验证，再 `--batch 6 --max 1` 小批试跑。
4. 要自动化再建计划任务（Windows 用 `pythonw.exe`）；**默认不要替用户创建**。
5. 模型/网关见本文「模型怎么调」；没有免费网关就改脚本顶部 `GATEWAY` / `MODELS`。

## 数据流

1. 每日新增记忆（`created_at` ≥ 05:00 换日点，且 `status=active`）里，排除 `absorbedIds` → **待反思**。
2. `semantic_reflect.py` 每批取 `BATCH` 条（默认 10），拼提示词（标题｜摘要），调模型。
3. 成功 → 写 `reflection.json`（`newIds`、`absorbedIds` 累加、`kind=semantic`），追加 `history.jsonl`；页面 60 秒轮询到新 `updatedAt` → 播一次诞生动画。
4. 循环直到没有待反思，或到 `MAX_BATCHES` / `MAX_SECONDS`。
5. 规则反思看到当天已有 `kind=semantic` 时只记历史，不碰页面。

## 手动反思与三元图（2026-11-02 新增）

- **手动反思**：`note.py --from-json <spec.json>` 只写 `reflection.json` 的 `manual` 字段（标题 / 时间 / 一句话结论 / 最多 4 行明细），页面在左下角单独画一块，和中央的自动审视并存。用于「这一轮整理了哪些记忆、改了哪些东西」。
- **注意**：`auto_reflect.py` / `semantic_reflect.py` / `full_audit.py` 三个写入方都是**整体重写** json，写盘前必须把旧的 `manual` 读出来带上（已修）。新加写入方时照抄这个写法，否则手动那块会被静默抹掉。
- **三元图**：`triads.py` 扫 skill 与插件，按 感知 / 思索 / 实践 三轴打权重写 `triads.json`；`auto_reflect.py` 每轮结束会顺手重算一次。页面上看：底部按钮「三元图」。三轴全 0 的对象（正文太短或只是转发入口）图上不画，面板里列名字。
- 分数是关键词密度的**粗估**，只用来找偏科对象，别当精确值。
- **唤醒寄存器**：`learn/wakeups.json` 声明「谁在什么时机自己动」；`triads.py` 读它，被声明且 `status: active` 的 skill 感知轴按 0.45 起算（不再算成被动对象），面板里会列出它们的唤醒时间，页面右上角常驻一行「已接管 X/Y · 在补 Z」。新增唤醒项时**两边一起改**——执行体真接上 + 这里登记 `active` 并写 `verified`，只写登记不算数（页面会显示成「在补」）。

## 零件库与组装（2026-11-02 新增）

反思如果只产出「三行结论」，就只是**看**；用户要的是反思后**真的动** skill 结构。这一层由三个脚本组成：

| 文件 | 干什么 |
|---|---|
| `learn/reflection/parts.py` | 把每个 skill 按 `##` 章节拆成零件，归 感知/思索/实践/未知 四类，写 `assets/organs/parts.json`；同时用**共享执行体**（同一脚本/路径/主机被多个 skill 引用）找真重复 |
| `learn/reflection/compose.py --need "..."` | 组装：需求 → IDF 加权检索三层零件 → 出装配单（`learn/reflection/out/compose-*.md`），顶上标哪层缺 |
| `learn/reflection/compose.py --review` | 体检：把重复/偏科/入口型转成 merge / extract / split / fill / prune / link 六类动作，写 `out/review-latest.md` + `assets/organs/review.json`（页面读） |

**自动接线**：`auto_reflect.py` 每轮跑完反思后，会依次重算 `triads.py` → `parts.py` → `compose.review()`。所以页面右上角那行「零件 N（感/思/实）· 体检 M 条」是每轮自己刷新的。

**判重不要用文字相似度**：模板同构（什么时候用/流程/验收）会让不同领域的 skill 算出 0.6~0.7 相似度。实测 44 个 skill 里过 0.80 的一对都没有，而共享执行体的有四组（dst 四件套共享 18 个执行体）。判据写在 `skill-assembly` 技能里。

**页面侧**：零件按层画进外围三个法阵（感知→眼、思索→脑、实践→手），用**亮白菱形**和记忆的彩色圆点区分；点开是零件面板（来源 skill / 层 / 字数 / 依赖 / 正文）；右上角「零件…体检…」那行点开是动作清单。

**纪律**：这些脚本**只产清单，不自动改 skill**。合并/拆分是不可逆的结构变更，落笔永远是人。

## 模型怎么调（最常改的）

- 网关：环境变量 `REFLECT_GATEWAY`（本机免费网关的转发口；地址与端口见本机网关配置，模板脚本不内置地址）。
- Key：`<DSH_HOME>/our-free-model/settings.json` 里的 `forwardKey`（别写进代码/页面）。
- 默认模型顺序 `MODELS = ["kilo-auto/free", "openrouter/free"]`；**必须带** `reasoning_effort: "low"`，否则免费池会把预算烧在思考上、正文为空。
- `max_tokens: 3000`：小了会被截断；脚本对「半截 JSON」有容错解析（summary + lines 逐个抠）。
- 限流（429/502）时：脚本等 75 秒重试一次；单批失败只跳过该批，连续 3 批失败才收手。**别连续手动触发**，免费池是分钟级窗口。
- 换批次/上限：文件顶部 `BATCH`（每批条数）、`MAX_BATCHES`（最多几批）、`MAX_SECONDS`（最长跑多久）。
- 换供应商：改 `GATEWAY` + `KEY_FILE` + `MODELS` 即可，其余逻辑不变。

## 隐私边界（硬约束）

- 只送 `project / fact / lesson / topic / rules` 五层；`soul / user` 永不外发，也不标成「已提炼」。
- 每条只送标题 + 130 字截断摘要。
- 命中密钥样式（`sk-`、`ofm-`、`password=`、`api_key=` 这类硬赋值）的整条跳过，并记入 `discarded`。

## 常见故障

| 现象 | 原因 | 处理 |
|---|---|---|
| 界面数字不涨 / 不跑 | 服务没起、脚本不存在 | 看 `/api/reflect/status` 的 `supported`、`tasks` |
| 开关关了又变开 | 系统任务状态读错（文本本地化） | 已改读任务 XML：`schtasks /Query /TN 名 /XML` 看 `<Enabled>false` |
| 每小时结论被顶掉 | 多写手覆盖 | 已用 `kind` 仲裁：规则反思见 semantic 只记历史 |
| 重复反思同一批 | 已提炼清单没生效 | 检查 `reflection.json.absorbedIds` 与页面 `nodeKey()` 归一化（页面节点 id 带层名前缀） |
| 待反思清不到 0 | 把归档/过期算进去了 | 页面只算 `status=active`；脚本只查 active |
| 反思脚本不写盘 | `pythonw` 下 `sys.stdout is None` | 先把日志落盘再 `print`（`log()` 已这样写） |

## 验收（改完必须跑）

```powershell
$py='<DSH_HOME>/dsh-runtimes/<运行时>/dependencies/python/python.exe'
& $py <工作区>/learn/reflection/semantic_reflect.py --batch 6 --max 1   # 单批试跑
& $py -c "import sys;sys.path.insert(0,r'<工作区>/learn/reflection');import semantic_reflect as S;a=S._absorbed_set();print(len(S.fetch_pending(a,9999)))"
```

页面侧：`http://127.0.0.1:8787/api/reflect/tokens` 有数；`?cam=2.10` 下中央显示今日/累计/待反思，点星星能展开对应结论。

## 设计口径（用户定的，别改回去）

- 外围三阵＝待反思列表；中间＝已反思成果。
- 一条结论一颗星；跑到清空才停。
- 没信息的条目如实显示「丢弃 N 条」，不假装反思过。
- 「今日」按 05:00 换日。
- 实验性功能默认关闭；换机器部署不要替用户创建计划任务或打开开关。
