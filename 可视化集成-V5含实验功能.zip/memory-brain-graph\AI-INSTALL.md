# AI-INSTALL —— 给「读这个包的 AI」看的部署说明

> 你读到这份文件，说明有人把 **记忆脑图（memory-brain-graph）** 这个 DSH 插件包交给了你。
> 你的任务不是读代码，而是**判断目标机器缺什么、把它装好、跑通、验证**。
> 包里那份 `memory-brain-graph-<版本>.tgz` 就是可直接安装的插件；本文件、`README.md`、`安装说明.md` 是说明。

## 0. 先判断这是什么

- 一个 **DSH（DeepSeek Harness）插件**，三部分：
  - `lib/index.js`：Host 侧，只做一件事——托管本地 python 服务（探活 `127.0.0.1:8787`，没在跑就拉起，之后每 30 秒复查）。
  - `client.js` + `locale/` + `icon.svg`：Web 客户端半边（「脑图」按钮与标签页）。
  - `assets/`：真正干活的本地服务 `server.py`（只读记忆库画图）、`index.html`（画布前端）、`session_log.cjs`（解压会话日志）。
- 不依赖云服务、不上传数据、不需要 API Key。**只监听 127.0.0.1**。

## 0.5 反思是实验性功能（默认关闭，别替用户打开）

- 页面左下角有带「实验性」标签的控制栏：自动反思开关 + 立即反思 + 已反思 N 秒。
- 默认必须关闭。没有反思脚本时，开关显示「未部署」并保持关闭。
- **不要替用户创建计划任务、不要替用户把开关打开**——这是用户自己的决定。
- 安装验收只需确认：控制栏存在、默认状态正确、点「立即反思」能跑一次并显示「已反思 N 秒」。

## 0.6 什么时候读 `skills/reflection-ops/SKILL.md`

**要读**：反思不跑了 / 没更新 / 待反思清不掉 / 数字不对 / 重复反思 / 丢条目；换模型或网关；调每批条数、重试、最长运行时间；改反思在页面上的呈现。

**不用读**：只是安装、启动、连记忆库；只改视觉；不涉及 `learn/reflection/`。

**读之前先确认**：目标机器有没有 `<工作区>/learn/reflection/` 那套脚本。没有就是「未部署」——按 §0.5 处理。

## 0.7 反思脚本的部署（可选，默认不做）

包里 `reflection/` 是模板，不会被自动运行。要用时：拷到 `<工作区>/learn/reflection/`，前提是有 `.dsh-meow/memory.db` 和 python 3。路径默认「脚本往上两级＝工作区」，可用 `REFLECT_DB` / `REFLECT_OUT` / `REFLECT_LOG_DIR` / `REFLECT_BACKUP` 覆盖。验证用 `python semantic_reflect.py --dry`，再 `--batch 6 --max 1` 小批试跑。**要自动化再建计划任务，默认不要替用户建。**

## 1. 前置条件（先查，缺什么让用户补什么）

| 需要 | 说明 | 缺失时 |
| --- | --- | --- |
| DSH（桌面版即可） | 插件只能挂在 profile 里 | 没有 profile 目录就无从安装 |
| python 3 | 标准库即可；优先 DSH 自带 `<DSH_HOME>/dsh-runtimes/*/dependencies/python/python.exe` | 服务起不来（页面打不开） |
| 记忆库 | meow-memory 的 SQLite：七张表 `soul/user/rules/project/fact/topic/lesson`，默认 `<工作区>/.dsh-meow/memory.db` | **服务照常起**，页面中间显示「没找到记忆库」+ 找过的路径（见 §6） |
| 端口 8787 | 只监听 `127.0.0.1:8787`（写死，改要两边同步） | 端口被占则服务无法监听 |
| （可选）另一台机器 | 想在时钟里看服务器会话时才要 WinRM + 凭据 | 只影响时钟里的服务器会话 |

**「没有记忆库」不是故障。** 这是本包故意做的软失败：服务不退出，页面讲清楚缺什么。你要做的是装上 meow-memory（§1.5）或把 `db` 指到现成的库。

## 1.5 可选依赖与推荐替代（没有这些，插件照样能装能开）

| 能力 | 本插件读什么 | 没有时的表现 | 推荐装什么 / 怎么替代 |
| --- | --- | --- | --- |
| 情感 / 心情（**可选**） | `dsh-mood.json`（当前心情 + 分值 + **历史切换记录 `history`** —— 情感面板的列表只读这个）、`dsh-mood-wish.json`（想干/不想干）；目录由 `<DSH_HOME>/dsh-mood-store.json` 的 `dir` / `dirs` 决定。⚠️ **不读** `dsh-mood-memory.jsonl`：那是 dsh-mood 的**对话归档**（给 `memory` 工具跨会话检索用），不是情绪数据 | 情感面板空、时钟上不显示心情弧；**不报错** | 装带 `dsh-mood` 的那套插件（写这两份文件即可）；不想装就把 `MEMORY_BRAIN_MOOD_DIR` 指向任何含这两份文件的目录；也可以完全不要 |
| 每日自我反思（**可选，实验性**） | `<工作区>/learn/reflection/*.py` + `history.jsonl` | 左下开关显示「未部署」、默认关闭 | 按 §0.7 部署脚本；不装就不用（默认就是关的） |
| 服务器会话（**可选**） | 工作区根的 `sync.config.json` + `python/sidecar.py` + 服务器侧 `assets/session_log.cjs`（WinRM） | 记忆时钟只显示本机会话 | 不做远程就 `remote: { enabled: false }` 或设 `MEMORY_BRAIN_REMOTE=0`；要远程见 README「记忆时钟」 |
| 技能戴森环（**可选**） | `<DSH_HOME>/skills/*/SKILL.md` | 环是空的，其余照常 | 装几个 skill 就好，2 分钟缓存 |
| 插件残片层（自动） | 当前 profile 的 `package.json` + `node_modules/<包>/package.json` | ——（总有数据） | 无需处理 |
| 记忆库（**必需**） | meow-memory 七层 SQLite | 页面显示「没找到记忆库」 | `plugin_manager` 装 npm 包 `meow-memory`（当前 0.32.4），或 web profile 用 `dsh plugin --profile web add meow-memory` |

> 记忆库这条要说清楚：**它只认 meow-memory 的表结构**。mem0 / zep / 自建库指过去也不会出图——想用这张图，就装 meow-memory。
> 已经装了 meow-memory 却还说没库？那多半是库在别的工作区：把 profile 配置里的 `db` 写成那个库的绝对路径即可（插件自己也会按最近会话的工作区去探，但显式配置最稳）。

## 2. 安装

### 2A 桌面版（首选；桌面版**没有** `dsh` 命令，别去找 CLI）

1. 把 zip 解压到一个固定目录（别放临时目录），拿到里面的 `memory-brain-graph-<版本>.tgz` 绝对路径。
2. 让当前会话的 AI 调**插件管理工具**装它：

   ```
   plugin_manager(action="install_bundle", target="file:<tgz 的绝对路径>")
   ```

   它会用 DSH 自带的 pnpm 把这个 tgz 装进当前 profile（`dependencies` 表现为 `file:`）。装的过程中可能会联网解析其它已装依赖，这是正常的。
3. **完全退出 DSH 再打开**（不是刷新窗口）。

> 别带用户去插件市场里找「从本地文件安装」——市场面板的「本机插件」只有停用/启用/卸载，没有本地 tgz 入口。

### 2B web profile / 机器上有 `dsh` 命令

```bash
dsh plugin --profile <profile 名> add file:<tgz 绝对路径>
```

装完重启 `dsh web`。

### 2C 手工兜底（没有 CLI、插件管理工具也用不了时）

1. 把解压后的整个目录（含 `package.json`）放到 `<DSH_HOME>/profiles/<profile>/node_modules/memory-brain-graph/`（junction 也行）。
2. 在 `<profile>/package.json` 的 `dependencies` 里加 `"memory-brain-graph": "link:<该目录绝对路径>"`。
3. 在 `<profile>/package.json` 的 `dsh.profile.bundles` 里加 `"memory-brain-graph"`。
4. 重启 DSH。

## 3. 配置（`<profile>/cordis.patch.yml`，整条可选）

```yaml
- insert:
    - id: memory-brain-graph
      name: 'memory-brain-graph'
      config:
        enabled: true
        port: 8787          # 客户端写死 8787；要换端口得同时改 client.js 里的 PORT
        keepAliveSec: 30    # 服务托管：每 N 秒探活，挂了自动拉起
        python: ''          # 留空自动找：配置 → MEMORY_BRAIN_PYTHON → DSH 运行时 → PATH
        db: ''              # 留空自动找；找不到时页面会显示「没找到记忆库」
        # 情感数据不在默认位置时指过去（也可用环境变量 MEMORY_BRAIN_MOOD_DIR）
        # remote:           # 可选：另一台机器上的会话
        #   enabled: true
        #   host: '<服务器地址>'
        #   user: '<账号>'
        #   credentialTarget: 'TERMSRV/<服务器地址>'
        #   dshHome: '<服务器上的 DSH_HOME>'
        #   node: '<服务器上的 node.exe>'
```

不写这一条也能用（走默认值）。

## 4. 你必须按目标机器改的占位符

- `<profile>`：目标 profile 名（桌面版一般 `desktop`）。
- `db`：记忆库绝对路径；不写就自动找。
- `python`：python 绝对路径（推荐 DSH 自带的那个）。
- `remote.*`：服务器地址、账号、凭据条目名、服务器上的 DSH_HOME 与 node 路径。
- 服务器侧要把 `assets/session_log.cjs` 放到 `<remoteDshHome>/plugins/memory-brain-graph/assets/`（只用于解压会话日志）。

## 5. 启动与验证（按顺序做，别跳）

1. 重启 DSH（或让插件热重载）。
2. 等 5–15 秒，确认端口在听：`netstat -ano | findstr :8787`。
3. 接口自检：
   - `GET http://127.0.0.1:8787/api/pulse` → 200 JSON（带 `dbMissing:true` 也算服务正常）
   - `GET http://127.0.0.1:8787/api/graph` → 200；有库时 `stats.nodes > 0`，没库时 `dbMissing:true` 且 `searched` 列出找过的路径
   - `GET http://127.0.0.1:8787/api/plugins` / `api/skills` → 返回 profile 已装插件 / skills
4. 打开页面：输入框右侧「脑图」按钮，或会话标签「脑图」。
5. 交互自检：滚轮缩远 → 记忆时钟成型 → 继续缩远 → 插件残片轨道 + 技能戴森环。

**页面三种状态对应三件事**：

- **有环、有点、有连线** → 一切正常。
- **中间一块「没找到记忆库」** → 服务正常、缺库（§1.5 最后一行）。
- **白屏/连页面都没有** → 服务没起来：查 python、端口、插件是否真的进了 profile。

## 6. 常见「假故障」——先看这里，别乱查

| 你看到的 | 其实是什么 | 正确做法 |
| --- | --- | --- |
| `Error: Host Cordis inspect provider "config" is not registered` | 查询运行时状态时把 provider 名写成了 `config`，这个名字不存在 | 先用 `cordis_inspect_list` 拿到真实 provider 名再查；**与本插件无关** |
| `Config.listConfigs` 里本插件 `status absent` / 没有 config schema | 本插件不声明 schemastery schema，本来就没有配置项可列 | 判断装没装看 profile 的 `dependencies` + `bundles`，或直接看 8787 端口 |
| 脑图里只有星空 / 中间写「没找到记忆库」 | 没装 meow-memory，或库在别的工作区 | 装 meow-memory；或把 `db` 指到现成的库 |
| 只装了 zip、没装里面的 tgz | 插件根本没进 profile，页面上当然没有「脑图」入口 | 按 §2 把 tgz 装上 |
| 反思开关显示「未部署」 | 没部署 `learn/reflection/` 脚本（默认状态） | 不需要就保持关闭，别替用户开 |

## 7. 真实故障处置

| 现象 | 原因 | 处置 |
| --- | --- | --- |
| 端口 8787 被占 | 同一插件有多个副本进程（旧目录副本也会抢） | `netstat -ano | findstr :8787`，结束重复进程，只留一个 |
| 页面连不上、端口没听 | python 找不到 / 服务被别的程序杀了 | 显式配置 `python`；重启 DSH；看插件日志 |
| 有图但记忆节点很少/不对 | 库路径错或库是旧的 | 显式配置 `db`；确认七张表存在 |
| 时钟/残片/技能环不出现 | 没缩远到阈值 | 先点「记忆时钟」，继续缩远；往回缩会按原路退场 |
| 服务器会话连不上 | WinRM / 凭据 / 服务器侧缺 `session_log.cjs` | 检查 `sync.config.json`、5985 端口、`TERMSRV/<地址>`；失败会保留上次缓存 |

## 8. 隐私与安全

- 包内**不含**任何本机路径、账号、IP、凭据或用户数据；示例都是 `<占位符>`。
- 凭据一律交给系统凭据管理器，不要把明文密码写进配置或本文件。
- 服务只监听 `127.0.0.1`。

## 8.5 三元图（可选，纯本地）

把「要被反思的东西」按 **感知 / 思索 / 实践** 三个权重摆成三角坐标，用来找出偏科的对象
（只有动作没有判断、只有思考但自己不会被触发等）。

- **数据从哪来**：`learn/reflection/triads.py` 扫 `~/.dsh/skills/*/SKILL.md` 和工作区 `plugins/`，
  按关键词密度估三个轴的权重，写 `plugins/memory-brain-graph/assets/organs/triads.json`。
  **不手填、不上传、不调模型。**
- **怎么重算**：`python learn/reflection/triads.py`，然后刷新页面（页面读静态 json）。
- **看哪里**：脑图底部按钮「三元图」→ 右侧面板。离顶点越近＝该轴越强；靠中心＝三轴都弱（不是均衡）。
- **三轴全 0 的对象**（正文太短或只是转发入口）图上不画，面板里会列出名字——不静默吞掉。
- 这是**粗估**：分得清「偏思辨 / 偏执行」，但分数不该当精确值用。

### 唤醒寄存器（和三元图共用一份数据）

`learn/wakeups.json` 声明「谁在什么时机自己动」。只有 `status: active` 的才算已接管——
**只是登记、没接上执行体的必须写 `pending`**，否则页面会撒谎。

- 页面右上角一行：`唤醒 · 已接管 4/6 · 在补 2：…`。有待补时是暖色，补全后转青绿显示「已补全」。
- 右侧面板打开时这行会淡出，避免压在面板标题上。
- 新增一个唤醒项要三件一起做：① 真接上执行体（计划任务 / 脚本）；② 在 `wakeups.json` 登记 `active`；③ 写 `verified` 说明什么时候验过。缺一件都别标 active。

## 8.55 技能零件与组装（这个包自带的零件体系）

包根目录的 `SKILL-ASSEMBLY.md` 是**自动组装脚本的施工图**（读者是 AI）：从零做出
`parts.py`（拆 `##` 章节、中英双语判层、抓 `deps`、标 `local`）→
`assemblies.py`（一个执行体被 ≥2 个 skill 引用且零件 ≥2 → 组件库）→
`compose.py`（分词/IDF 打分/缺层判定/装配单、`--review` 五动作）。
还写了三个触发点（定期/按需/体检）、幂等与原子写、以及接进反思开关的接口形态
（`POST /api/reflect/assemble`，缺脚本回 200 + `needScript`）。

要点：脚本在工作区 `learn/reflection/`（parts.py / assemblies.py / compose.py），
产物在本包 `assets/organs/`（parts.json / assemblies.json）。**只装包不装脚本也能用**，
只是没法重新拆解；光缆树的「花亮不亮」读的就是 `parts.json` 的零件数，所以想点亮花就得跑 parts.py。

**开关与接口（0.5.x）**：左下角反思控制栏是**一个总开关**——`auto` 与 `assemble` 两个字段一起开关，
设置落在 `.dsh-meow/reflect-settings.json`（老文件没有 `assemble` 时跟随 `auto`）。
`GET /api/reflect/status` 同时返回两者；`POST /api/reflect/auto {on, assemble}` 切换；
`POST /api/reflect/assemble` 手动跑一次 `parts.py`（返回 `{ok, sec, counts, out, err}`，
实测约 1 秒、返回 45 技能 / 264 零件）。**注意**：切换 `auto` 会真的启用/禁用那四个反思计划任务，
别人机器上别替用户乱拨。

## 8.6 光缆树 / 技能树视图（新增，纯本地）

底栏「光缆树」是一个独立视图：整棵树由发光晶体堆成（**没有实体树干/枝条**），花代表技能，
近白色的丝线表示技能之间的前置关系，底部是 CPU。它不参与脑图的缩放分层。

### 数据来源（三份本地文件 + 两个接口）

| 用途 | 位置 | 缺了会怎样 |
|---|---|---|
| 技能清单 | `/api/skills`（server.py 现成接口） | 花全变成「技能 #N」占位 |
| 前置关系 | `assets/skill-deps.json`（13 条边，手写） | 丝线退回「按列表顺序连」的简单模式 |
| 零件数（解锁判据） | `assets/organs/parts.json`（45 技能 / 264 零件） | 解锁退回「记忆提及次数」判据，颜色会不准 |
| 辅助证据 | `/api/skill-usage`（server.py 现成接口） | 只影响提示里的一句话，不影响画面 |

### 部署时**必须**做的三件事

1. `assets/server.py` 的静态资源白名单要包含 `.js` 和 `.css`（本包已含）。缺了 `tree.js` 会 404，页面切过去是**全黑**。
2. 部署文件清单里要有这三个新文件：`assets/tree.js`、`assets/skill-deps.json`、`assets/organs/parts.json`。
   漏掉不会报错，只会**静默降级**，肉眼看不出。
3. 改完 `server.py` 要重启页面服务（本机可手动起；服务器上通常靠插件保活自己拉起，约 30~60 秒）。

### 验证（按顺序做，别跳）

```powershell
# 1) 三个资源都要 200
iwr http://127.0.0.1:8787/tree.js            -UseBasicParsing | % StatusCode
iwr http://127.0.0.1:8787/skill-deps.json    -UseBasicParsing | % StatusCode
iwr http://127.0.0.1:8787/organs/parts.json  -UseBasicParsing | % StatusCode
# 2) 新接口
iwr http://127.0.0.1:8787/api/skill-usage    -UseBasicParsing | % StatusCode
# 3) 真页面：打开 ?view=tree，应看到晶体树 + 左侧技能树面板（30 行）
```

### 常见「假故障」

- **切过去全黑**：`tree.js` 404（白名单没加 `.js`，或文件没推）。
- **有树但没有花/花全同色**：`organs/parts.json` 没推 → 退回辅助判据；或者所有技能零件都 <4。
- **没有白色丝线**：`skill-deps.json` 没推 → 退回顺序链（仍会画线，但语义不对）。
- **点花没反应**：先确认页面刷新到了最新版；再看是不是停在旧缓存（服务端对静态资源设了 no-store，正常刷新即可）。
- **点空白处弹出了记忆点的简介**：那是旧版行为，新版在树模式下已整体关掉脑图节点拾取（`pick()` 直接返回 null）。
- **服务器上树是空白的、但本机正常**：多半是 `assets/` 下的新文件没推全，逐个 GET 上面三个 URL 确认。

### 解锁规则（改之前先读）

`assets/tree.js` 里 `UNLOCK_PARTS = 4`：技能在 `organs/parts.json` 里的 `parts` ≥4 → 花亮金（真的会）；
否则青色。面板顶部和点青色花时的提示里写着一份**给 AI 自己看的解锁说明**：
把该技能的 `SKILL.md` 拆成 ≥4 个可执行零件（感知/思索/实践），重新生成 parts.json 即会点亮。
不要为了让花变亮去改阈值——阈值是判据，不是装饰。

### 前置关系怎么维护

`assets/skill-deps.json`：`{"deps": {"后继技能id": ["前置技能id"]}}`。
id 必须与 `/api/skills` 的 id 一致；只写有把握的边，没写的一律当根技能。
改完刷新即可，不需要重启服务，也不需要重新部署（除非是在服务器上改）。

## 9. 版本要点（不影响安装步骤）

- **0.4.2**：手动反思（`reflection.json` 的 `manual` 字段，页面左下角单独一块）+ 三元图（底部按钮，感知/思索/实践）；三个反思写入方改成「写盘前保留 manual」；`auto_reflect` 每轮顺手重算三元图。
- **0.4.1**：缺库改成软失败（服务不退 + 页面给安装提示）；找库新增「按最近会话的工作区反查」；说明补了可选依赖与推荐替代。
- **0.4.0**：反思层（待反思 / 已反思 / 一条结论一颗星）、四个 `/api/reflect/*` 接口、`skills/reflection-ops`。
- **0.3.0**：指针碎片飞入拼合、对时过渡、魔法阵、首次进入自动弹一次使用说明（`localStorage.mbg_help_seen`）。
