/**
 * memory-brain-graph —— Client 半边
 *
 * 两个入口：
 *   · 输入框右侧「脑图」按钮 → 新标签打开
 *   · 会话视图「脑图」标签页 → 内嵌 iframe，直接在 DSH 里看
 *
 * ⚠️ 注册 id 必须等于 loader entry 名（包名），否则 ModuleLoader 会报
 *    "loaded without registering memory-brain-graph"，整个客户端半边不出现。
 */

window.__ModuleLoader__.load({
  id: 'memory-brain-graph',
  factory: (require) => {
    var module = { exports: {} };
    var exports = module.exports;
    Object.defineProperty(exports, Symbol.toStringTag, { value: 'Module' });

    const React = require('react');

    // Host 侧默认端口；改端口的话两边要一起改
    const PORT = 8787;
    const URL = 'http://127.0.0.1:' + PORT + '/';

    const OpenButton = () => React.createElement('button', {
      type: 'button',
      title: '记忆脑图（新标签打开）',
      onClick: () => {
        try { window.open(URL, '_blank', 'noopener'); } catch (e) { /* 忽略 */ }
      },
      style: {
        display: 'inline-flex',
        alignItems: 'center',
        height: '26px',
        padding: '0 9px',
        marginLeft: '2px',
        fontSize: '12px',
        lineHeight: 1,
        whiteSpace: 'nowrap',
        cursor: 'pointer',
        borderRadius: '7px',
        color: 'var(--dsw-alias-label-primary)',
        background: 'var(--dsw-alias-bg-layer-2)',
        border: '1px solid var(--dsw-alias-border-l1)',
      },
    }, '脑图');

    const MapView = () => React.createElement('iframe', {
      src: URL,
      title: '记忆脑图',
      style: {
        width: '100%',
        height: '100%',
        border: '0',
        display: 'block',
        background: 'transparent',
      },
    });

    const inject = ['slots'];

    function apply(ctx) {
      const slots = ctx.get('slots');
      if (slots === undefined) return;

      slots.inject('conversation.input.right', () => slots.register(
        { name: 'conversation.input.right', id: 'brain-map-open', order: 41, label: '记忆脑图' },
        () => React.createElement(OpenButton, null),
      ));

      slots.inject('conversation.view', () => slots.register(
        { name: 'conversation.view', id: 'brain-map-view', order: 61, label: '脑图' },
        () => React.createElement(MapView, null),
      ));
    }

    module.exports = { name: 'memory-brain-graph', inject, apply };
    return module.exports;
  },
});
