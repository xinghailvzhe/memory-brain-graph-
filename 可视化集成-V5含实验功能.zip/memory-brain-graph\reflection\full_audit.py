# -*- coding: utf-8 -*-
"""全量自检：把整个记忆库拉出来做基础框架 / 兼容度审计。
产出：learn/reflection/audit-YYYYMMDD.md + 把结论写进页面用的 reflection.json。
"""
import sqlite3
import json
import os
import datetime
from collections import Counter, defaultdict

import reflect_store

HERE = os.path.dirname(os.path.abspath(__file__))
WORKSPACE = os.environ.get("REFLECT_WORKSPACE") or os.path.dirname(os.path.dirname(HERE))
DB = os.environ.get("REFLECT_DB") or os.path.join(WORKSPACE, ".dsh-meow", "memory.db")
OUT_REPORT = os.path.join(HERE, "audit-%s.md" % datetime.datetime.now().strftime("%Y%m%d"))
OUT_JSON = os.environ.get("REFLECT_OUT") or os.path.join(
    WORKSPACE, "plugins", "memory-brain-graph", "assets", "organs", "reflection.json")
LEVELS = ["soul", "user", "project", "fact", "lesson", "topic", "rules"]
NAME = {"soul": "灵魂", "user": "用户", "project": "项目", "fact": "事实",
        "lesson": "经验", "topic": "话题", "rules": "准则"}


def norm(t):
    return "".join((t or "").split()).lower()[:40]


def main():
    conn = sqlite3.connect(DB)
    total = 0
    per_level = {}
    status = Counter()
    no_kw = 0
    titles = []
    projects = Counter()
    dup = defaultdict(list)
    for lv in LEVELS:
        try:
            cur = conn.execute("SELECT * FROM %s" % lv)
            cols = [c[0] for c in cur.description]
            rows = []
            for r in cur.fetchall():
                rr = dict(zip(cols, r))
                rows.append((rr.get("id", ""), rr.get("title", ""), rr.get("keywords", ""),
                             rr.get("status", "active"), rr.get("project", "")))
        except Exception:
            continue
        per_level[lv] = len(rows)
        total += len(rows)
        for rid, title, kw, st, proj in rows:
            status[st or "active"] += 1
            kw = (kw or "").strip()
            if len([k for k in kw.replace(",", " ").split() if k]) < 3:
                no_kw += 1
            if title:
                titles.append((lv, rid, title))
                dup[norm(title)].append((lv, title))
            if proj and proj != "全局":
                for p in proj.split(","):
                    projects[p.strip()] += 1
    conn.close()

    dup_conflicts = {k: v for k, v in dup.items() if len(v) > 1}
    stale_ratio = status.get("stale", 0) / max(1, total)
    arch_ratio = status.get("archived", 0) / max(1, total)

    lines = []
    lines.append("全量 %d 条 · 分层 %s" % (total, " / ".join("%s %d" % (NAME[lv], per_level.get(lv, 0)) for lv in LEVELS)))
    lines.append("状态 active %d · stale %d · archived %d" % (status.get("active", 0), status.get("stale", 0), status.get("archived", 0)))
    lines.append("关键词过少 %d 条 · 疑似重复标题 %d 组 · 项目维度 %d 个" % (no_kw, len(dup_conflicts), len(projects)))

    # 兼容度/框架问题清单（规则判定）
    issues = []
    if no_kw:
        issues.append("关键词覆盖不足：%d 条记忆关键词少于 3 个，检索命中率会掉" % no_kw)
    if stale_ratio > 0.15:
        issues.append("stale 占比 %.0f%%，说明完成/过时条目没有及时归位" % (stale_ratio * 100))
    big_p = [p for p, c in projects.most_common(3)]
    if big_p:
        issues.append("条目最集中的项目：%s —— 单项目信息密度过高时按主题拆成 topic 更利于检索" % "、".join(big_p))
    if len(dup_conflicts):
        issues.append("疑似重复标题 %d 组：同名条目应合并或标 stale，避免检索时互相稀释" % len(dup_conflicts))

    md = ["# 记忆库全量自检 · %s" % datetime.datetime.now().strftime("%Y-%m-%d %H:%M"), ""]
    md += ["## 规模", "", "| 层 | 条数 |", "|---|---|"]
    for lv in LEVELS:
        md.append("| %s | %d |" % (NAME[lv], per_level.get(lv, 0)))
    md += ["", "- 合计：%d" % total, "- 状态：%s" % json.dumps(dict(status), ensure_ascii=False)]
    md += ["", "## 问题与优化", ""]
    md += ["- " + s for s in (issues or ["未发现结构性问题"])]
    md += ["", "## 项目分布（前 10）", "", "| 项目 | 条数 |", "|---|---|"]
    for p, c in projects.most_common(10):
        md.append("| %s | %d |" % (p, c))
    if dup_conflicts:
        md += ["", "## 疑似重复标题", ""]
        for k, v in list(dup_conflicts.items())[:20]:
            md.append("- " + " / ".join(x[1] for x in v))
    with open(OUT_REPORT, "w", encoding="utf-8") as f:
        f.write("\n".join(md))

    now = datetime.datetime.now()
    prev_absorbed = []
    prev_manual = None
    try:
        with open(OUT_JSON, "r", encoding="utf-8") as f:
            _prev = json.load(f)
        prev_absorbed = _prev.get("absorbedIds") or []
        prev_manual = _prev.get("manual")
    except Exception:
        pass
    data = {
        "date": now.strftime("%Y-%m-%d"),
        "updatedAt": now.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        "autoAt": now.strftime("%m-%d %H:%M"),
        "tokens": 0,
        "summary": "全量自检 · %d 条 · 关键词过少 %d · 重复组 %d" % (total, no_kw, len(dup_conflicts)),
        "lines": lines[:3],
        "newIds": [],
        "absorbedIds": sorted(set(map(str, prev_absorbed))),
    }
    # 手动反思（note.py 写的 manual）不能被全量自检覆盖掉
    if prev_manual:
        data["manual"] = prev_manual
    with open(OUT_JSON, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    reflect_store.append({
        "at": now.strftime("%Y-%m-%dT%H:%M:%S"),
        "atMs": int(now.timestamp() * 1000),
        "kind": "audit",
        "summary": data["summary"],
        "lines": lines[:3],
        "tokens": 0,
        "model": "",
        "ids": [],
    })
    print("report:", OUT_REPORT)
    print("total:", total, "no_kw:", no_kw, "dup:", len(dup_conflicts), "projects:", len(projects))
    print("\n".join(lines))


if __name__ == "__main__":
    main()
