# -*- coding: utf-8 -*-
"""记忆脑图 · 本地服务
读 meow-memory 的真实库，算一套稳定的三维布局，给前端画星空脑图。
纯标准库，不装任何东西。
"""
import datetime
import glob
import json
import math
import os
import re
import shutil
import sqlite3
import subprocess
import sys
import tempfile
import time
import threading
import urllib.parse
import webbrowser
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


# 同步服务器会话是**后台**行为：从这个服务里 spawn 控制台子进程（python / node）
# 时，Windows 会给它新开一个控制台黑窗——屏幕上一闪。全部用 CREATE_NO_WINDOW 压掉。
CREATE_NO_WINDOW = 0x08000000


def _no_window():
    """spawn 时附加的「别弹窗」参数；非 Windows 返回空字典。"""
    if os.name != "nt":
        return {}
    si = subprocess.STARTUPINFO()
    si.dwFlags |= subprocess.STARTF_USESHOWWINDOW
    si.wShowWindow = 0          # SW_HIDE
    return {"creationflags": CREATE_NO_WINDOW, "startupinfo": si}


def _arg_value(flag):
    """取 `--flag value` 形式的值，没有就返回空串"""
    argv = sys.argv[1:]
    if flag in argv:
        i = argv.index(flag)
        if i + 1 < len(argv):
            return argv[i + 1]
    return ""


def _dsh_home():
    return os.environ.get("DSH_HOME") or os.path.join(os.path.expanduser("~"), ".dsh")


def _proj_cache_dir():
    return (os.environ.get("MEMORY_BRAIN_PROJCACHE")
            or os.path.join(_dsh_home(), "storages", "session_projcache", "sessions"))


def _recent_workspaces(limit=24):
    """最近活跃过的几个工作区。

    为什么要这个：插件是由 DSH 宿主拉起的，宿主进程的当前目录**不一定是工作区**
    （从快捷方式/开始菜单启动时不是，从别的目录启动也不是）。只靠 os.getcwd()
    往上找 .dsh-meow，就会出现「明明装了 meow-memory、库里有几百条，页面却说没有库」。
    会话投影缓存里每个会话都记着自己的 cwd，据此反推最稳。
    """
    out = []
    try:
        files = sorted(glob.glob(os.path.join(_proj_cache_dir(), "*.json")),
                       key=os.path.getmtime, reverse=True)[:limit]
    except Exception:
        return out
    for f in files:
        try:
            with open(f, "r", encoding="utf-8") as fh:
                rec = (json.load(fh) or {}).get("record") or {}
            cwd = ((rec.get("identity") or {}).get("cwd")
                   or (((rec.get("rows") or {}).get("workingDirectory") or {}).get("val"))
                   or "")
            if isinstance(cwd, str) and cwd and os.path.isdir(cwd) and cwd not in out:
                out.append(cwd)
        except Exception:
            continue
    return out


def _default_dbs():
    """通用候选：环境变量 → 当前目录往上找 → 最近活跃的工作区 → 用户目录常见位置"""
    cands = []
    env = os.environ.get("MEMORY_BRAIN_DB")
    if env:
        cands.append(env)
    cur = os.getcwd()
    for _ in range(5):
        cands.append(os.path.join(cur, ".dsh-meow", "memory.db"))
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    for ws in _recent_workspaces():
        cands.append(os.path.join(ws, ".dsh-meow", "memory.db"))
    home = os.path.expanduser("~")
    cands.append(os.path.join(home, ".dsh", "meow-memory", "memory.db"))
    cands.append(os.path.join(home, ".dsh-meow", "memory.db"))
    seen, uniq = set(), []
    for c in cands:
        k = os.path.normcase(os.path.normpath(c))
        if k in seen:
            continue
        seen.add(k)
        uniq.append(c)
    return uniq


class DbMissing(RuntimeError):
    """没有记忆库。

    注意别用 SystemExit：main() 的预计算只包了 except Exception，
    BaseException 会穿过去把整个 HTTP 服务带崩 —— 表现就是别人装完看到白屏。
    这里要的是「服务照常跑，页面自己说清缺什么」。
    """

    def __init__(self, path):
        super().__init__("找不到记忆库: " + path)
        self.path = path


DB_CANDIDATES = _default_dbs()
_given_db = _arg_value("--db")
if _given_db:
    DB_CANDIDATES.insert(0, _given_db)


def _activity(db):
    """这个库里最近一次被访问的时间（毫秒），用来判断哪个工作区还活着"""
    try:
        con = sqlite3.connect(db)
        best = 0
        for t in ("fact", "lesson", "project", "rules", "topic", "user", "soul"):
            try:
                m = con.execute("select max(last_accessed_at) from %s" % t).fetchone()[0]
                if m and m > best:
                    best = int(m)
            except Exception:
                pass
        con.close()
        return best
    except Exception:
        return 0


# 默认跟随「最近有记忆读写的那个工作区」—— 也就是你现在正在聊的这个
DB = max([d for d in DB_CANDIDATES if os.path.exists(d)] or [DB_CANDIDATES[0]],
         key=_activity)
ROOT = os.path.dirname(os.path.abspath(__file__))
def _arg_port():
    """端口：去掉 --db 那对参数之后的第一个位置参数"""
    argv = sys.argv[1:]
    if "--db" in argv:
        i = argv.index("--db")
        argv = argv[:i] + argv[i + 2:]
    return int(argv[0]) if argv else 8777


PORT = _arg_port()

# 七个记忆层级 = 七个脑区（角度方向由斐波那契球给出）
LEVELS = [
    ("soul",    "灵魂",   "#eafcff", "关于我自己"),
    ("user",    "用户",   "#7dffc4", "关于你"),
    ("rules",   "准则",   "#ffd166", "做事的原则"),
    ("project", "项目",   "#6aa9ff", "项目里的记忆"),
    ("fact",    "事实",   "#4fd6ff", "原子事实"),
    ("topic",   "话题",   "#c39bff", "事情的发展"),
    ("lesson",  "经验",   "#ffb0d9", "踩过的坑"),
]
TABLES = {k: t for (k, _, _, _) in LEVELS for t in [k]}


def parse_keywords(raw):
    if not raw:
        return []
    raw = raw.strip()
    if raw.startswith("["):
        try:
            v = json.loads(raw)
            return [str(x) for x in v if str(x).strip()]
        except Exception:
            pass
    for sep in ("，", "、", ";", "；"):
        raw = raw.replace(sep, ",")
    return [p.strip() for p in raw.split(",") if p.strip()]


def fib_sphere(n):
    """n 个大致均匀分布的单位向量"""
    pts = []
    golden = math.pi * (3.0 - math.sqrt(5.0))
    for i in range(n):
        y = 1 - (i / float(max(1, n - 1))) * 2 if n > 1 else 0.0
        r = math.sqrt(max(0.0, 1 - y * y))
        th = golden * i
        pts.append((math.cos(th) * r, y, math.sin(th) * r))
    return pts


def ortho_basis(d):
    """给一个方向，构造两个正交切向量"""
    dx, dy, dz = d
    up = (0.0, 1.0, 0.0)
    if abs(dy) > 0.9:
        up = (1.0, 0.0, 0.0)
    ux = dy * up[2] - dz * up[1]
    uy = dz * up[0] - dx * up[2]
    uz = dx * up[1] - dy * up[0]
    ln = math.sqrt(ux * ux + uy * uy + uz * uz) or 1.0
    u = (ux / ln, uy / ln, uz / ln)
    v = (dy * u[2] - dz * u[1], dz * u[0] - dx * u[2], dx * u[1] - dy * u[0])
    ln2 = math.sqrt(v[0] ** 2 + v[1] ** 2 + v[2] ** 2) or 1.0
    v = (v[0] / ln2, v[1] / ln2, v[2] / ln2)
    return u, v


def build():
    if not os.path.exists(DB):
        raise DbMissing(DB)
    con = sqlite3.connect(DB)
    con.row_factory = sqlite3.Row

    dirs = fib_sphere(len(LEVELS))
    nodes = []
    by_level = {}
    keyword_index = {}
    project_index = {}

    for li, (level, label, color, desc) in enumerate(LEVELS):
        try:
            cols = [r[1] for r in con.execute("pragma table_info(%s)" % level)]
            has_proj = "project" in cols
            sql = ("select id,title,content,importance,keywords,status,%s "
                   "hit_count,created_at,updated_at from %s"
                   % ("project," if has_proj else "'' as project,", level))
            rows = con.execute(sql).fetchall()
        except Exception:
            rows = []
        d = dirs[li]
        u, v = ortho_basis(d)
        count = len(rows)
        # 半径随该脑区条数增长，但封顶，避免压到别的脑区
        spread = min(0.15, 0.050 + 0.0007 * count)
        cluster = []
        for i, row in enumerate(rows):
            # 黄金角螺旋铺开，稳定、不重叠
            ang = i * 2.399963
            rad = spread * math.sqrt((i + 0.5) / max(1, count))
            a = math.cos(ang) * rad
            b = math.sin(ang) * rad
            # 离核心的基准距离：保持在画面中部，外围留白
            base = 0.26 + 0.06 * ((i + 0.5) / max(1, count))
            x = d[0] * base + u[0] * a + v[0] * b
            y = d[1] * base + u[1] * a + v[1] * b
            z = d[2] * base + u[2] * a + v[2] * b
            # 沿法线加一点厚度，别让每个脑区塌成一张扁平饼
            thick = (0.5 - ((i * 0.6180339887) % 1.0)) * 0.055
            x += d[0] * thick
            y += d[1] * thick
            z += d[2] * thick
            kws = parse_keywords(row["keywords"])
            nid = "%s-%s" % (level, row["id"])
            status = (row["status"] or "active").lower()
            text = (row["content"] or "").strip()
            title = (row["title"] or "").strip()
            if not title:
                # 大部分条目没写 title，就拿正文第一句当标题
                first = text.split("\n")[0].strip()
                for cut in ("。", "；", "，", " "):
                    p = first.find(cut)
                    if 6 < p < 40:
                        first = first[:p]
                        break
                title = (first[:38] or "(空)")
            node = {
                "id": nid,
                "level": level,
                "title": title,
                "text": text[:600],
                "imp": float(row["importance"] or 1),
                "status": status,
                "project": row["project"] or "",
                "hits": int(row["hit_count"] or 0),
                "created": row["created_at"] or "",
                "updated": row["updated_at"] or "",
                "kw": kws[:8],
                "x": round(x, 5), "y": round(y, 5), "z": round(z, 5),
            }
            nodes.append(node)
            cluster.append(node)
            for k in kws[:8]:
                keyword_index.setdefault(k, []).append(nid)
            if node["project"]:
                project_index.setdefault(node["project"], []).append(nid)
        by_level[level] = cluster

    edges = []
    seen = set()
    by_id = {n["id"]: n for n in nodes}
    MAXD2 = 0.36 * 0.36      # 跨层连线的最远距离，避免横穿整个屏幕

    def dist2(a, b):
        return (a["x"] - b["x"]) ** 2 + (a["y"] - b["y"]) ** 2 + (a["z"] - b["z"]) ** 2

    def add_edge(a, b, kind, w, maxd2=None):
        if a == b:
            return
        key = (a, b) if a < b else (b, a)
        if key in seen:
            return
        if maxd2 is not None:
            na, nb = by_id.get(a), by_id.get(b)
            if not na or not nb or dist2(na, nb) > maxd2:
                return
        seen.add(key)
        edges.append({"a": key[0], "b": key[1], "k": kind, "w": round(w, 3)})

    # 0) 每个脑区挑离中枢最近的若干条，连回中枢，形成放射状主干
    for level, cluster in by_level.items():
        near = sorted(cluster, key=lambda n: n["x"] ** 2 + n["y"] ** 2 + n["z"] ** 2)[:9]
        for n in near:
            key = ("core", n["id"])
            if key in seen:
                continue
            seen.add(key)
            edges.append({"a": "core", "b": n["id"], "k": "core", "w": 0.6})

    # 1) 同一层级内，按创建顺序相邻相连（形成脉络，而不是一锅粥）
    for level, cluster in by_level.items():
        for i in range(len(cluster) - 1):
            add_edge(cluster[i]["id"], cluster[i + 1]["id"], "seq", 0.45)

    # 2) 同一项目：每条记忆连到该项目里最近的一条（只在近处连，不拉长线）
    for proj, ids in project_index.items():
        if len(ids) < 2 or len(ids) > 400:
            continue
        for i in range(1, len(ids)):
            a = by_id[ids[i]]
            best, bestd = None, 1e9
            for j in range(max(0, i - 12), i):
                b = by_id[ids[j]]
                dd = dist2(a, b)
                if dd < bestd:
                    best, bestd = b, dd
            if best:
                add_edge(a["id"], best["id"], "proj", 0.8, MAXD2)

    # 3) 同关键词：只连前 6 条，且必须挨得近
    for kw, ids in keyword_index.items():
        if len(ids) < 2:
            continue
        take = ids[:6]
        for i in range(1, len(take)):
            add_edge(take[0], take[i], "kw", 0.32, MAXD2)
    stats = {
        "nodes": len(nodes),
        "edges": len(edges),
        "levels": [
            {"level": k, "label": l, "color": c, "desc": d, "n": len(by_level.get(k, [])),
             "active": sum(1 for x in by_level.get(k, []) if x["status"] == "active"),
             "stale": sum(1 for x in by_level.get(k, []) if x["status"] == "stale"),
             "archived": sum(1 for x in by_level.get(k, []) if x["status"] == "archived")}
            for (k, l, c, d) in LEVELS
        ],
        "active": sum(1 for n in nodes if n["status"] == "active"),
        "stale": sum(1 for n in nodes if n["status"] == "stale"),
        "archived": sum(1 for n in nodes if n["status"] == "archived"),
        "projects": len(project_index),
        "keywords": len(keyword_index),
        "db": DB,
    }
    return {"nodes": nodes, "edges": edges, "stats": stats}


CACHE = {"data": None}


def payload():
    if CACHE["data"] is None:
        CACHE["data"] = build()
    return CACHE["data"]


def empty_payload():
    """没有记忆库时给前端的正式响应：空图 + 缺库标记 + 找过的路径。

    返回 200 而不是 500，是因为「没库」不是服务故障 —— 前端要能拿到
    dbMissing 去显示安装提示，而不是停在「读取中」或者空白。
    """
    return {
        "nodes": [],
        "edges": [],
        "stats": {
            "nodes": 0, "edges": 0, "active": 0, "stale": 0, "archived": 0,
            "projects": 0, "keywords": 0, "db": DB,
            "levels": [{"level": k, "label": lbl, "color": cl, "n": 0}
                       for (k, lbl, cl, _desc) in LEVELS],
        },
        "dbMissing": True,
        "db": DB,
        "searched": DB_CANDIDATES[:10],
        "error": "找不到记忆库: " + DB,
        "hint": "装 meow-memory 插件（记忆会落到工作区的 .dsh-meow/memory.db），"
                "或在 profile 的 cordis.patch.yml 里把 db 指到现成的库",
    }


def pulse(since_ms):
    """最近被召回的记忆。召回时 meow-memory 会写 last_accessed_at（毫秒），
    所以只读库就能知道这一轮抓了哪几条 —— 不用再问模型，零 token。"""
    if not os.path.exists(DB):
        return {"hits": [], "now": int(time.time() * 1000),
                "dbMissing": True, "db": DB}
    try:
        con = sqlite3.connect(DB)
        con.row_factory = sqlite3.Row
    except Exception:
        return {"hits": [], "now": int(time.time() * 1000)}
    out = []
    for level, label, color, _desc in LEVELS:
        try:
            rows = con.execute(
                "select id,title,last_accessed_at,hit_count from %s "
                "where last_accessed_at > ? order by last_accessed_at" % level,
                (since_ms,)).fetchall()
        except Exception:
            continue
        for r in rows:
            if (r["hit_count"] or 0) <= 0:
                continue          # 写入时也会打时间戳，hits=0 的排除掉
            out.append({
                "id": "%s-%s" % (level, r["id"]),
                "level": level,
                "label": label,
                "at": int(r["last_accessed_at"]),
                "title": (r["title"] or "")[:40],
            })
    out.sort(key=lambda x: x["at"])
    return {"hits": out, "now": int(time.time() * 1000)}


# dsh-mood 的数据目录会搬家：以插件自己的仓库指针为准，别在这里写死默认路径。
# 指针文件 ~/.dsh/dsh-mood-store.json：{"dir": "...", "default": "...", "dirs": {工作区: "..."}}
MOOD_DIR_DEFAULT = os.path.join(
    os.environ.get("DSH_HOME") or os.path.join(os.path.expanduser("~"), ".dsh"),
    "dsh-mood-data")


def _mood_dir_candidates():
    out = []
    env = os.environ.get("MEMORY_BRAIN_MOOD_DIR")
    if env:
        out.append(env.strip())
    home = _dsh_home()
    try:
        with open(os.path.join(home, "dsh-mood-store.json"), "r", encoding="utf-8") as fh:
            st = json.load(fh)
        for key in ("dir", "default"):
            v = st.get(key)
            if isinstance(v, str) and v.strip():
                out.append(v.strip())
        dirs = st.get("dirs")
        if isinstance(dirs, dict):
            for v in dirs.values():
                if isinstance(v, str) and v.strip():
                    out.append(v.strip())
    except Exception:
        pass            # 没有指针文件就退回默认位置
    out.append(MOOD_DIR_DEFAULT)
    seen, uniq = set(), []
    for p in out:
        try:
            k = os.path.normcase(os.path.normpath(p))
        except Exception:
            k = p
        if k in seen:
            continue
        seen.add(k)
        uniq.append(p)
    return uniq


def mood_dir():
    """多候选取「dsh-mood.json 最新」的那个目录；一个都读不到就返回默认目录。"""
    best, best_m = None, -1
    for p in _mood_dir_candidates():
        try:
            m = os.path.getmtime(os.path.join(p, "dsh-mood.json"))
        except Exception:
            if best is None and os.path.isdir(p):
                best = p
            continue
        if m > best_m:
            best, best_m = p, m
    return best or MOOD_DIR_DEFAULT


WISH_FILE = "dsh-mood-wish.json"


def wish_payload(mdir):
    """「我想干的 / 我不想干的」——我自己的愿望清单，放在情感数据目录里，跟着心情数据一起搬。
    items 里每条可以是字符串（老格式，算「想干的」），也可以是 {"text","kind"}：
    kind=want → 想干的；kind=dont → 不想干的。两组分开返回，前端分两段显示。"""
    out = {"ok": False, "items": [], "donts": [], "updatedAt": 0}
    try:
        with open(os.path.join(mdir, WISH_FILE), "r", encoding="utf-8") as fh:
            st = json.load(fh)
        for it in (st.get("items") or []):
            kind = "want"
            if isinstance(it, str):
                txt = it.strip()
            elif isinstance(it, dict):
                txt = (it.get("text") or "").strip()
                kind = str(it.get("kind") or "want").strip().lower()
            else:
                txt = ""
            if not txt:
                continue
            if kind in ("dont", "no", "unwant", "avoid", "不想", "不想干"):
                out["donts"].append(txt[:200])
            else:
                out["items"].append(txt[:200])
        out["updatedAt"] = int(st.get("updatedAt") or 0)
        out["ok"] = True
    except Exception:
        pass
    return out


# 心情 id → 中文名。**镜像 lib/mood/index.js 的 MOODS[*].label**：
# 那边加一种心情时这边要跟着加，漏了不会崩，只会退化成显示英文 id。
MOOD_LABELS = {
    "calm": "平静", "happy": "开心", "curious": "好奇", "focused": "专注",
    "excited": "兴奋", "tired": "疲惫", "annoyed": "烦躁", "down": "低落",
    "sulk": "生闷气", "hurt": "委屈", "proud": "得意", "gloomy": "消沉",
    "anxious": "焦虑", "numb": "麻木", "lonely": "孤单", "flutter": "心动",
    "love": "恋慕", "jealous": "吃醋", "burnout": "内耗", "cracked": "破防",
    "checkedout": "摆烂", "hyper": "上头", "fear": "恐惧", "disgust": "厌恶",
    "surprise": "惊讶", "shame": "羞耻", "guilt": "内疚", "awkward": "尴尬",
    "sympathy": "同情", "disappointed": "失望", "nostalgia": "怀旧", "coy": "撒娇",
    "conflict": "矛盾",
}

# 切换原因 → 人话。reason 由 lib/mood/index.js 的 tryTransition 调用方给。
MOOD_REASONS = {
    "user-message": "用户消息",
    "periodic": "周期判定",
    "manual-set": "手动调整",
    "manual-feel": "主动切换",
}


def mood_label(x):
    s = str(x or "").strip()
    return MOOD_LABELS.get(s, s)


def mood_switch_rows(hist, limit=30):
    """把 dsh-mood.json 的 history（**心情真的切了才有一条**）翻成面板要的行。

    ⚠️ **不带 around.lastUser，也不带 around.words。**
       那两个字段是从对话里抠出来的原文/词（实测 words 是「记忆」「任务」这种），
       情绪面板里出现工作对话就是这么来的 —— 要的是"什么时候从什么心情变成什么心情"，
       不是"当时在聊什么"。
    """
    rows = []
    for h in (hist or []):
        if not isinstance(h, dict):
            continue
        reason = str(h.get("reason") or "").strip()
        rows.append({
            "t": int(h.get("at") or 0),
            "from": mood_label(h.get("from")),
            "to": mood_label(h.get("to")),
            "reason": MOOD_REASONS.get(reason, reason),
        })
    return rows[-max(1, limit):][::-1]


def mood_payload():
    """情感日记/心情：当前心情各分值 + 最近的**心情变化** + 我自己想干/不想干的事。

    ⚠️ 这里**不读 dsh-mood-memory.jsonl**，那不是情绪数据。
       那个文件是「硬盘记忆」——对话正文归档，给 `memory` 工具跨会话检索用
       （见 lib/mood/memory.js 开头那段说明）。以前这个接口把它的最后 80 行
       当"情绪记忆"塞给情感面板，于是工作对话（"把新的压成 zip"这种指令）
       原封不动出现在情感日记里 —— 面板该显示的是心情自己变过几次，不是聊天记录。
    """
    out = {"ok": False, "current": "", "currentLabel": "", "values": [], "recent": [], "count": 0,
           "dir": "", "wish": {"ok": False, "items": [], "donts": [], "updatedAt": 0}}
    mdir = mood_dir()
    out["dir"] = mdir
    out["wish"] = wish_payload(mdir)
    try:
        st_path = os.path.join(mdir, "dsh-mood.json")
        if os.path.exists(st_path):
            with open(st_path, "r", encoding="utf-8") as fh:
                st = json.load(fh)
            out["current"] = st.get("current") or ""
            out["currentLabel"] = mood_label(out["current"])
            vals = st.get("values") or {}
            pairs = [{"k": k, "v": round(float(v), 1)} for k, v in vals.items()
                     if isinstance(v, (int, float))]
            pairs.sort(key=lambda x: -x["v"])
            out["values"] = pairs[:8]
            hist = st.get("history") or []
            out["recent"] = mood_switch_rows(hist)
            out["count"] = len(hist)
            out["ok"] = True
    except Exception as e:
        out["statError"] = str(e)
    return out


SYNC_STATE = os.environ.get("MEMORY_BRAIN_SYNC_STATE") or os.path.join(
    os.path.expanduser("~"), ".dsh", "storages", "meow-memory-sync", "state.json")


def sync_payload():
    """记忆同步状态：6 个同步对里最近一次成功的时间 + 下一次每日同步（13:00）的时间戳。"""
    out = {"ok": False, "last": 0, "lastPair": "", "pairs": [], "anyFail": False}
    try:
        with open(SYNC_STATE, "r", encoding="utf-8") as fh:
            st = json.load(fh)
        pairs = st.get("pairs") or {}
        rows = []
        last, last_pair, any_fail = 0, "", False
        for pid, p in pairs.items():
            ok_at = int(p.get("lastSuccessAt") or 0)
            res = (p.get("lastResult") or "").strip()
            rows.append({"id": pid, "at": ok_at, "result": res,
                         "err": (p.get("lastError") or "")[:160]})
            if ok_at > last:
                last, last_pair = ok_at, pid
            if res and res != "ok":
                any_fail = True
        rows.sort(key=lambda r: -r["at"])
        out.update({"ok": True, "last": last, "lastPair": last_pair,
                    "pairs": rows, "anyFail": any_fail,
                    "updatedAt": int(st.get("updatedAt") or 0)})
    except Exception as e:
        out["error"] = str(e)
    now = datetime.datetime.now()
    nxt = now.replace(hour=13, minute=0, second=0, microsecond=0)
    if nxt <= now:
        nxt += datetime.timedelta(days=1)
    out["next"] = int(nxt.timestamp() * 1000)
    out["now"] = int(now.timestamp() * 1000)
    return out


# ---------------------------------------------------------------------------
# 会话时间轴：记忆时钟要把「某个 10:20–10:50 的会话」挂到钟面外
# 数据源只读两个已有文件，不依赖 zstd 解压就能算时间段：
#   · ~/.dsh/storages/session_projcache/sessions/<id>.json  → createdAt / lastMessageTime / 标题 / 轮数
#   · ~/.dsh/sessions/<工作区>/<id>/session.v4.jsonl.zstd   → 点开时才读正文（交给 node 解多帧）
# ---------------------------------------------------------------------------
SESS_ROOT = os.environ.get("MEMORY_BRAIN_SESSIONS") or os.path.join(_dsh_home(), "sessions")
PROJ_DIR = _proj_cache_dir()
WORKSPACE = os.path.dirname(os.path.dirname(os.path.abspath(DB)))
# 「正在运作」的判定：日志文件或最后消息在这么多毫秒内还有动静
ACTIVE_MS = int(os.environ.get("MEMORY_BRAIN_ACTIVE_MS") or 15 * 60 * 1000)


def _norm_path(p):
    try:
        return os.path.normcase(os.path.normpath(os.path.abspath(p)))
    except Exception:
        return (p or "").replace("/", "\\").lower()


def _find_node():
    """找 node：插件拉起时会给 MEMORY_BRAIN_NODE=process.execPath，这里再兜底。"""
    cands = [os.environ.get("MEMORY_BRAIN_NODE"), shutil.which("node"), shutil.which("node.exe")]
    try:
        rt = os.path.join(_dsh_home(), "dsh-runtimes")
        for d in os.listdir(rt):
            exe = os.path.join(rt, d, "dependencies", "node", "bin",
                               "node.exe" if os.name == "nt" else "node")
            if os.path.exists(exe):
                cands.append(exe)
    except Exception:
        pass
    for c in cands:
        if c and (not os.path.isabs(c) or os.path.exists(c)):
            return c
    return None


_LOG_INDEX = {"at": 0.0, "map": {}}


def _session_log_path(sid):
    """会话 id → 日志路径。索引 30 秒，避免每次点碎片都扫目录。"""
    now = time.time()
    if now - _LOG_INDEX["at"] > 30:
        m = {}
        try:
            for ws in os.listdir(SESS_ROOT):
                d = os.path.join(SESS_ROOT, ws)
                if not os.path.isdir(d):
                    continue
                for sid2 in os.listdir(d):
                    f = os.path.join(d, sid2, "session.v4.jsonl.zstd")
                    if os.path.exists(f):
                        m[sid2] = f
        except Exception:
            pass
        _LOG_INDEX["map"] = m
        _LOG_INDEX["at"] = now
    return _LOG_INDEX["map"].get(sid, "")


# ---------------------------------------------------------------------------
# 远程会话源：让这台机器的记忆时钟也能匹配「服务器上跑着的会话」
#
#   为什么不在本机读：服务器上的会话日志平均 1 MB、最大 33 MB，整包搬回来不现实；
#   所以元数据（时间段/标题/轮数）在服务器侧压成一份小 JSON 拉回来（全量约 40 KB），
#   点开某条碎片时才在服务器侧用 node 解压出最近若干条消息（约 15 KB）。
#
#   通道：复用工作区里现成的 python/sidecar.py（WinRM + Windows 凭据管理器），
#        不引任何新依赖；找不到 sidecar / 没配服务器 → 整块静默关闭，时钟照常只有本机会话。
#   缓存：<DSH_HOME>/storages/memory-brain-graph/remote-sessions.json
#        拉取失败保留上一次结果（标 stale），不让时钟因为网络抖一下就空掉。
# ---------------------------------------------------------------------------
REMOTE_REFRESH_SEC = max(60, int(os.environ.get("MEMORY_BRAIN_REMOTE_REFRESH") or 600))
# 打开时钟时的主动同步：同一冷却窗口内只真拉一次，来回缩放/变形不重复打扰服务器
REMOTE_SYNC_COOLDOWN = max(1.0, float(os.environ.get("MEMORY_BRAIN_REMOTE_SYNC_COOLDOWN") or 10))
_REMOTE = {"cfg": None, "entries": [], "fetchedAt": 0, "error": "", "busy": False,
           "askedAt": 0.0}
_REMOTE_LOCK = threading.Lock()


def _remote_enabled_env():
    v = (os.environ.get("MEMORY_BRAIN_REMOTE") or "").strip().lower()
    return v not in ("0", "off", "false", "no")


def _find_sidecar():
    """找 python/sidecar.py：环境变量 → 插件目录逐级向上（工作区根下的 python/）"""
    cands = []
    env = (os.environ.get("MEMORY_BRAIN_SIDECAR") or "").strip()
    if env:
        cands.append(env)
    cur = os.path.dirname(os.path.abspath(__file__))
    for _ in range(4):
        cands.append(os.path.join(cur, "python", "sidecar.py"))
        parent = os.path.dirname(cur)
        if parent == cur:
            break
        cur = parent
    for c in cands:
        try:
            if c and os.path.exists(c):
                return c
        except Exception:
            pass
    return ""


def _remote_config():
    """读 sync.config.json / 环境变量；返回 None = 不启用远程源"""
    if not _remote_enabled_env():
        return None
    cfg = {}
    for p in ((os.environ.get("MEMORY_BRAIN_SYNC_CONFIG") or "").strip(),
              os.path.join(WORKSPACE, "sync.config.json")):
        if not p or not os.path.exists(p):
            continue
        try:
            with open(p, "r", encoding="utf-8-sig") as fh:
                cfg = json.load(fh) or {}
            break
        except Exception:
            cfg = {}
    host = (os.environ.get("MEMORY_BRAIN_REMOTE_HOST") or cfg.get("host") or "").strip()
    dsh_home = (os.environ.get("MEMORY_BRAIN_REMOTE_DSH_HOME")
                or cfg.get("remoteDshHome") or "").strip().replace("/", "\\").rstrip("\\")
    sidecar = _find_sidecar()
    if not host or not dsh_home or not sidecar:
        return None
    return {
        "host": host,
        "port": int(os.environ.get("MEMORY_BRAIN_REMOTE_PORT") or cfg.get("port") or 5985),
        "user": (os.environ.get("MEMORY_BRAIN_REMOTE_USER") or cfg.get("user") or "administrator").strip(),
        "credential": (os.environ.get("MEMORY_BRAIN_REMOTE_CREDENTIAL")
                       or cfg.get("credentialTarget") or ("TERMSRV/" + host)).strip(),
        "dsh_home": dsh_home,
        "node": (os.environ.get("MEMORY_BRAIN_REMOTE_NODE") or cfg.get("remoteNode") or "").strip(),
        "sidecar": sidecar,
        "python": sys.executable or "python",
    }


def _remote_cache_path():
    d = os.path.join(_dsh_home(), "storages", "memory-brain-graph")
    try:
        os.makedirs(d, exist_ok=True)
    except Exception:
        pass
    return os.path.join(d, "remote-sessions.json")


def _remote_index_script(cfg):
    """服务器侧：把 projcache 压成精简时间轴（一行 @@JSON@@ 返回）"""
    proj = cfg["dsh_home"] + "\\storages\\session_projcache\\sessions"
    sess = cfg["dsh_home"] + "\\sessions"
    return r"""
$ErrorActionPreference='Stop'
[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new()
$p=__PROJ__
$s=__SESS__
$logs=@{}
foreach($d in Get-ChildItem -LiteralPath $s -Directory){
  foreach($q in Get-ChildItem -LiteralPath $d.FullName -Directory){
    $f=Join-Path $q.FullName 'session.v4.jsonl.zstd'
    if(Test-Path -LiteralPath $f){$it=Get-Item -LiteralPath $f;$logs[$q.Name]=@($f,[long]([DateTimeOffset]$it.LastWriteTime).ToUnixTimeMilliseconds())}
  }
}
$out=New-Object System.Collections.ArrayList
foreach($f in Get-ChildItem -LiteralPath $p -Filter *.json){
  try{$o=Get-Content -LiteralPath $f.FullName -Raw -Encoding UTF8|ConvertFrom-Json}catch{continue}
  $r=$o.record;if(-not $r){continue}
  $id=$r.identity;$rows=$r.rows
  $tc=$rows.timeContext.val;$sl=$rows.sessionListMetadata.val;$st=$rows.sessionStats.val
  $t=''
  if($rows.title.val){$t=[string]$rows.title.val}
  elseif($rows.turnOutline.val.turns){$t=[string]$rows.turnOutline.val.turns[0].prompt}
  $lm=0;if($tc){$lm=[long]$tc.lastMessageTime}
  $lp=0;if($sl){$lp=[long]$sl.lastPromptAt}
  $sid=[IO.Path]::GetFileNameWithoutExtension($f.Name)
  $lg=$logs[$sid];$logp='';$mt=0
  if($lg){$logp=[string]$lg[0];$mt=[long]$lg[1]}
  $start=[long]$id.createdAt
  $end=[math]::Max([math]::Max($start,$lm),$lp)
  $tr=0;if($st){$tr=[int]$st.turns}
  $cut=[Math]::Min(64,$t.Length)
  [void]$out.Add([ordered]@{id=$sid;cwd=[string]$id.cwd;start=$start;end=$end;turns=$tr;title=$t.Substring(0,$cut);log=$logp;mtime=$mt})
}
'@@JSON@@'+(ConvertTo-Json -InputObject $out -Compress -Depth 4)
""".replace("__PROJ__", _ps_quote(proj)).replace("__SESS__", _ps_quote(sess))


def _ps_quote(s):
    return "'" + str(s).replace("'", "''") + "'"


def _run_remote(cfg, script, timeout=120):
    """跑一段远程 PowerShell；返回 (ok, stdout)。sidecar 自己会删 job 文件。"""
    job = {"host": cfg["host"], "port": cfg["port"], "user": cfg["user"],
           "credentialTarget": cfg["credential"], "timeoutSec": timeout,
           "script": script}
    fd, path = tempfile.mkstemp(prefix="mbg-remote-", suffix=".json")
    try:
        with os.fdopen(fd, "w", encoding="utf-8") as fh:
            json.dump(job, fh, ensure_ascii=False)
        p = subprocess.run([cfg["python"], cfg["sidecar"], "exec", path],
                           capture_output=True, timeout=timeout + 30, **_no_window())
        raw = (p.stdout or b"").decode("utf-8", "replace").strip()
    except Exception as e:
        return False, str(e)
    payload = None
    for line in reversed(raw.splitlines()):
        line = line.strip()
        if line.startswith("{"):
            try:
                payload = json.loads(line)
                break
            except Exception:
                continue
    if not payload:
        return False, raw[-500:] or "远程无返回"
    if not payload.get("ok"):
        return False, (payload.get("error") or "远程调用失败")[:500]
    return True, payload.get("stdout") or ""


def _remote_take_json(text):
    """从远程 stdout 里取 @@JSON@@ 那一行之后的内容"""
    for line in text.splitlines():
        i = line.find("@@JSON@@")
        if i >= 0:
            raw = line[i + 8:].strip()
            try:
                return json.loads(raw)
            except Exception:
                return None
    return None


def _remote_ws_label(cwd):
    parts = [p for p in re.split(r"[\\/]+", cwd or "") if p]
    if not parts:
        return "服务器"
    tail = parts[-1]
    if tail.lower() in ("workspace", "agents", "state") and len(parts) >= 2:
        return parts[-2] + "/" + tail
    return tail


def _remote_entries(raw, now_ms):
    """把服务器索引转成跟本机会话同形状的条目（多一个 host/workspace）"""
    entries = []
    for r in raw or []:
        if not isinstance(r, dict):
            continue
        sid = str(r.get("id") or "").strip()
        if not sid:
            continue
        start = int(r.get("start") or 0)
        end = int(r.get("end") or 0) or start
        mtime = int(r.get("mtime") or 0)
        if not start:
            continue
        active = (now_ms - max(end, mtime)) < ACTIVE_MS and start <= now_ms
        entries.append({
            "id": sid,
            "title": (str(r.get("title") or "").strip() or "未命名会话")[:64],
            "start": start,
            "end": max(start, end),
            "mtime": mtime,
            "active": active,
            "turns": int(r.get("turns") or 0),
            "steps": 0,
            "log": bool(r.get("log")),
            "host": "server",
            "workspace": _remote_ws_label(r.get("cwd")),
            "cwd": str(r.get("cwd") or ""),
            "logPath": str(r.get("log") or ""),
        })
    return entries


def _remote_refresh():
    """拉一次服务器会话索引；失败保留旧数据只标 error"""
    cfg = _remote_config()
    if not cfg:
        return
    with _REMOTE_LOCK:
        if _REMOTE["busy"]:
            return
        _REMOTE["busy"] = True
    ok, text = (False, "")
    try:
        ok, text = _run_remote(cfg, _remote_index_script(cfg), timeout=120)
        now_ms = int(time.time() * 1000)
        raw = _remote_take_json(text) if ok else None
        if isinstance(raw, dict):
            raw = [raw]
        if ok and raw is not None:
            entries = _remote_entries(raw, now_ms)
            with _REMOTE_LOCK:
                _REMOTE["cfg"] = cfg
                _REMOTE["entries"] = entries
                _REMOTE["fetchedAt"] = now_ms
                _REMOTE["error"] = ""
            try:
                with open(_remote_cache_path(), "w", encoding="utf-8") as fh:
                    json.dump({"fetchedAt": now_ms, "host": cfg["host"],
                               "entries": entries, "error": ""}, fh, ensure_ascii=False)
            except Exception:
                pass
        else:
            with _REMOTE_LOCK:
                _REMOTE["error"] = (text or "远程索引解析失败")[:300]
    finally:
        with _REMOTE_LOCK:
            _REMOTE["busy"] = False


def _remote_sync_if_due():
    """打开时钟（开始变形）时主动同步一次；冷却窗口内重复请求直接吃缓存。
    返回 True = 这次真的去拉了。"""
    now = time.time()
    with _REMOTE_LOCK:
        if now - _REMOTE["askedAt"] < REMOTE_SYNC_COOLDOWN:
            return False
        _REMOTE["askedAt"] = now
    _remote_refresh()
    return True


def _remote_load_cache():
    try:
        with open(_remote_cache_path(), "r", encoding="utf-8") as fh:
            o = json.load(fh) or {}
        entries = [e for e in (o.get("entries") or []) if isinstance(e, dict) and e.get("id")]
        with _REMOTE_LOCK:
            _REMOTE["entries"] = entries
            _REMOTE["fetchedAt"] = int(o.get("fetchedAt") or 0)
    except Exception:
        pass


def _remote_loop():
    while True:
        try:
            _remote_refresh()
        except Exception:
            pass
        time.sleep(REMOTE_REFRESH_SEC)


def _remote_snapshot():
    with _REMOTE_LOCK:
        return {"entries": list(_REMOTE["entries"]), "fetchedAt": _REMOTE["fetchedAt"],
                "error": _REMOTE["error"]}


def _remote_entry(sid):
    for e in _remote_snapshot()["entries"]:
        if e.get("id") == sid:
            return e
    return None


def _remote_session_payload(sid, limit=160):
    """远程会话正文：服务器侧 node 解压，只回传最近若干条消息"""
    entry = _remote_entry(sid)
    out = {"ok": False, "id": sid, "meta": entry}
    if not entry:
        out["error"] = "服务器索引里没有这个会话"
        return out
    cfg = _remote_config()
    if not cfg:
        out["error"] = "远程会话源未配置"
        return out
    log_path = entry.get("logPath") or ""
    if not log_path:
        out["error"] = "服务器上找不到这个会话的日志文件"
        return out
    node = cfg.get("node") or ""
    helper = os.path.join(ROOT, "session_log.cjs")
    remote_helper = cfg["dsh_home"] + "\\plugins\\memory-brain-graph\\assets\\session_log.cjs"
    # 远程 limit 收在 40：单次回传上限约 400KB，多了一定被截断、JSON 就坏了
    n = max(10, min(40, int(limit or 40)))
    if not node:
        out["error"] = "没有配置服务器 node 路径"
        return out
    script = r"""
[Console]::OutputEncoding=[System.Text.UTF8Encoding]::new()
$o = & __NODE__ __CJS__ __LOG__ __N__ 2>$null
'@@JSON@@' + ($o -join '')
""".replace("__NODE__", _ps_quote(node)) \
   .replace("__CJS__", _ps_quote(remote_helper)) \
   .replace("__LOG__", _ps_quote(log_path)) \
   .replace("__N__", str(n))
    ok, text = _run_remote(cfg, script, timeout=120)
    if not ok:
        out["error"] = text or "远程读取失败"
        return out
    got = _remote_take_json(text)
    if not isinstance(got, dict):
        out["error"] = "远程日志解析失败"
        return out
    out.update(got)
    out["ok"] = bool(got.get("ok"))
    if got.get("ok"):
        out["host"] = "server"
        out["workspace"] = entry.get("workspace")
        out["title"] = entry.get("title")
        out["truncated"] = (got.get("count") or 0) > n
    else:
        out["error"] = got.get("error") or "远程日志读取失败"
    return out


def _rowval(rows, key):
    r = rows.get(key) or {}
    return r.get("val")


_SESS_CACHE = {"at": 0.0, "data": None}


def sessions_payload(force=False):
    """本工作区所有会话的时间段（给记忆时钟做区间匹配）。"""
    now = time.time()
    if not force and _SESS_CACHE["data"] is not None and now - _SESS_CACHE["at"] < 6:
        return _SESS_CACHE["data"]

    ws = _norm_path(WORKSPACE)
    out = []
    skipped = 0
    for f in glob.glob(os.path.join(PROJ_DIR, "*.json")):
        try:
            with open(f, "r", encoding="utf-8") as fh:
                o = json.load(fh)
        except Exception:
            skipped += 1
            continue
        rec = o.get("record") or {}
        ident = rec.get("identity") or {}
        rows = rec.get("rows") or {}
        cwd = ident.get("cwd") or _rowval(rows, "workingDirectory") or ""
        if not cwd or _norm_path(cwd) != ws:
            continue
        sid = os.path.splitext(os.path.basename(f))[0]
        start = int(ident.get("createdAt") or 0)
        tc = _rowval(rows, "timeContext") or {}
        sl = _rowval(rows, "sessionListMetadata") or {}
        last_msg = int((tc or {}).get("lastMessageTime") or 0)
        last_prompt = int((sl or {}).get("lastPromptAt") or 0)
        end = max(start, last_msg, last_prompt)
        if not start:
            try:
                start = int(os.path.getmtime(f) * 1000)
            except Exception:
                start = 0
        if not end:
            end = start
        title = (_rowval(rows, "title") or "").strip()
        stats = _rowval(rows, "sessionStats") or {}
        turns = int((stats or {}).get("turns") or 0)
        if not title:
            outline = _rowval(rows, "turnOutline") or {}
            tl = (outline or {}).get("turns") or []
            if tl:
                title = (tl[0].get("prompt") or "").strip()
            if not turns:
                turns = len(tl)
        if not title:
            title = "未命名会话"
        title = " ".join(title.split())[:64]
        if (sl or {}).get("blank") and not turns:
            continue
        now_ms = int(now * 1000)
        logp = _session_log_path(sid)
        mtime = 0
        if logp:
            try:
                mtime = int(os.path.getmtime(logp) * 1000)
            except Exception:
                mtime = 0
        active = bool(logp) and start <= now_ms and (now_ms - max(end, mtime)) < ACTIVE_MS
        out.append({
            "id": sid,
            "title": title,
            "start": start,
            "end": max(start, end),
            "mtime": mtime,
            "active": active,
            "turns": turns,
            "steps": int((stats or {}).get("steps") or 0),
            "log": bool(logp),
            "host": "local",
            "workspace": os.path.basename(WORKSPACE.rstrip("\\/")) or "本机",
            "cwd": cwd,
        })
    # 服务器上的会话：全量返回（约 40 KB）；只留近 14 天内有过动静的，
    # 活跃的不受时间限制 —— 否则几十个旧的 QQ agent 会话会把时钟的碎片池挤满
    remote = _remote_snapshot()
    now_ms = int(now * 1000)
    cutoff = now_ms - 14 * 24 * 3600 * 1000
    for e in remote["entries"]:
        if e.get("start", 0) >= cutoff or e.get("active"):
            out.append({k: e.get(k) for k in
                        ("id", "title", "start", "end", "mtime", "active", "turns",
                         "steps", "log", "host", "workspace", "cwd")})
    out.sort(key=lambda s: (s["start"], s["id"]))
    data = {"ok": True, "workspace": WORKSPACE, "count": len(out),
            "skipped": skipped, "sessions": out, "now": now_ms,
            "remote": {"enabled": bool(remote["entries"]) or bool(_remote_config()),
                       "count": len([s for s in out if s.get("host") == "server"]),
                       "fetchedAt": remote["fetchedAt"], "error": remote["error"]}}
    _SESS_CACHE["data"] = data
    _SESS_CACHE["at"] = now
    return data


def session_payload(sid, limit=160, host="local"):
    """单个会话的日志正文：交给 node 逐帧解压（python 标准库没有 zstd）。"""
    if host == "server":
        return _remote_session_payload(sid, limit)
    data = sessions_payload()
    meta = next((s for s in data["sessions"] if s["id"] == sid), None)
    out = {"ok": False, "id": sid, "meta": meta}
    if not meta:
        out["error"] = "这个工作区里没有这个会话"
        return out
    log = _session_log_path(sid)
    if not log:
        out["error"] = "找不到会话日志文件"
        return out
    node = _find_node()
    helper = os.path.join(ROOT, "session_log.cjs")
    if not node or not os.path.exists(helper):
        out["error"] = "找不到 node 或 session_log.cjs"
        return out
    try:
        p = subprocess.run([node, helper, log, str(max(1, min(400, int(limit))))],
                           capture_output=True, timeout=20, **_no_window())
        raw = (p.stdout or b"").decode("utf-8", "replace").strip()
        got = json.loads(raw) if raw else {}
        if got.get("ok"):
            out.update(got)
            out["ok"] = True
        else:
            out["error"] = got.get("error") or "读取失败"
    except Exception as e:
        out["error"] = str(e)
    return out


# ---------------------------------------------------------------------------
# 已装插件清单：记忆时钟继续外扩后，飞进来的残片里放的是「当前 profile 已装插件」
# 数据源 = profile/package.json 的 dependencies + node_modules/<包>/package.json
# 简介 = package.json description + README 首段（去掉 markdown 标记）
# 只读本地文件，不联网、不写盘；60 秒缓存，?refresh 强制重扫。
# ---------------------------------------------------------------------------
_PLUGIN_CACHE = {"at": 0.0, "data": None}


def _profile_dir():
    """当前插件的 profile 目录：环境变量 → desktop → 第一个有 package.json 的。"""
    env = os.environ.get("MEMORY_BRAIN_PROFILE")
    home = _dsh_home()
    cands = []
    if env:
        cands.append(env)
    cands.append(os.path.join(home, "profiles", "desktop"))
    try:
        for d in sorted(os.listdir(os.path.join(home, "profiles"))):
            cands.append(os.path.join(home, "profiles", d))
    except Exception:
        pass
    for c in cands:
        if c and os.path.isfile(os.path.join(c, "package.json")):
            return c
    return None


def _md_plain(s, n=1400):
    """README 去掉标题井号/列表符/链接图片/HTML 之后压成一段纯文本。"""
    s = re.sub(r"```[\s\S]*?```", " ", s)
    s = re.sub(r"`([^`]*)`", r"\1", s)
    s = re.sub(r"!\[[^\]]*\]\([^)]*\)", " ", s)
    s = re.sub(r"\[([^\]]*)\]\([^)]*\)", r"\1", s)
    s = re.sub(r"<[^>]+>", " ", s)
    s = re.sub(r"(?m)^\s{0,3}#{1,6}\s*", "", s)
    s = re.sub(r"(?m)^\s*[-*+]\s+", "· ", s)
    s = re.sub(r"[*_>|]", "", s)
    s = re.sub(r"\s+", " ", s).strip()
    return s[:n]


def _plugin_list():
    prof = _profile_dir()
    out = {"ok": True, "profile": prof or "", "plugins": []}
    if not prof:
        out["ok"] = False
        out["error"] = "没找到 profile 目录（里面有 package.json 的那层）"
        return out
    try:
        with open(os.path.join(prof, "package.json"), "r", encoding="utf-8") as fh:
            pj = json.load(fh)
    except Exception as e:
        out["ok"] = False
        out["error"] = "读 profile/package.json 失败：%s" % e
        return out
    deps = pj.get("dependencies") or {}
    nm = os.path.join(prof, "node_modules")
    rows = []
    for name in deps.keys():
        spec = str(deps.get(name) or "")
        pkg_dir = os.path.join(nm, name.replace("/", os.sep))
        pkg = {}
        try:
            with open(os.path.join(pkg_dir, "package.json"), "r", encoding="utf-8") as fh:
                pkg = json.load(fh)
        except Exception:
            pass
        if spec.startswith("link:"):
            form = "本地链接"
        elif spec.startswith("file:"):
            form = "本地包"
        elif spec.startswith("http") or spec.startswith("git"):
            form = "GitHub"
        else:
            form = "npm"
        dsh = pkg.get("dsh") or {}
        kinds = []
        if dsh.get("bundle"):
            kinds.append("bundle")
        if dsh.get("client"):
            kinds.append("客户端")
        if dsh.get("server") or dsh.get("host"):
            kinds.append("服务端")
        icon = ""
        for cand in ("icon.svg", "icon.png", "icon.webp", "icon.ico"):
            if os.path.isfile(os.path.join(pkg_dir, cand)):
                icon = cand
                break
        readme = ""
        for cand in ("README.zh.md", "README.md", "readme.md"):
            p = os.path.join(pkg_dir, cand)
            if os.path.isfile(p):
                try:
                    with open(p, "r", encoding="utf-8", errors="replace") as fh:
                        readme = _md_plain(fh.read(), 1400)
                except Exception:
                    readme = ""
                if readme:
                    break
        rows.append({
            "id": name,
            "short": name.split("/")[-1],
            "version": str(pkg.get("version") or ""),
            "desc": re.sub(r"\s+", " ", str(pkg.get("description") or "")).strip(),
            "readme": readme,
            "form": form,
            "spec": spec,
            "kind": " / ".join(kinds) or "插件",
            "icon": ("/api/plugin-icon?name=" + urllib.parse.quote(name)) if icon else "",
        })
    out["plugins"] = rows
    return out


def plugins_payload(refresh=False):
    now = time.time()
    if refresh or not _PLUGIN_CACHE["data"] or now - _PLUGIN_CACHE["at"] > 60:
        try:
            _PLUGIN_CACHE["data"] = _plugin_list()
        except Exception as e:
            _PLUGIN_CACHE["data"] = {"ok": False, "error": str(e), "plugins": []}
        _PLUGIN_CACHE["at"] = now
    return _PLUGIN_CACHE["data"]


# 技能清单：记忆时钟的「技能翅膀」里显示当前装了哪些 skill
# 只扫 <DSH_HOME>/skills/<name>/SKILL.md，取 frontmatter 的 name/description
_SKILL_CACHE = {"at": 0.0, "data": None}


def _skill_list():
    root = os.path.join(_dsh_home(), "skills")
    rows = []
    if not os.path.isdir(root):
        return rows
    for name in sorted(os.listdir(root)):
        p = os.path.join(root, name, "SKILL.md")
        if not os.path.isfile(p):
            continue
        text = ""
        try:
            with open(p, "r", encoding="utf-8", errors="replace") as fh:
                text = fh.read()
        except Exception:
            continue
        title, desc = name, ""
        m = re.search(r"^---\s*$([\s\S]*?)^---\s*$", text, re.MULTILINE)
        fm = m.group(1) if m else text[:1200]
        mm = re.search(r"^name:\s*(.+)$", fm, re.MULTILINE)
        if mm:
            title = mm.group(1).strip().strip("\"'")
        md = re.search(r"^description:\s*(.+)$", fm, re.MULTILINE)
        if md:
            desc = md.group(1).strip().strip("\"'")
        else:
            for line in text.splitlines():
                s = line.strip()
                if not s or s.startswith("#") or s.startswith("---") or ":" in s[:24]:
                    continue
                desc = s
                break
        rows.append({"id": name, "name": title, "desc": re.sub(r"\s+", " ", desc)[:160]})
    return rows


def skills_payload(refresh=False):
    now = time.time()
    if refresh or not _SKILL_CACHE["data"] or now - _SKILL_CACHE["at"] > 120:
        try:
            _SKILL_CACHE["data"] = {"ok": True, "skills": _skill_list()}
        except Exception as e:
            _SKILL_CACHE["data"] = {"ok": False, "error": str(e), "skills": []}
        _SKILL_CACHE["at"] = now
    return _SKILL_CACHE["data"]


_SKILL_USE_CACHE = {"data": None, "at": 0}


def _skill_usage():
    """每个技能在记忆库里被提到多少次 —— 这就是"我是真的会它"的证据。"""
    import time as _t
    now = _t.time()
    if _SKILL_USE_CACHE["data"] is not None and now - _SKILL_USE_CACHE["at"] < 120:
        return _SKILL_USE_CACHE["data"]
    try:
        skills = _skill_list()
    except Exception as e:
        return {"ok": False, "error": str(e), "usage": {}}
    out = {}
    try:
        con = sqlite3.connect(DB)
        tables = [r[0] for r in con.execute("select name from sqlite_master where type='table'")]
        for sk in skills:
            sid = str(sk.get("id") or sk.get("name") or "")
            if not sid:
                continue
            n = 0
            for t in tables:
                try:
                    cols = [c[1] for c in con.execute("pragma table_info(%s)" % t)]
                except Exception:
                    continue
                w = []
                for c in ("content", "keywords", "title"):
                    if c in cols:
                        w.append("coalesce(%s,'') like ?" % c)
                if not w:
                    continue
                try:
                    n += con.execute("select count(*) from %s where %s" % (t, " or ".join(w)),
                                     ["%" + sid + "%"] * len(w)).fetchone()[0]
                except Exception:
                    pass
            out[sid] = n
        con.close()
    except Exception as e:
        return {"ok": False, "error": str(e), "usage": {}}
    data = {"ok": True, "usage": out}
    _SKILL_USE_CACHE["data"] = data
    _SKILL_USE_CACHE["at"] = now
    return data


def plugin_icon_bytes(name):
    """按包名读它根目录的 icon.*；路径必须落在 profile/node_modules 里。
    注意不能用 realpath：插件常用 junction/link 装到别处，一解析就跑到 node_modules 外了。"""
    prof = _profile_dir()
    if not prof or not name:
        return None, None
    base = os.path.abspath(os.path.join(prof, "node_modules"))
    d = os.path.abspath(os.path.join(base, name.replace("/", os.sep)))
    if not (d == base or d.startswith(base + os.sep)):
        return None, None
    for cand in ("icon.svg", "icon.png", "icon.webp", "icon.ico"):
        p = os.path.join(d, cand)
        if os.path.isfile(p):
            ext = os.path.splitext(p)[1].lower()
            ctype = {".svg": "image/svg+xml", ".png": "image/png",
                     ".webp": "image/webp", ".ico": "image/x-icon"}.get(
                ext, "application/octet-stream")
            try:
                with open(p, "rb") as fh:
                    return fh.read(), ctype
            except Exception:
                return None, None
    return None, None


# ---------------- 反思开关 / 主动反思 / 已反思秒数（实验性功能） ----------------
# 设计口径（2026-11-01 用户要求）：
#   · 自动反思默认关闭：本机没有部署反思计划任务时，初始化一定写 auto=false；
#     只有已经存在并启用的反思任务（老用户自己部署过）才沿用真实状态，避免界面说谎。
#   · 主动反思：点一次只跑一次，跑的时候页面显示"已反思 N 秒"。
#   · 这是实验性功能：开启会调用本地脚本（语义反思还会调模型），有风险，默认关。
REFLECT_DIR = os.path.join(WORKSPACE, "learn", "reflection")
REFLECT_SETTINGS = os.path.join(WORKSPACE, ".dsh-meow", "reflect-settings.json")
REFLECT_SCRIPTS = {
    "semantic": os.path.join(REFLECT_DIR, "semantic_reflect.py"),
    "rules": os.path.join(REFLECT_DIR, "auto_reflect.py"),
    "audit": os.path.join(REFLECT_DIR, "full_audit.py"),
}
# 自动反思 = 这一组计划任务在系统里按时跑（换台机器没有它们，自然就是"未部署/关闭"）
REFLECT_TASKS = {
    "rules": "MeowMemoryAutoReflect",
    "audit": "MeowMemoryFullAudit",
    "semantic": "MeowMemorySemanticReflect",
    "boot": "MeowMemoryAutoReflectBoot",
}
_REFLECT_LOCK = threading.Lock()
_REFLECT_RUN = {"proc": None, "kind": "", "started": 0.0, "finished": 0.0, "code": None}
_TASK_CACHE = {"at": 0.0, "data": {}}


def _reflect_python():
    """子进程用 pythonw（无黑框）；拿不到就退回当前解释器。"""
    exe = sys.executable or ""
    if os.name == "nt" and exe:
        cand = os.path.join(os.path.dirname(exe), "pythonw.exe")
        if os.path.isfile(cand):
            return cand
    return exe or "python"


def _load_reflect_settings():
    try:
        with open(REFLECT_SETTINGS, "r", encoding="utf-8") as fh:
            d = json.load(fh)
        if isinstance(d, dict):
            return d
    except Exception:
        pass
    return {}


def _task_state(name):
    """查一个计划任务：存在？启用？结果缓存 5 秒，别让 1 秒一次的轮询把 schtasks 打爆。

    坑（2026-11-01 实测）：`schtasks /Query /FO LIST` 的文本是**跟着系统语言/编码走**的——
    在服务进程里拿回来是 GBK 中文，按 UTF-8 解就是乱码，"disabled/禁用"一个都匹配不上，
    于是被兜底判成"启用"，开关的关闭动作看起来成功、实际状态却读错。
    所以状态一律读 **任务 XML**：里面 `<Enabled>false</Enabled>` 是固定英文标签，
    且"没有这个元素 = 默认启用"，不受语言影响；存在性看返回码。"""
    now = time.time()
    if now - _TASK_CACHE["at"] < 5 and name in _TASK_CACHE["data"]:
        return _TASK_CACHE["data"][name]
    st = {"exists": False, "enabled": False}
    try:
        p = subprocess.run(["schtasks", "/Query", "/TN", name, "/XML"],
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=8, **_no_window())
        raw = p.stdout or b""
        if p.returncode == 0:
            st["exists"] = True
            if raw[:2] in (b"\xff\xfe", b"\xfe\xff"):
                text = raw.decode("utf-16", "replace")
            else:
                try:
                    text = raw.decode("utf-8")
                except Exception:
                    text = raw.decode("mbcs", "replace")
            mo = re.search(r"<Enabled>\s*(true|false)\s*</Enabled>", text, re.I)
            st["enabled"] = not (mo and mo.group(1).lower() == "false")
    except Exception:
        pass
    if now - _TASK_CACHE["at"] >= 5:
        _TASK_CACHE["data"] = {}
        _TASK_CACHE["at"] = now
    _TASK_CACHE["data"][name] = st
    return st


def _set_tasks(enabled):
    """把自动反思那一组任务打开/关掉；返回实际动到的任务。注意：这是系统级操作。
    /Change 本身是幂等的，所以这里**不靠缓存判断当前状态**直接下发——
    踩过的坑：刚 /DISABLE 完立刻再查，系统可能还报 Ready，缓存 5 秒就会让下一次切换被误判成"不用改"。"""
    touched = []
    for key, name in REFLECT_TASKS.items():
        st = _task_state(name)
        if not st["exists"]:
            continue
        try:
            p = subprocess.run(["schtasks", "/Change", "/TN", name,
                                "/ENABLE" if enabled else "/DISABLE"],
                               stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                               timeout=10, **_no_window())
            touched.append((key, "ok" if p.returncode == 0 else "failed"))
        except Exception:
            touched.append((key, "failed"))
    time.sleep(0.6)                    # 等系统把状态落定，再让下一次查询读到真值
    _TASK_CACHE["at"] = 0
    _TASK_CACHE["data"] = {}
    return touched


def _save_reflect_settings(d):
    try:
        os.makedirs(os.path.dirname(REFLECT_SETTINGS), exist_ok=True)
        tmp = REFLECT_SETTINGS + ".tmp"
        with open(tmp, "w", encoding="utf-8") as fh:
            json.dump(d, fh, ensure_ascii=False, indent=2)
        os.replace(tmp, REFLECT_SETTINGS)
        return True
    except Exception:
        return False


def _reflect_init():
    """首次初始化：没有设置文件就写一份。
    本机没有反思任务 → auto=false（新部署默认关闭自动反思）；
    已经有任务且启用（老用户自己配过）→ 沿用真实状态，界面不说谎。"""
    s = _load_reflect_settings()
    if s:
        return s
    any_task = any(_task_state(n)["exists"] and _task_state(n)["enabled"]
                   for n in REFLECT_TASKS.values())
    s = {"auto": bool(any_task), "assemble": bool(any_task), "lastRun": None,
         "initializedAt": datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S")}
    _save_reflect_settings(s)
    return s


def _reflect_day_start_ms():
    """「今日」从 05:00 起算（与页面/反思脚本同一口径）。"""
    now = datetime.datetime.now()
    d0 = now.replace(hour=5, minute=0, second=0, microsecond=0)
    if now < d0:
        d0 -= datetime.timedelta(days=1)
    return int(d0.timestamp() * 1000)


def _reflect_tokens():
    """今日/累计的反思 token 消耗（读 learn/reflection/history.jsonl）。"""
    entries = []
    try:
        with open(os.path.join(REFLECT_DIR, "history.jsonl"), "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                except Exception:
                    continue
                if isinstance(e, dict):
                    entries.append(e)
    except Exception:
        pass
    start = _reflect_day_start_ms()
    today_tok = today_runs = total_tok = total_runs = 0
    for e in entries:
        tok = int(e.get("tokens") or 0)
        total_tok += tok
        if e.get("kind") == "semantic":
            total_runs += 1
        try:
            at = int(e.get("atMs") or 0)
        except Exception:
            at = 0
        if at >= start:
            today_tok += tok
            if e.get("kind") == "semantic":
                today_runs += 1
    return {
        "todayTokens": today_tok,
        "todayRuns": today_runs,
        "totalTokens": total_tok,
        "totalRuns": total_runs,
        "dayStartMs": start,
    }


def _reflect_status():
    s = _reflect_init()
    tasks = {}
    for key, name in REFLECT_TASKS.items():
        st = _task_state(name)
        tasks[key] = {"name": name, "exists": st["exists"], "enabled": st["enabled"]}
    scripts = {k: os.path.isfile(p) for k, p in REFLECT_SCRIPTS.items()}
    running = False
    elapsed = 0.0
    kind = ""
    with _REFLECT_LOCK:
        proc = _REFLECT_RUN["proc"]
        if proc is not None:
            code = proc.poll()
            if code is None:
                running = True
                kind = _REFLECT_RUN["kind"]
                elapsed = round(time.time() - _REFLECT_RUN["started"], 1)
            else:
                # 跑完了：落一次结果
                dur = round((_REFLECT_RUN["finished"] or time.time()) - _REFLECT_RUN["started"], 1)
                s["lastRun"] = {
                    "kind": _REFLECT_RUN["kind"],
                    "ok": code == 0,
                    "code": code,
                    "durationSec": dur,
                    "at": datetime.datetime.now().strftime("%m-%d %H:%M"),
                }
                _save_reflect_settings(s)
                _REFLECT_RUN.update({"proc": None, "kind": "", "started": 0.0,
                                     "finished": 0.0, "code": code})
    return {
        "auto": bool(s.get("auto")),
        # 老设置文件里没有 assemble 字段时，跟随 auto（一个总开关）
        "assemble": bool(s.get("assemble", s.get("auto"))),
        "supported": any(scripts.values()),
        "scripts": scripts,
        "tasks": tasks,
        "deployed": any(t["exists"] for t in tasks.values()),
        "running": running,
        "kind": kind,
        "elapsedSec": elapsed,
        "lastRun": s.get("lastRun"),
        "experimental": True,
        "warning": "实验性功能：自动反思会按期调用本地脚本（语义反思还会调模型），开启有风险，默认关闭。",
    }


def _reflect_set_auto(on, assemble=None):
    s = _reflect_init()
    s["auto"] = bool(on)
    # 一个总开关：开自动反思 = 同时开自动拼装（用户 2026-11-02 口径）
    s["assemble"] = (bool(on) if assemble is None else bool(assemble))
    _save_reflect_settings(s)
    touched = _set_tasks(bool(on)) if os.name == "nt" else []
    st = _reflect_status()
    st["touched"] = touched
    return st


def _assemble_once():
    """立即拼装：跑一次 parts.py（把每个 SKILL.md 的 ## 章节拆成零件，刷新 parts.json）。"""
    script = os.path.join(REFLECT_DIR, "parts.py")
    if not os.path.isfile(script):
        return {"ok": False, "needScript": True,
                "error": "这台机器上没有零件拆解脚本（learn/reflection/parts.py），拼装只在本机可用。"
                         "把 parts.py 放到 " + REFLECT_DIR + " 再试。"}
    py = _reflect_python()
    if os.name == "nt" and py.lower().endswith("pythonw.exe"):
        cand = py[:-len("pythonw.exe")] + "python.exe"
        if os.path.isfile(cand):
            py = cand
    t0 = time.time()
    try:
        p = subprocess.run([py, script], cwd=WORKSPACE,
                           stdout=subprocess.PIPE, stderr=subprocess.PIPE,
                           timeout=180, **_no_window())
    except Exception as e:
        return {"ok": False, "error": str(e)}
    out = (p.stdout or b"").decode("utf-8", "replace")[-1200:]
    err = (p.stderr or b"").decode("utf-8", "replace")[-600:]
    counts = None
    try:
        with open(os.path.join(WORKSPACE, "plugins", "memory-brain-graph",
                               "assets", "organs", "parts.json"), "r", encoding="utf-8") as fh:
            counts = json.load(fh).get("counts")
    except Exception:
        pass
    return {"ok": p.returncode == 0, "code": p.returncode,
            "sec": round(time.time() - t0, 1), "out": out, "err": err, "counts": counts}


def _reflect_start(kind):
    kind = kind if kind in REFLECT_SCRIPTS else "rules"
    script = REFLECT_SCRIPTS[kind]
    if not os.path.isfile(script):
        return {"ok": False, "error": "没有这个反思脚本: " + script}
    with _REFLECT_LOCK:
        proc = _REFLECT_RUN["proc"]
        if proc is not None and proc.poll() is None:
            return {"ok": False, "error": "already running", "kind": _REFLECT_RUN["kind"]}
        py = _reflect_python()
        try:
            p = subprocess.Popen([py, script], cwd=WORKSPACE,
                                 stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL,
                                 env=dict(os.environ, PYTHONIOENCODING="utf-8"),
                                 **_no_window())
        except Exception as e:
            return {"ok": False, "error": str(e)}
        _REFLECT_RUN.update({"proc": p, "kind": kind, "started": time.time(),
                             "finished": 0.0, "code": None})
    return {"ok": True, "kind": kind, "startedAt": time.time()}


class Handler(BaseHTTPRequestHandler):
    def log_message(self, *a):
        pass

    def _send(self, code, body, ctype):
        if isinstance(body, str):
            body = body.encode("utf-8")
        self.send_response(code)
        self.send_header("Content-Type", ctype)
        self.send_header("Content-Length", str(len(body)))
        self.send_header("Cache-Control", "no-store")
        self.end_headers()
        self.wfile.write(body)

    def do_GET(self):
        path = self.path.split("?")[0]
        if path == "/api/reflect/tokens":
            try:
                return self._send(200, json.dumps(_reflect_tokens(), ensure_ascii=False),
                                  "application/json; charset=utf-8")
            except Exception as e:
                return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False),
                                  "application/json; charset=utf-8")
        if path == "/api/skill-usage":
            try:
                return self._send(200, json.dumps(_skill_usage(), ensure_ascii=False),
                                  "application/json; charset=utf-8")
            except Exception as e:
                return self._send(500, json.dumps({"ok": False, "error": str(e)}, ensure_ascii=False),
                                  "application/json; charset=utf-8")
        if path == "/api/reflect/status":
            try:
                return self._send(200, json.dumps(_reflect_status(), ensure_ascii=False),
                                  "application/json; charset=utf-8")
            except Exception as e:
                return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False),
                                  "application/json; charset=utf-8")
        if path in ("/", "/index.html"):
            f = os.path.join(ROOT, "index.html")
            if not os.path.exists(f):
                return self._send(500, "index.html 不在同目录", "text/plain; charset=utf-8")
            with open(f, "r", encoding="utf-8") as fh:
                return self._send(200, fh.read(), "text/html; charset=utf-8")
        # 静态图片/数据资源（人物贴图、法阵图、反思数据等）
        if path.lower().endswith((".png", ".jpg", ".jpeg", ".webp", ".svg", ".ico", ".mp4", ".json", ".js", ".css")):
            name = path.lstrip("/").replace("/", os.sep)
            f = os.path.join(ROOT, name)
            if os.path.exists(f) and os.path.isfile(f):
                ext = os.path.splitext(f)[1].lower()
                ctype = {
                    ".png": "image/png", ".jpg": "image/jpeg", ".jpeg": "image/jpeg",
                    ".webp": "image/webp", ".svg": "image/svg+xml", ".ico": "image/x-icon",
                    ".mp4": "video/mp4", ".json": "application/json; charset=utf-8",
                    ".js": "text/javascript; charset=utf-8",
                    ".css": "text/css; charset=utf-8",
                }.get(ext, "application/octet-stream")
                with open(f, "rb") as fh:
                    return self._send(200, fh.read(), ctype)
            return self._send(404, "not found", "text/plain; charset=utf-8")
        if path == "/api/pulse":
            try:
                since = 0
                if "?" in self.path:
                    for kv in self.path.split("?", 1)[1].split("&"):
                        if kv.startswith("since="):
                            since = int(kv.split("=", 1)[1] or 0)
                return self._send(200, json.dumps(pulse(since), ensure_ascii=False),
                                  "application/json; charset=utf-8")
            except Exception as e:
                return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False),
                                  "application/json; charset=utf-8")
        if path == "/api/graph":
            try:
                if self.path.endswith("?refresh"):
                    CACHE["data"] = None
                data = payload()
                return self._send(200, json.dumps(data, ensure_ascii=False),
                                  "application/json; charset=utf-8")
            except DbMissing:
                return self._send(200, json.dumps(empty_payload(), ensure_ascii=False),
                                  "application/json; charset=utf-8")
            except Exception as e:
                return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False),
                                  "application/json; charset=utf-8")
        if path == "/api/mood":
            try:
                return self._send(200, json.dumps(mood_payload(), ensure_ascii=False),
                                  "application/json; charset=utf-8")
            except Exception as e:
                return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False),
                                  "application/json; charset=utf-8")
        if path == "/api/sync":
            try:
                return self._send(200, json.dumps(sync_payload(), ensure_ascii=False),
                                  "application/json; charset=utf-8")
            except Exception as e:
                return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False),
                                  "application/json; charset=utf-8")
        if path == "/api/sessions":
            try:
                # 打开时钟时前端带 sync=1 来：主动同步一次（10 秒冷却，见 _remote_sync_if_due）
                if "sync=1" in self.path or "remoterefresh" in self.path:
                    _remote_sync_if_due()
                data = sessions_payload("refresh" in self.path)
                return self._send(200, json.dumps(data, ensure_ascii=False),
                                  "application/json; charset=utf-8")
            except Exception as e:
                return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False),
                                  "application/json; charset=utf-8")
        if path == "/api/session":
            try:
                q = {}
                if "?" in self.path:
                    for kv in self.path.split("?", 1)[1].split("&"):
                        if "=" in kv:
                            k, v = kv.split("=", 1)
                            q[urllib.parse.unquote(k)] = urllib.parse.unquote(v)
                sid = (q.get("id") or "").strip()
                if not sid:
                    return self._send(400, json.dumps({"error": "缺少 id"}, ensure_ascii=False),
                                      "application/json; charset=utf-8")
                data = session_payload(sid, int(q.get("limit") or 160),
                                       (q.get("host") or "local").strip())
                return self._send(200, json.dumps(data, ensure_ascii=False),
                                  "application/json; charset=utf-8")
            except Exception as e:
                return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False),
                                  "application/json; charset=utf-8")
        if path == "/api/plugins":
            try:
                return self._send(200, json.dumps(plugins_payload("refresh" in self.path),
                                                  ensure_ascii=False),
                                  "application/json; charset=utf-8")
            except Exception as e:
                return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False),
                                  "application/json; charset=utf-8")
        if path == "/api/plugin-icon":
            try:
                q = {}
                if "?" in self.path:
                    for kv in self.path.split("?", 1)[1].split("&"):
                        if "=" in kv:
                            k, v = kv.split("=", 1)
                            q[k] = urllib.parse.unquote(v)
                body, ctype = plugin_icon_bytes(q.get("name") or "")
                if body is None:
                    return self._send(404, "not found", "text/plain; charset=utf-8")
                return self._send(200, body, ctype)
            except Exception as e:
                return self._send(500, str(e), "text/plain; charset=utf-8")
        if path == "/api/skill":
            try:
                q = {}
                if "?" in self.path:
                    for kv in self.path.split("?", 1)[1].split("&"):
                        if "=" in kv:
                            k, v = kv.split("=", 1)
                            q[urllib.parse.unquote(k)] = urllib.parse.unquote(v)
                sid = (q.get("id") or "").strip()
                root = os.path.join(_dsh_home(), "skills")
                f2 = os.path.join(root, sid, "SKILL.md")
                if not sid or not os.path.isfile(f2):
                    return self._send(404, json.dumps({"error": "没有这个技能"}, ensure_ascii=False),
                                      "application/json; charset=utf-8")
                with open(f2, "r", encoding="utf-8", errors="replace") as fh:
                    txt = fh.read()
                return self._send(200, json.dumps({"ok": True, "id": sid, "text": txt[:12000]},
                                                  ensure_ascii=False),
                                  "application/json; charset=utf-8")
            except Exception as e:
                return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False),
                                  "application/json; charset=utf-8")
        if path == "/api/skills":
            try:
                return self._send(200, json.dumps(skills_payload("refresh" in self.path),
                                                  ensure_ascii=False),
                                  "application/json; charset=utf-8")
            except Exception as e:
                return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False),
                                  "application/json; charset=utf-8")
        return self._send(404, "not found", "text/plain; charset=utf-8")


    def _body_json(self):
        try:
            n = int(self.headers.get("Content-Length") or 0)
            raw = self.rfile.read(n) if n else b"{}"
            return json.loads((raw or b"{}").decode("utf-8"))
        except Exception:
            return {}

    def do_POST(self):
        path = self.path.split("?")[0]
        try:
            if path == "/api/reflect/auto":
                body = self._body_json()
                st = _reflect_set_auto(bool(body.get("on")), body.get("assemble"))
                return self._send(200, json.dumps(st, ensure_ascii=False),
                                  "application/json; charset=utf-8")
            if path == "/api/reflect/assemble":
                r = _assemble_once()
                # 缺脚本不是"请求错"，回 200 + ok=false，页面才能把原因讲清楚
                return self._send(200, json.dumps(r, ensure_ascii=False),
                                  "application/json; charset=utf-8")
            if path == "/api/reflect/run":
                body = self._body_json()
                r = _reflect_start(str(body.get("kind") or "semantic"))
                code = 200 if r.get("ok") else 409
                return self._send(code, json.dumps(r, ensure_ascii=False),
                                  "application/json; charset=utf-8")
            return self._send(404, json.dumps({"error": "not found"}, ensure_ascii=False),
                              "application/json; charset=utf-8")
        except Exception as e:
            return self._send(500, json.dumps({"error": str(e)}, ensure_ascii=False),
                              "application/json; charset=utf-8")


def main():
    srv = ThreadingHTTPServer(("127.0.0.1", PORT), Handler)
    url = "http://127.0.0.1:%d/" % PORT
    print("记忆脑图已启动: " + url)
    print("库: " + DB)
    print("（自动跟随最近活跃的工作区；换工作区重启一次即可）")
    # 远程会话源：先把上次缓存挂上（秒开），再起后台线程拉新的
    _remote_load_cache()
    if _remote_config():
        print("远程会话源: " + str(_remote_config()["host"])
              + "  (" + str(_remote_config()["dsh_home"]) + ")")
        threading.Thread(target=_remote_loop, daemon=True).start()
    else:
        print("远程会话源: 未启用（没找到 sync.config.json / python\\sidecar.py）")
    try:
        s = payload()["stats"]
        print("节点 %d / 连线 %d / 活跃 %d 归档 %d" % (s["nodes"], s["edges"], s["active"], s["archived"]))
    except DbMissing as e:
        # 关键：不退出。没有库也要把页面开出来，让页面自己讲清「缺什么、去哪装」。
        print("没有记忆库: " + e.path)
        print("服务照常运行；页面会显示安装提示（装 meow-memory，或把配置里的 db 指到现成的库）")
    except Exception as e:
        print("预计算失败: %s" % e)
    # 插件场景不要弹浏览器；想弹就设 MEMORY_BRAIN_OPEN_BROWSER=1
    if os.environ.get("MEMORY_BRAIN_OPEN_BROWSER") == "1":
        threading.Timer(0.6, lambda: webbrowser.open(url)).start()
    srv.serve_forever()


if __name__ == "__main__":
    main()
