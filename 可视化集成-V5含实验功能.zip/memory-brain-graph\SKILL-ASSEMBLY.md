# 技能自动组装 · 脚本施工图（给别的肥鱼）

> 这份是**写脚本**用的施工图：你要做出「自动把 skill 拆成零件 → 自动找出共享执行体并拼成组件 →
> 按一句需求自动生成装配单」这条流水线。读者是 AI，不是人。代码都是可抄的最小实现。
> 本包参考实现在 `learn/reflection/`：`parts.py` / `assemblies.py` / `compose.py`。

---

## 1. 自动组装长什么样

```
~/.dsh/skills/*/SKILL.md
        │  ① parts.py      拆章节、判层、抓依赖、标 local
        ▼
assets/organs/parts.json          （零件库：45 技能 / 264 零件）
        │  ② assemblies.py  统计共享执行体 → 聚类成组件
        ▼
assets/organs/assemblies.json     （组件库：可复用半成品）
        │  ③ compose.py --need "..."  分词→三层检索→打分→缺层判定
        ▼
learn/reflection/out/装配单.md     （给人/AI 审的装配方案，不自动发布）
```

**三个触发点**（缺一个就不算「自动」）：

1. **定期**：反思跑完顺手跑 ①（本包挂在反思开关上，见第 6 节）；
2. **按需**：一句需求 → ③ 出装配单；
3. **体检**：审视时跑 ③ 的 `--review`，把重复/偏科/孤岛变成动作清单。

三步都必须是**幂等**的：跑一百次结果一样，中途失败不留半份文件（写临时文件再 `os.replace`）。

---

## 2. 数据契约（照抄，字段别改名）

`parts.json`：

```json
{ "generatedAt": "...", "counts": {"skills":45,"parts":264,"layers":{"sense":50,"think":117,"act":72,"unknown":25}},
  "skills": [{"name":"code-review","parts":8,"dist":{"sense":2,"think":4,"act":1,"unknown":1},"chars":12580}],
  "parts":  [{"id":"code-review/03","skill":"code-review","title":"流程","layer":"act",
              "mix":{"sense":0,"think":0.2,"act":0.8},"chars":812,"hash":"...","deps":["x.ps1"],
              "local":false,"text":"## 流程\n..."}],
  "gaps": ["缺层的技能名"], "clusters": [["相似零件 id"]] }
```

`assemblies.json`（组件）：

```json
{ "generatedAt":"...", "assemblies":[
   {"name":"dst-mods", "deps":["mods.ps1"], "parts":[...], "skills":["dst-mod-quick","dst-mod-daily"],
    "reuse":2, "complete":true, "usage":"...", "acceptance":"..."}],
  "stats": {"assemblies":12,"complete":9,"reusedBy3plus":2} }
```

规则：`layer ∈ {sense,think,act,unknown}`；`local=true` 表示绑死本机不能搬；
`deps` 是引用到的命令/脚本/文件（判共享执行体**只**靠它）；`text` 必须留原文。

---

## 3. ① parts.py：怎么拆、怎么判层（可抄）

```python
def split_parts(text):
    """第一个 ## 之前 = intro；之后每个 ## 到下一个 ## = 一个零件。"""
    lines = text.splitlines()
    idx = [i for i, l in enumerate(lines) if re.match(r"^##\s+\S", l)]
    out = []
    head = "\n".join(lines[:idx[0]] if idx else lines).strip()
    if head: out.append(("(intro)", head))
    for n, i in enumerate(idx):
        j = idx[n+1] if n+1 < len(idx) else len(lines)
        out.append((re.sub(r"^##\s+", "", lines[i]).strip(), "\n".join(lines[i:j]).strip()))
    return out
```

判层：**标题强判据 → 正文弱判据 → unknown**（不要硬塞；`unknown` 是「这章写得没结构」的信号）。
正则必须中英双语（英文 skill 占一半，只写中文会漏一半）：

```python
TITLE = {
 "sense": r"什么时候用|何时用|不适用|触发|前提|前置|依赖|安装|输入|边界|用在哪|when|precondition|require|setup|install|input|trigger|on-?ramp",
 "think": r"判断|判据|规则|约定|纪律|阈值|优先级|取舍|策略|原则|铁律|坑|陷阱|失败|分类|定义|反模式|为什么|glossary|principle|rule|criteria|anti-?pattern|pitfall|why|decision|tradeoff|contract",
 "act":   r"流程|用法|步骤|命令|脚本|执行|部署|写入|生成|渲染|输出|验收|校验|检查|启动|配置|怎么用|怎么跑|实操|process|usage|steps?|commands?|deploy|output|verify|check|run|build|render|generate|flow|test|debug|acceptance",
}
```

再抓两个信号：

```python
LOCAL = r"[A-Za-z]:[\\/]|\\\\|/home/|/Users/|127\.0\.0\.1|localhost|:\d{4,5}|administrator|schtasks|计划任务|凭据"
DEP   = r"`([^`\n]{2,80})`|\b([\w.-]+\.(?:ps1|py|cjs|mjs|js|json|md|ya?ml|db|exe))\b"
```

`local=true` 的零件不能直接搬去别的机器（组装时要么改硬编码、要么标注「需本机」）。
`deps` 里要滤掉噪声：命令行参数（`-SkipVerify`）、cmdlet 片段（`Test-Path`、`Get-*`）、
变量（`$PSScriptRoot`、`%TEMP%`）、URL、true/false/null。

---

## 4. ② assemblies.py：怎么找「可复用的组件」

**判据两条同时成立才成组件**（这是全篇最重要的一节）：

1. 一个执行体（脚本 / 主机 / 配置 / 数据文件）被 **≥2 个 skill** 引用；
2. 引用它的**零件 ≥2 个**（只被一两个章节提一句的，不算可复用）。

**聚合方式很关键**：不是「一个执行体 = 一个组件」，而是**按 skill 集合聚合**——
同一组 skill 共享的一批执行体，合成**一个**组件（DST 四件套那 18 个执行体其实是一件事）。

```python
dep_parts = defaultdict(list)             # dep -> [parts]
for p in PARTS:
    for d in p["deps"]:
        if GENERIC_DEP.match(d) or NOISE_DEP.match(d):   # 泛化词/噪声先滤掉
            continue
        dep_parts[d].append(p)

groups = defaultdict(lambda: {"deps": [], "parts": {}})
for dep, ps in dep_parts.items():
    skills = tuple(sorted({p["skill"] for p in ps}))
    if len(skills) < 2:                       # 判据 1：至少 2 个 skill
        continue
    if not any(p["layer"] == "act" for p in ps):
        continue                              # 判据 2：至少 1 个实践零件
    g = groups[skills]                        # ← 按"技能集合"聚合，不是按 dep
    g["deps"].append(dep)
    for p in ps:
        g["parts"][p["id"]] = p

for skills, g in groups.items():
    ps = list(g["parts"].values())
    layers = Counter(p["layer"] for p in ps)
    name = sorted(g["deps"], key=lambda d: (len(d), d))[0]     # 名字取最短的 dep
    if re.match(r"^[A-Za-z]:[\\/]", name):                    # 绝对路径取最后一段
        name = re.split(r"[\\/]", name.rstrip("\\/"))[-1]
    asms.append({
        "id": "asm-" + slug(name) + "-" + slug(skills[0])[:10],
        "name": name, "deps": sorted(g["deps"])[:12], "parts": ps,
        "skills": list(skills), "reuse": len(skills), "layers": dict(layers),
        "complete": layers["sense"] > 0 and layers["think"] > 0 and layers["act"] > 0,
        "status": "active", "verified": False, "usedBy": [],
    })
asms.sort(key=lambda a: (-a["reuse"], -sum(a["layers"].values())))
```

`complete` = 三层都至少一件；`verified` 默认 false，只有真被主组装用过并实测过才置 true。

再加一个 `match(need_tokens, topk=3)`：按需求词给组件打分（标题命中 > 正文命中，reuse 高的加权），
供 ③ 复用。输出 `assemblies.json`，并统计 `complete / reusedBy3plus` 两个数用来看健康度。

---

## 5. ③ compose.py：一句需求 → 装配单

```python
def tokens(text, strict=False):     # 中英混排：中文按 2 字切、英文按词切，去停用词
def build_index(parts):             # 每个零件的词表 + IDF
def score_part(p, tk, need_layers, idf, ptk, ttk):
    # 分数 = 层匹配(该层零件 +) × IDF 加权命中 × 文本相似 × 组件复用加成
```

关键细节：

- **需求暗示层**：`NEED_LAYER_HINT`——「什么时候用/要不要」→ sense，「怎么判断/算不算」→ think，
  「怎么写/怎么跑/验收」→ act。命中就给该层加权。
- **缺层判定**：该层没有任何零件，或者该层最高分低于阈值（阈值要跟分数尺度走，别写死 0.1）→
  在装配单里明确写「缺 X 层，需要新写」。
- **分派**：每个候选零件标 `复用 / 改造 / 新写` 三类；复用要写出「来自哪个 skill 的哪一节」。
- **输出**：`learn/reflection/out/compose-<需求slug>.md`，包含需求原文、三层候选（带来源）、缺层、装配步骤。
- **绝不自动写 SKILL.md**：装配单是草稿，跑通、验过才落成正式 skill。

---

## 6. 接进「自动」（本包的做法，可直接照搬）

本包的反思控制栏是**一个总开关**：`auto` 与 `assemble` 同时开关。

- 设置：`.dsh-meow/reflect-settings.json` 里 `{"auto":true,"assemble":true}`；
  老文件没有 `assemble` 时**跟随 `auto`**（避免开关状态说谎）。
- 接口：
  - `GET  /api/reflect/status` → 返回 `auto` / `assemble` / `running` / `lastRun`；
  - `POST /api/reflect/auto {on, assemble}` → 切换（注意：会真的启用/禁用系统计划任务，别替用户乱拨）；
  - `POST /api/reflect/assemble` → 立刻跑一次 `parts.py`，返回 `{ok, sec, counts, out, err}`（本机约 1 秒）。
- 执行：服务端用 `subprocess.run([python, "learn/reflection/parts.py"], cwd=WORKSPACE, timeout=180)`，
  跑完读 `parts.json` 的 `counts` 回给前端。
- **失败要能说话**：脚本不存在时回 **200 + `{ok:false, needScript:true, error:"<它自己解析出来的绝对路径>"}`**，
  不要回 500——页面才能告诉用户「这台机器上没有脚本，放哪去」。
- **跨机注意**：`WORKSPACE` 不同机器不一样（本机 `E:\心智单元`，服务器可能是别的路径），
  脚本里写死的输出路径必须改成可配置，否则「找到了脚本也写错地方」。

---

## 7. 自动化的边界（写脚本时就该守住）

1. **只自动产出草稿**：装配单可以是自动的，`SKILL.md` 必须人工审过才落。
2. **幂等 + 原子写**：`tmp` 文件写完 `os.replace`；同一天重复跑不产生重复条目。
3. **超时**：子进程一律给 `timeout`（180s 够用），超时当失败但要留半成品可查。
4. **别用文字相似度找重复**：三段式模板会让不同领域算出 0.6~0.7 假相似；
   判重只用 `deps`（同一脚本/主机/配置被几个 skill 引用）。
5. **共享执行体 ≠ 该合并 skill**：触发场景不同就抽组件，别合并。
   反例：DST 四件套共享 18 个执行体，合并会把四个触发场景挤在一起。
6. **成品 skill 默认不拆**：只有「完全用不上」或「需要优化」时才回到零件层。

---

## 8. 验收（做完必须跑）

```powershell
python learn\reflection\parts.py          # 期望输出 45 技能 / 264 零件 / unknown 占比 <30%
python learn\reflection\assemblies.py     # 期望 assemblies>0，complete 与 reusedBy3plus 有数
python learn\reflection\compose.py --need "每天检查服务器 DST 日志有没有崩"
python learn\reflection\compose.py --review   # 五种动作清单：merge/split/extract/prune/fill
# 接口：POST /api/reflect/assemble → {"ok":true,"sec":~1,"counts":{...}}
```

抽查三件事：① 抽 3 个零件看 `layer` 判得对不对、`text` 是不是原文；② 组件列表里
有没有「同一个脚本挂在两个不相干 skill 上」的误判；③ 装配单里「缺层」的判断是否合理。

## 9. 复制即用：包里自带的 `assembler/`

以上是原理；**要现成的同款库，直接用包里的三个脚本**（`plugins/memory-brain-graph/assembler/`，
已改成可用环境变量覆盖路径，不绑死任何机器）：

```powershell
$env:MBG_WS    = "E:\你的工作区"          # 工作区根（下面要有 plugins/ 或 learn/）
$env:MBG_SKILLS = "$env:USERPROFILE\.dsh\skills"   # 技能目录（可省，默认就是它）
$env:MBG_OUT   = "E:\你的工作区\plugins\memory-brain-graph\assets\organs"  # 产物目录

python assembler\parts.py          # ① 拆零件
python assembler\assemblies.py     # ② 找共享执行体 → 组件
python assembler\compose.py --need "每天检查服务器 DST 日志有没有崩"   # ③ 出装配单
python assembler\compose.py --review                                  # ④ 体检动作清单
```

**本机实测输出（可以拿它当对照基线）**：

```
parts.py       → 45 skills / 264 parts / 层 sense 50 · think 117 · act 72 · unknown 25
assemblies.py  → assemblies=15 (complete=3, reused>=3=3) bricks=264
```

两个脚本都是**幂等**的：重跑覆盖同样的文件，不会产生重复条目。
`compose.py` 的装配单写到 `learn/reflection/out/compose-<需求slug>.md`，体检报告写 `review.json`。

> 判层是**加权打分**不是首个命中：intro 直接归思索（身份说明）、标题命中每层 +4、
> 正文关键词密度最多 +2、代码块/命令 ≥ 阈值 → 实践 +1.5、表格多且没代码 → 思索 +0.8、
> 条件句多 → 感知 +0.6，总分 <0.8 判 unknown。这一条如果你改成「首个命中即返回」，
> 层分布会从 `50/117/72` 变成 `93/79/62` 那种样子——数字对不上就说明判层被简化坏了。

## 10. 从零开始的顺序

1. 跑通 `split_parts`，只输出 `{title,text}`；
2. 加判层（中英双语），人工抽 5 个验层；
3. 加 `deps` + `local`，看哪些执行体被 ≥2 个 skill 引用；
4. 出 `assemblies.json`，人工看组件名是否可读；
5. 写 `compose.py`（分词→打分→缺层→装配单），先跑三条真实需求；
6. 写 `--review` 五动作；
7. 接进自动流程（开关/接口/调度），最后按第 8 节验收。
