#!/usr/bin/env python3
"""手动反思写入器：把「记忆整理 / 自我审视 / 干了啥」写进页面上的中央反思区。

页面（plugins/memory-brain-graph/assets/index.html）每 60 秒轮询
plugins/memory-brain-graph/assets/organs/reflection.json，发现 updatedAt 变了就重画。

自动语义反思（semantic_reflect.py）写的是 date / summary / lines / newIds / absorbedIds；
本脚本只写 manual 字段，两者互不覆盖，所以「今日自动审视」和「我这次手动整理了啥」能同时看到。

用法（在 E:\\心智单元 下）：
  python learn/reflection/note.py --title 记忆整理 --summary "一句话结论" \\
      --line "新增 5 条：..." --line "更新 3 条：..." [--tokens 1234]
  python learn/reflection/note.py --clear     # 清掉手动区块
"""
import argparse
import datetime
import json
from pathlib import Path

WORKSPACE = Path(__file__).resolve().parents[2]
OUT = WORKSPACE / "plugins" / "memory-brain-graph" / "assets" / "organs" / "reflection.json"


def load():
    try:
        with open(OUT, "r", encoding="utf-8") as f:
            return json.load(f)
    except Exception:
        return {}


def day_key(now):
    """与页面同一口径：早上 05:00 换日，凌晨仍算前一天。"""
    d = now.date()
    if now.hour < 5:
        d -= datetime.timedelta(days=1)
    return d.isoformat()


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--title", default="记忆整理")
    ap.add_argument("--summary", default="")
    ap.add_argument("--line", action="append", default=[])
    ap.add_argument("--tokens", type=int, default=0)
    ap.add_argument("--from-json", default="", help="从 UTF-8 json 读 {title,summary,lines,tokens}，避开控制台中文转码问题")
    ap.add_argument("--clear", action="store_true")
    a = ap.parse_args()

    if a.from_json:
        with open(a.from_json, "r", encoding="utf-8") as f:
            spec = json.load(f)
        a.title = spec.get("title", a.title)
        a.summary = spec.get("summary", a.summary)
        a.line = spec.get("lines", a.line) or a.line
        a.tokens = int(spec.get("tokens", a.tokens) or 0)

    now = datetime.datetime.now()
    data = load()

    if a.clear:
        data.pop("manual", None)
    else:
        data["manual"] = {
            "at": now.strftime("%m-%d %H:%M"),
            "date": day_key(now),
            "title": a.title,
            "summary": a.summary[:80],
            "lines": [x for x in a.line if x][:4],
            "tokens": a.tokens,
        }
    # 页面靠 updatedAt 判断「有新反思」，变了就重画一次
    data["updatedAt"] = now.strftime("%Y-%m-%dT%H:%M:%S+08:00")

    OUT.parent.mkdir(parents=True, exist_ok=True)
    tmp = OUT.with_suffix(".json.tmp")
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)
    tmp.replace(OUT)
    print("WROTE %s  manual=%s" % (OUT, bool(data.get("manual"))))


if __name__ == "__main__":
    main()
