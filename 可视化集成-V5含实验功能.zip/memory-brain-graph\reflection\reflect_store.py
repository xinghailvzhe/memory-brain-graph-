# -*- coding: utf-8 -*-
"""反思历史的落盘与游标（三个反思脚本共用）。

为什么要有它（2026-11-01 用户反馈）：
  · 「已经反思过的内容要保存下来」——以前每次反思直接覆盖 reflection.json，历史全丢；
  · 「刚刚貌似重复反思上一个一样的信息」——语义反思每次都取最近 24 小时，
    隔几分钟再跑一遍就会把同一批记忆再总结一次，结论几乎一样。

做法：
  · 每次反思往 history.jsonl 追加一行（at / kind / summary / lines / tokens / model / ids）；
  · 语义反思用「上一次语义反思的时间」当游标：只看游标之后的记忆，没有新的就跳过，
    不改 reflection.json；
  · ids 是这次真正参与反思的记忆 id，页面据此把它们从"今日星座"里摘掉（已提炼）。
"""
import json
import os

HERE = os.path.dirname(os.path.abspath(__file__))
HISTORY = os.path.join(HERE, "history.jsonl")

# 会被「提炼」的层：页面据此把它们从待反思列表里摘掉。
# soul / user 不参与：它们是身份与个人偏好，不送给外部模型，也就不该被标成"已提炼"。
ABSORB_LEVELS = ("project", "fact", "lesson", "topic", "rules")


def append(entry):
    """追加一条历史；写失败不影响主流程。"""
    try:
        with open(HISTORY, "a", encoding="utf-8") as f:
            f.write(json.dumps(entry, ensure_ascii=False) + "\n")
        return True
    except Exception:
        return False


def entries(kind=None, limit=200):
    out = []
    try:
        with open(HISTORY, "r", encoding="utf-8") as f:
            for line in f:
                line = line.strip()
                if not line:
                    continue
                try:
                    e = json.loads(line)
                except Exception:
                    continue
                if kind and e.get("kind") != kind:
                    continue
                out.append(e)
    except Exception:
        return []
    return out[-limit:]


def last_at(kind=None):
    """最后一次反思的时间（毫秒时间戳）；没有就返回 0。"""
    best = 0
    for e in entries(kind):
        try:
            best = max(best, int(e.get("atMs") or 0))
        except Exception:
            continue
    return best


def known_ids(kind=None):
    """已经参与过反思的记忆 id 集合（跨所有历史），用于去重。"""
    out = set()
    for e in entries(kind):
        for i in (e.get("ids") or []):
            if i:
                out.add(str(i))
    return out
