#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""零件库：把每个 skill 拆成「感知 / 思索 / 实践」三层的可复用零件，并找出真重复。

为什么不再用 triads.py 的做法
------------------------------
triads.py 对**整篇** SKILL.md 数关键词密度，只回答「这个 skill 偏哪一科」，
拿它去组装是不可能的——它没有"零件"这个概念。这里改成**章节级**：

  一个零件 = SKILL.md 里的一个 `##` 章节（含标题），或开头的 intro。
  章节是 skill 里唯一可独立搬移、独立复用的单元。

三层（与记忆侧的 感知/思索/实践 同构：输入 / 处理 / 输出）
------------------------------------------------------------
  sense 感知：什么时候被触发、吃什么输入、前提与依赖、不适用边界
  think 思索：判据、阈值、取舍、优先级、失败分类、定义、踩过的坑
  act   实践：具体命令、脚本、流程、写入、部署、渲染、验收动作
  unknown    ：三轴都判不出来（不硬塞一层，如实标未知；组装时视为待补）

真重复怎么判（这是关键）
------------------------
**文字相似度不可信**：同一套模板写法（"什么时候用/流程/验收"）会让不同领域的
skill 算出 0.6~0.7 的相似度，那不是重复，只是同构。真正的重复信号是

  ① 共享执行体（deps）：两个 skill 引用同一个脚本 / 同一个远程主机 / 同一个配置
     —— 说明它们是同一个执行体的多份说明书，可合并或抽共享件；
  ② 正文近似（>=0.80）：同一段话被复制到两处。

产物：plugins/memory-brain-graph/assets/organs/parts.json

用法：
  python parts.py                 # 扫描 + 写 json + 打印摘要
  python parts.py --json          # 只打印 json
  python parts.py --skill NAME    # 看某个 skill 拆出来的零件
"""
import argparse
import hashlib
import json
import re
import sys
import datetime
from collections import defaultdict
import os
from pathlib import Path

WS = Path(os.environ.get("MBG_WS") or Path(__file__).resolve().parents[2])
SKILLS = Path(os.environ.get("MBG_SKILLS") or (Path.home() / ".dsh" / "skills"))
OUT = Path(os.environ.get("MBG_OUT") or (WS / "plugins" / "memory-brain-graph" / "assets" / "organs")) / "parts.json"

# ---------------------------------------------------------------- 三层判定

# 标题规则（强判据）。英文 skill 占一半，必须同时覆盖动词结构（→实践）
# 与名词概念（→思索），否则一半零件判不出来。
TITLE_RULES = {
    "sense": re.compile(
        r"什么时候用|何时用|什么时候别用|不适用|适用|触发|唤醒|监听|前提|前置|依赖|安装|输入|"
        r"边界|限制|别用|不该用|用在哪|"
        r"\bwhen\b|\bwhenever\b|precondition|prerequisit|require|setup|install|input|on-?ramp|trigger|"
        r"invocation|context pointers", re.I),
    "think": re.compile(
        r"判断|判据|怎么判断|如何判断|规则|约定|纪律|阈值|优先级|取舍|策略|原则|铁律|"
        r"坑|陷阱|失败|错误|退出码|分类|权衡|决策|评估|定义|词汇|术语|反模式|为什么|人设|"
        r"注意事项|待定|未定|分工|可用性|成本|参考|自检|读法|"
        r"\bglossary\b|\bprinciple|\brule\b|\brelationship|\bdefinition|\bcriteria\b|anti-?pattern|"
        r"\bpitfall|\bgotcha|\bwhy\b|\breason|\bdecision|\btradeoff|\bboundary|\blimit\b|"
        r"\bcontract|\brefram|\bframing|\bnotes?\b|\bvocabulary|\bhealth\b|\bphilosophy|"
        r"\bmission\b|\bknowledge|\bwisdom\b|\breference|\bstandalone\b|\bduring\b|"
        r"\bspecified\b|invariant|\bredact|\btypes\b|\bdanger\b", re.I),
    "act": re.compile(
        r"流程|用法|步骤|一条命令|命令|脚本|执行|部署|写入|生成|渲染|输出|验收|校验|检查|"
        r"收尾|启动|配置|怎么用|怎么跑|怎么改|怎么装|实操|主循环|动作|屏幕和动作|做法|"
        r"\bprocess\b|\busage\b|\bsteps?\b|\bcommands?\b|\bdeploy|\boutput|\bverify|\bcheck\b|"
        r"\brun\b|\bbuild\b|\brender|\bgenerate|\bflow\b|\bdesign|\breproduce|\bhypothes|"
        r"\binstrument|\bfix\b|\bcleanup|\bpick\b|\bwrite\b|\bshow\b|\btriage\b|\bplan\b|"
        r"\btest\b|\bdebug|\bstart\b|\bstop\b|\binit\b|\bimport\b|\bparse\b|\bsplit\b|"
        r"\bmerge\b|\breview|\bresolve|\btemplate|\bsections?\b|\bsummary\b|\bevidence\b|"
        r"problem statement|\bsolution\b|out of scope|further notes|acceptance|what to build|"
        r"blocked by|\bparent\b", re.I),
}

# 正文关键词（弱判据）
BODY_PAT = {
    "sense": re.compile(
        r"监听|事件|触发|感知|轮询|检测|订阅|hook|watch|listen|emit|observ|subscrib|schedul|timer|interval|poll|"
        r"前提|依赖|需要先|必须先|输入|来源|当.*时|一旦|只要|"
        r"\bwhen\b|\bonce\b|\bupon\b|\bas soon as\b|\btrigger", re.I),
    "think": re.compile(
        r"判断|决策|策略|规则|条件|阈值|权重|优先级|分析|解析|推理|评估|取舍|如果.*就|否则|不要|别|应该|"
        r"policy|rule|threshold|score|weight|priorit|decision|evaluat|\bif\b|\bunless\b|\bshould\b|\bmust\b", re.I),
    "act": re.compile(
        r"写入|保存|执行|运行|推送|上传|下载|部署|生成|渲染|绘制|命令|工具调用|落盘|"
        r"write|save|exec|spawn|deploy|render|draw|push|upload|fetch|apply|invoke|\brun\b", re.I),
}

# 含这些说明零件绑死本机环境，不能直接搬走（可复用性 = local）
LOCAL_MARK = re.compile(
    r"[A-Za-z]:[\\/]|\\\\|/home/|/Users/|115\.238\.|127\.0\.0\.1|localhost|:\d{4,5}|"
    r"administrator|credentialTarget|schtasks|计划任务|凭据", re.I)

# 命令/脚本/工具引用（零件之间的真实依赖；也是"真重复"的主信号）
DEP_PAT = re.compile(
    r"`([^`\n]{2,80})`|"
    r"\b([\w.-]+\.(?:ps1|py|cjs|mjs|js|json|md|ya?ml|lua|db|exe))\b|"
    r"\b([a-z_][a-z0-9_]{3,40})\s*\{",
    re.I)

# 依赖里的噪声词：不是执行体，别拿它判重复
DEP_NOISE = re.compile(
    r"^(true|false|null|none|yes|no|sk-.*|https?:.*|www\..*|"
    r"-\S.*|"                                    # 命令行参数：-SkipVerify / -Json
    r"(?:Test-Path|Get|Set|Start|Stop|Invoke|New|Remove|Write|Read|Select|Where)-\w+.*|"  # cmdlet 片段
    r"[$%]\S*|"                                  # 变量：$PSScriptRoot / %TEMP%
    r"\d+|"
    r"SKILL\.md|"
    r"[A-Za-z]:[\\/].*\s.*"                      # 带空格的路径 = 命令片段，不是稳定标识
    r")$", re.I)


def deps_of(text):
    """只留「稳定标识」：脚本/配置/数据文件名、IP、绝对路径、无空格标识符。
    命令行片段（Test-Path 'D:\\...'、-SkipVerify、$PSScriptRoot）一律不算依赖。"""
    out = set()
    for m in DEP_PAT.finditer(text):
        for g in m.groups():
            if not g:
                continue
            g = g.strip().strip("'\"")
            if len(g) < 4 or len(g) > 80:
                continue
            if DEP_NOISE.match(g):
                continue
            # 带空格的多半是命令片段；唯一允许的是「不带引号的路径」
            if " " in g and not re.match(r"^[A-Za-z]:[\\/]", g):
                continue
            out.add(g)
    return sorted(out)[:14]

# 代码块 / 表格 / 条件句的结构特征
CODE_BLOCK = re.compile(r"```")
TABLE_ROW = re.compile(r"^\s*\|.*\|\s*$", re.M)
CMD_TOKENS = re.compile(r"(?:\b(?:pwsh|powershell|python|node|cmd|git|ssh|curl|schtasks|robocopy)\b|"
                        r"\s-{1,2}[A-Za-z][\w-]*\s|^\s*[$>]\s)", re.M)


def parse_frontmatter(text):
    if not text.startswith("---"):
        return {}, text
    end = text.find("\n---", 3)
    if end < 0:
        return {}, text
    raw, body = text[3:end].strip("\n"), text[end + 4:].lstrip("\n")
    fm, key = {}, None
    for line in raw.splitlines():
        if re.match(r"^\s+\S", line) and key:
            fm[key] = (fm.get(key, "") + " " + line.strip()).strip()
            continue
        m = re.match(r"^([A-Za-z_][\w-]*)\s*:\s*(.*)$", line)
        if m:
            key = m.group(1)
            fm[key] = m.group(2).strip().strip('"').strip("'")
    return fm, body


def split_sections(body):
    out, cur = [], {"title": "(intro)", "lines": []}
    for line in body.splitlines():
        if re.match(r"^##\s+\S", line):
            if cur["lines"] or cur["title"] != "(intro)":
                out.append(cur)
            cur = {"title": line[3:].strip(), "lines": []}
        else:
            cur["lines"].append(line)
    out.append(cur)
    return [{"title": c["title"], "text": "\n".join(c["lines"]).strip()} for c in out]


def classify(title, text):
    """三轴打分。返回 (主层, 分数 dict, 判定依据)。判不出来就 'unknown'，不硬塞。"""
    t = title.strip()
    sc = {"sense": 0.0, "think": 0.0, "act": 0.0}
    why = []

    # ⓪ intro：它是「这个 skill 是什么」的身份说明，归思索（定义），不是动作也不是触发
    if t == "(intro)":
        return "think", {"sense": 0.0, "think": 1.0, "act": 0.0}, "intro"

    # ① 标题（权重 4 —— 标题是作者亲手写下的功能标签，比正文词频可信）
    for layer, rx in TITLE_RULES.items():
        if rx.search(t):
            sc[layer] += 4.0
            why.append("title:" + layer)

    # ② 正文词密度（0~2）
    n = max(len(text), 1)
    for layer, rx in BODY_PAT.items():
        dens = len(rx.findall(text)) / (n / 1000.0)
        sc[layer] += min(2.0, dens / 12.0 * 2.0)

    # ③ 结构特征（0~1.5）
    codes = len(CODE_BLOCK.findall(text)) // 2
    rows = len(TABLE_ROW.findall(text))
    cmds = len(CMD_TOKENS.findall(text))
    if codes >= 2 or cmds >= 3:
        sc["act"] += min(1.5, 0.5 + 0.25 * max(codes, cmds))
        why.append("struct:code")
    if rows >= 3 and codes == 0:
        sc["think"] += 0.8
        why.append("struct:table")
    cond = len(re.findall(r"如果|当.*?时|一旦|只要|when |if |unless ", text, re.I))
    if cond >= 3 and codes == 0:
        sc["sense"] += 0.6
        why.append("struct:cond")

    total = sum(sc.values())
    if total < 0.8:
        return "unknown", {k: 0.0 for k in sc}, "unknown"
    mix = {k: round(v / total, 3) for k, v in sc.items()}
    best = max(sc, key=lambda k: sc[k])
    if sc[best] < 0.8:
        return "unknown", mix, "unknown"
    return best, mix, ",".join(why) or "body"


def norm_text(text):
    t = re.sub(r"```.*?```", " ", text, flags=re.S)
    t = re.sub(r"https?://\S+", " ", t)
    t = re.sub(r"[A-Za-z]:[\\/][^\s`)\]]*", " ", t)
    t = re.sub(r"`[^`]*`", " ", t)
    t = re.sub(r"\d+", "0", t)
    t = re.sub(r"[\s，。、；：！？,.;:!?()（）\[\]【】|*#>~_-]+", "", t)
    return t.lower()


def shingles(t, k=3):
    return set(t[i:i + k] for i in range(max(0, len(t) - k + 1)))


def analyze_skill(name, path):
    raw = path.read_text(encoding="utf-8", errors="ignore")
    fm, body = parse_frontmatter(raw)
    parts = []
    for i, s in enumerate(split_sections(body)):
        if s["title"] == "(intro)" and len(s["text"]) < 20:
            continue
        layer, mix, how = classify(s["title"], s["text"])
        norm = norm_text(s["text"])
        parts.append({
            "id": "%s/%02d" % (name, i),
            "skill": name,
            "title": s["title"],
            "layer": layer,
            "mix": mix,
            "how": how,
            "chars": len(s["text"]),
            "hash": hashlib.sha1(norm.encode("utf-8")).hexdigest()[:12],
            "norm_len": len(norm),
            "deps": deps_of(s["text"]),
            "local": bool(LOCAL_MARK.search(s["text"])),
            "text": s["text"],
        })
    return {"name": name, "description": fm.get("description", ""),
            "chars": len(raw), "parts": parts}


def find_dups(skills):
    """真重复 = 共享执行体（主）+ 正文近似（辅）。跨 skill 才算。"""
    all_parts = [p for s in skills for p in s["parts"]]

    # ① 共享执行体：每个 dep 被哪些 skill 用
    dep_skills = defaultdict(set)
    dep_parts = defaultdict(list)
    for p in all_parts:
        for d in p["deps"]:
            dep_skills[d].add(p["skill"])
            dep_parts[d].append(p["id"])
    exec_shared = []
    for d, sks in dep_skills.items():
        if len(sks) >= 2:
            exec_shared.append({
                "dep": d,
                "skills": sorted(sks),
                "parts": dep_parts[d][:8],
            })
    exec_shared.sort(key=lambda x: -len(x["skills"]))

    # ② 正文近似（阈值 0.80；低于它是模板同构，不算重复）
    sh = {p["id"]: shingles(re.sub(r"\s", "", norm_text(p["text"])))
          for p in all_parts if p["norm_len"] >= 80}
    by_id = {p["id"]: p for p in all_parts}
    text_pairs, seen = [], set()
    ids = list(sh.keys())
    for i, a in enumerate(ids):
        for b in ids[i + 1:]:
            pa, pb = by_id[a], by_id[b]
            if pa["skill"] == pb["skill"]:
                continue
            key = (min(a, b), max(a, b))
            if key in seen:
                continue
            sa, sb = sh[a], sh[b]
            inter = len(sa & sb)
            if not inter:
                continue
            score = inter / float(len(sa | sb))
            if score >= 0.80:
                seen.add(key)
                text_pairs.append({
                    "score": round(score, 3),
                    "a": {"id": a, "skill": pa["skill"], "title": pa["title"], "layer": pa["layer"]},
                    "b": {"id": b, "skill": pb["skill"], "title": pb["title"], "layer": pb["layer"]},
                })
    text_pairs.sort(key=lambda x: -x["score"])
    return exec_shared, text_pairs


def skill_dist(sk):
    dist = {"sense": 0, "think": 0, "act": 0, "unknown": 0}
    for p in sk["parts"]:
        dist[p["layer"]] = dist.get(p["layer"], 0) + 1
    return dist


def find_gaps(skills, exec_shared):
    """偏科 / 入口型 / 孤岛 —— 都是组装时会断链的地方。"""
    gaps = []
    for sk in skills:
        dist = skill_dist(sk)
        n = len(sk["parts"]) or 1
        known = n - dist["unknown"]
        sk["dist"] = dist
        sk["totalParts"] = n

        if n <= 2 and sk["chars"] < 1200:
            gaps.append({"skill": sk["name"], "kind": "entry", "missing": [], "dominant": "entry",
                         "note": "入口型（%d 个零件 / %d 字符）：只转指不干活，装配时算噪声" % (n, sk["chars"])})
            continue
        if n < 3 or known < 2:
            continue
        missing = [k for k in ("sense", "think", "act") if dist[k] == 0]
        dominant = max(("sense", "think", "act"), key=lambda k: dist[k])
        if missing and dist[dominant] / float(known) >= 0.6:
            what = {"sense": "触发条件", "think": "判断依据", "act": "落地动作"}
            gaps.append({
                "skill": sk["name"], "kind": "lopsided", "missing": missing,
                "dominant": dominant, "share": round(dist[dominant] / float(known), 2),
                "note": "全是%s件、缺%s —— 装配时找不到%s" % (
                    {"sense": "感知", "think": "思索", "act": "实践"}[dominant],
                    "/".join({"sense": "触发", "think": "判据", "act": "动作"}[m] for m in missing),
                    "、".join(what[m] for m in missing)),
            })
    # 孤岛：没有任何跨 skill 共享执行体，也不出现在别人的依赖里
    in_cluster = set()
    for e in exec_shared:
        in_cluster.update(e["skills"])
    for sk in skills:
        if sk["totalParts"] >= 4 and sk["name"] not in in_cluster:
            gaps.append({"skill": sk["name"], "kind": "island", "missing": [], "dominant": "-",
                         "note": "%d 个零件但没和任何 skill 共享执行体：可能重复造轮子，也可能该被引用" % sk["totalParts"]})
    return gaps


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("--json", action="store_true")
    ap.add_argument("--skill")
    args = ap.parse_args()

    skills = []
    if SKILLS.exists():
        for d in sorted(SKILLS.iterdir()):
            f = d / "SKILL.md"
            if d.is_dir() and f.exists():
                skills.append(analyze_skill(d.name, f))

    if args.skill:
        hit = [s for s in skills if s["name"] == args.skill]
        if not hit:
            print("no such skill:", args.skill)
            return 1
        for p in hit[0]["parts"]:
            print("%-44s %-7s %4d  %s" % (p["title"][:44], p["layer"], p["chars"], p["how"]))
        return 0

    exec_shared, text_pairs = find_dups(skills)
    gaps = find_gaps(skills, exec_shared)

    dist_total = {"sense": 0, "think": 0, "act": 0, "unknown": 0}
    for sk in skills:
        for p in sk["parts"]:
            dist_total[p["layer"]] = dist_total.get(p["layer"], 0) + 1

    # 执行体聚簇：共享 >=3 个执行体的 skill 组 = 同一个执行体的多份说明书
    pair_deps = defaultdict(set)
    for e in exec_shared:
        for i, a in enumerate(e["skills"]):
            for b in e["skills"][i + 1:]:
                pair_deps[(a, b)].add(e["dep"])
    clusters = []
    for (a, b), ds in sorted(pair_deps.items(), key=lambda x: -len(x[1])):
        if len(ds) >= 3:
            clusters.append({"a": a, "b": b, "sharedDeps": len(ds), "deps": sorted(ds)[:8],
                             "suggest": "同一个执行体的两份说明书：合并，或抽成共享件后各留触发与判据"})

    data = {
        "generatedAt": datetime.datetime.now().strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        "source": str(SKILLS),
        "counts": {
            "skills": len(skills),
            "parts": sum(len(s["parts"]) for s in skills),
            "layers": dist_total,
            "execShared": len(exec_shared),
            "textDup": len(text_pairs),
            "clusters": len(clusters),
            "gaps": len(gaps),
            "unknown": dist_total.get("unknown", 0),
        },
        "layers": {"sense": "感知/触发/输入", "think": "思索/判据/取舍",
                   "act": "实践/动作/产出", "unknown": "判不出（不硬塞）"},
        "skills": [{"name": s["name"], "description": s["description"],
                    "parts": s["totalParts"], "dist": s["dist"], "chars": s["chars"]}
                   for s in skills],
        "parts": [p for s in skills for p in s["parts"]],
        "execShared": exec_shared,
        "clusters": clusters,
        "textDup": text_pairs,
        "gaps": gaps,
    }

    if args.json:
        print(json.dumps(data, ensure_ascii=False, indent=2))
        return 0

    OUT.parent.mkdir(parents=True, exist_ok=True)
    OUT.write_text(json.dumps(data, ensure_ascii=False, indent=2), encoding="utf-8")

    c = data["counts"]
    print("skills=%(skills)d parts=%(parts)d -> %s" % c % () if False else "skills=%d parts=%d -> %s" % (
        c["skills"], c["parts"], OUT))
    print("layers: sense=%d think=%d act=%d unknown=%d" % (
        dist_total["sense"], dist_total["think"], dist_total["act"], dist_total["unknown"]))
    print("execShared=%d  textDup=%d  clusters=%d  gaps=%d" % (
        c["execShared"], c["textDup"], c["clusters"], c["gaps"]))
    print("\n-- clusters（共享 >=3 个执行体：同一个执行体的多份说明书）--")
    for x in clusters[:12]:
        print("  %2d  %-30s <-> %-30s" % (x["sharedDeps"], x["a"], x["b"]))
    print("\n-- execShared top（最强复用信号）--")
    for e in exec_shared[:12]:
        print("  %-42s %s" % (e["dep"][:42], ",".join(e["skills"])[:88]))
    print("\n-- gaps --")
    for g in gaps[:16]:
        print("  [%-8s] %-30s %s" % (g["kind"], g["skill"], g["note"]))
    return 0


if __name__ == "__main__":
    sys.exit(main())
