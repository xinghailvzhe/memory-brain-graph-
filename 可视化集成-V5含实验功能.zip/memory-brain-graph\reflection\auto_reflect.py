# -*- coding: utf-8 -*-
"""每小时自动反思：读记忆库最近 1 小时的条目，归纳成小结，写回页面用的 reflection.json。
规则式归纳（不调模型，token 消耗为 0）；以后接入模型时只替换 build_lines()。
"""
import sqlite3
import json
import os
import datetime

import reflect_store

HERE = os.path.dirname(os.path.abspath(__file__))
WORKSPACE = os.environ.get("REFLECT_WORKSPACE") or os.path.dirname(os.path.dirname(HERE))
DB = os.environ.get("REFLECT_DB") or os.path.join(WORKSPACE, ".dsh-meow", "memory.db")
OUT = os.environ.get("REFLECT_OUT") or os.path.join(
    WORKSPACE, "plugins", "memory-brain-graph", "assets", "organs", "reflection.json")
LEVELS = ["soul", "user", "project", "fact", "lesson", "topic", "rules"]
NAME = {"soul": "灵魂", "user": "用户", "project": "项目", "fact": "事实",
        "lesson": "经验", "topic": "话题", "rules": "准则"}


def recent(conn, since_ms):
    out = []
    for lv in LEVELS:
        try:
            rows = conn.execute(
                "SELECT id, title, content, project FROM %s WHERE updated_at >= ? ORDER BY updated_at DESC" % lv,
                (since_ms,),
            ).fetchall()
        except Exception:
            continue
        for rid, t, c, p in rows:
            out.append({"id": str(rid or ""), "level": lv, "title": t or "",
                        "content": c or "", "project": p or ""})
    return out


def build_lines(items):
    if not items:
        return ["近一小时没有新的记忆"]
    cnt = {}
    for it in items:
        cnt[it["level"]] = cnt.get(it["level"], 0) + 1
    parts = ["%s %d" % (NAME.get(k, k), v) for k, v in sorted(cnt.items(), key=lambda x: -x[1])]
    lines = ["近一小时新增 %d 条：%s" % (len(items), " · ".join(parts))]
    for it in items[:2]:
        t = it["title"].strip()
        if t:
            lines.append("· " + t[:34])
    projects = sorted({it["project"] for it in items if it["project"] and it["project"] != "全局"})
    if projects:
        lines.append("涉及项目：" + "、".join(projects[:3]))
    return lines[:3]


def main():
    now = datetime.datetime.now()
    since = int((now - datetime.timedelta(hours=1)).timestamp() * 1000)  # updated_at 是毫秒时间戳
    try:
        conn = sqlite3.connect(DB)
        items = recent(conn, since)
        conn.close()
    except Exception as e:
        print("DB error:", e)
        return
    if not items:
        print("no new memories in last hour, skip")
        return
    ids = [it["id"] for it in items
           if it.get("id") and it.get("level") in reflect_store.ABSORB_LEVELS]
    prev_absorbed = []
    prev_manual = None
    try:
        with open(OUT, "r", encoding="utf-8") as f:
            _prev = json.load(f)
        prev_absorbed = _prev.get("absorbedIds") or []
        prev_manual = _prev.get("manual")
    except Exception:
        pass
    data = {
        "date": now.strftime("%Y-%m-%d"),
        "updatedAt": now.strftime("%Y-%m-%dT%H:%M:%S+08:00"),
        "autoAt": now.strftime("%m-%d %H:%M"),
        "tokens": 0,
        "summary": "自动反思 · 近一小时 %d 条新记忆" % len(items),
        "lines": build_lines(items),
        "newIds": ids,
        "absorbedIds": sorted(set(map(str, prev_absorbed)) | set(ids)),
        "kind": "rules",
    }
    # 手动反思（note.py 写的 manual）不能被自动反思覆盖掉：整体重写时要把它带上
    if prev_manual:
        data["manual"] = prev_manual
    # 同一天已有语义反思结论时，规则反思只记历史、不覆盖页面：
    # 否则每小时「近一小时新增 N 条」会把 04:45 的真结论顶掉（2026-11-01 用户反馈）。
    skip_display = False
    try:
        with open(OUT, "r", encoding="utf-8") as f:
            prev_json = json.load(f)
        if prev_json.get("kind") == "semantic" and prev_json.get("date") == now.strftime("%Y-%m-%d"):
            skip_display = True
    except Exception:
        pass
    ok = skip_display
    for _ in range(0 if skip_display else 3):
        try:
            with open(OUT, "w", encoding="utf-8") as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            ok = True
            break
        except Exception as e:
            print("write retry:", e)
            import time
            time.sleep(1)
    print("reflection written:", ok, "items:", len(items),
          "display:", "kept semantic" if skip_display else "updated")
    if ok:
        reflect_store.append({
            "at": now.strftime("%Y-%m-%dT%H:%M:%S"),
            "atMs": int(now.timestamp() * 1000),
            "kind": "rules",
            "summary": data["summary"],
            "lines": data["lines"],
            "tokens": 0,
            "model": "",
            "ids": ids,
        })
    # 顺手重算三元图坐标（纯本地静态扫描，不调模型；失败不影响反思本身）
    try:
        import triads
        triads.main()
    except Exception as e:
        print("triads skip:", e)


if __name__ == "__main__":
    main()
